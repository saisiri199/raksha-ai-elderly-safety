import { RadarSample, RadarTargetState, RadarConfidenceLevel, RadarVerificationState } from '../types';

export const MIN_CONSECUTIVE_READINGS = 3;
export const MIN_WINDOW_MS = 2000; // 2 seconds minimum temporal window
export const MAX_WINDOW_MS = 5000; // 5 seconds maximum temporal window

export const INITIAL_RADAR_STATE: RadarVerificationState = {
  state: 'NO_TARGET',
  confidence: 'No target',
  consecutiveReadings: 0,
  sampleCount: 0,
  presenceDurationSec: 0,
  movementDurationSec: 0,
  distanceGate: 0,
  distanceMeters: 0,
  signalStabilityPct: 0,
  lastEvaluationReason: 'Idle noise floor baseline. Scanning at 24GHz.',
  isVerifying: false,
  rawSamples: [],
};

/**
 * Evaluates radar samples buffer using the 7-state human presence verification state machine.
 */
export function evaluateRadarSamples(
  samples: RadarSample[],
  currentState: RadarVerificationState,
  now = Date.now()
): RadarVerificationState {
  // Prune samples older than MAX_WINDOW_MS (5s)
  const validWindowSamples = samples.filter((s) => now - s.timestamp <= MAX_WINDOW_MS);

  if (validWindowSamples.length === 0) {
    return {
      ...INITIAL_RADAR_STATE,
      lastEvaluationReason: 'No active target detected within 5-second window.',
    };
  }

  const consecutiveCount = validWindowSamples.length;
  const latestSample = validWindowSamples[validWindowSamples.length - 1];
  const oldestSample = validWindowSamples[0];
  const windowDurationMs = latestSample.timestamp - oldestSample.timestamp;
  const presenceDurationSec = Math.max(
    0.5,
    Math.round((windowDurationMs / 1000) * 10) / 10
  );

  // Compute average distance gate and signal stability
  const avgDistanceMeters =
    validWindowSamples.reduce((acc, s) => acc + s.distanceMeters, 0) / consecutiveCount;
  const avgGate = Math.round(
    validWindowSamples.reduce((acc, s) => acc + s.distanceGate, 0) / consecutiveCount
  );
  const avgStability = Math.round(
    validWindowSamples.reduce((acc, s) => acc + s.stabilityScore, 0) / consecutiveCount
  );

  // Rule: Check for possible impact or sudden low-position event
  // MUST have at least 2 corroborating low-position readings (never from 1 reading!)
  const lowPositionImpactCount = validWindowSamples.filter(
    (s) => s.isLowPositionImpact || s.targetProfile === 'low_position_impact'
  ).length;

  if (lowPositionImpactCount >= 2 && consecutiveCount >= MIN_CONSECUTIVE_READINGS) {
    return {
      state: 'POSSIBLE_FALL',
      confidence: 'Needs checking',
      consecutiveReadings: consecutiveCount,
      sampleCount: validWindowSamples.length,
      presenceDurationSec,
      movementDurationSec: presenceDurationSec,
      distanceGate: avgGate,
      distanceMeters: Math.round(avgDistanceMeters * 10) / 10,
      signalStabilityPct: avgStability,
      lastEvaluationReason:
        'Sudden downward transition and sustained low-position echo detected across multiple readings.',
      isVerifying: false,
      rawSamples: validWindowSamples,
    };
  }

  // Rule: If fewer than 3 consecutive readings, ALWAYS keep in TARGET_CHECKING
  // "First show 'Checking movement…' — do not immediately display 'Human detected.'"
  if (consecutiveCount < MIN_CONSECUTIVE_READINGS) {
    return {
      state: 'TARGET_CHECKING',
      confidence: 'Needs checking',
      consecutiveReadings: consecutiveCount,
      sampleCount: validWindowSamples.length,
      presenceDurationSec,
      movementDurationSec: latestSample.movement ? presenceDurationSec : 0,
      distanceGate: latestSample.distanceGate,
      distanceMeters: latestSample.distanceMeters,
      signalStabilityPct: avgStability,
      lastEvaluationReason: `Checking movement... Sample ${consecutiveCount} of ${MIN_CONSECUTIVE_READINGS} recorded in ${Math.round(windowDurationMs)}ms.`,
      isVerifying: true,
      rawSamples: validWindowSamples,
    };
  }

  // At least 3 consecutive readings available in temporal window.
  // Evaluate signal characteristics:
  // Non-human indicators:
  // - High flutter / unstable jitter (stability < 60%)
  // - Marked as micro_flutter or pet_or_debris
  // - Drastic gate fluctuation (e.g. variance > 2.5 gates across 3 samples)
  const isMicroFlutter = validWindowSamples.some(
    (s) => s.targetProfile === 'micro_flutter' || s.targetProfile === 'pet_or_debris'
  );
  const gateVariance = Math.max(...validWindowSamples.map((s) => s.distanceGate)) -
    Math.min(...validWindowSamples.map((s) => s.distanceGate));
  const isErraticSignal = avgStability < 55 || gateVariance > 2;

  if (isMicroFlutter || isErraticSignal) {
    return {
      state: 'NON_HUMAN_LIKELY',
      confidence: 'Non-human movement likely',
      consecutiveReadings: consecutiveCount,
      sampleCount: validWindowSamples.length,
      presenceDurationSec,
      movementDurationSec: presenceDurationSec,
      distanceGate: avgGate,
      distanceMeters: Math.round(avgDistanceMeters * 10) / 10,
      signalStabilityPct: avgStability,
      lastEvaluationReason:
        'Signal is brief, unstable, or inconsistent with human-sized presence (e.g., curtain flutter, fan, or pet). Kept out of alert pipeline.',
      isVerifying: false,
      rawSamples: validWindowSamples,
    };
  }

  // Consistent human-sized reflection verified over >= 3 samples with high stability
  return {
    state: 'HUMAN_LIKELY',
    confidence: 'Human likely',
    consecutiveReadings: consecutiveCount,
    sampleCount: validWindowSamples.length,
    presenceDurationSec,
    movementDurationSec: latestSample.movement ? presenceDurationSec : 0.5,
    distanceGate: avgGate,
    distanceMeters: Math.round(avgDistanceMeters * 10) / 10,
    signalStabilityPct: avgStability,
    lastEvaluationReason: `Human-sized presence verified over ${consecutiveCount} consecutive samples across ${presenceDurationSec}s (${avgStability}% stability).`,
    isVerifying: false,
    rawSamples: validWindowSamples,
  };
}
