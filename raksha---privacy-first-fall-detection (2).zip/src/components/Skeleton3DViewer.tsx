import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Shield,
  Eye,
  EyeOff,
  Compass,
  Layers,
  ChevronDown,
  ChevronUp,
  Maximize2,
  AlertTriangle,
  CheckCircle2,
  Info,
  VideoOff,
  RefreshCw,
} from 'lucide-react';
import { LivingRoomStatus } from '../types';
import {
  validateAndSanitizeLandmarks,
  SAFE_DEFAULT_COORDINATES,
} from '../utils/sensorValidation';

export type DemoPoseType = 'normal' | 'possible-fall' | 'lying-down';
export type CameraViewPreset = 'front' | 'side' | 'top' | 'isometric';

export type ForcedLandmarkError = 'missing' | 'fewer_landmarks' | 'invalid_coords' | null;

interface Skeleton3DViewerProps {
  status: LivingRoomStatus;
  externalPose?: DemoPoseType;
  onPoseChange?: (pose: DemoPoseType) => void;
  cameraConnected?: boolean;
  rawLandmarks?: unknown;
  forcedError?: ForcedLandmarkError;
  onClearForcedError?: () => void;
}

// MediaPipe 33 Landmark Names & anatomical group mapping
export interface LandmarkMeta {
  id: number;
  name: string;
  group: 'head' | 'torso' | 'arms' | 'legs' | 'feet';
  isFaceDetail?: boolean;
}

// Landmark sphere radius strictly between 0.05 and 0.08
// With distinctly larger spheres for shoulders, hips, knees, and ankles
export function getLandmarkRadius(landmarkId: number): number {
  if (landmarkId === 11 || landmarkId === 12) return 0.078; // Shoulders (Large)
  if (landmarkId === 23 || landmarkId === 24) return 0.078; // Hips (Large)
  if (landmarkId === 25 || landmarkId === 26) return 0.074; // Knees (Large)
  if (landmarkId === 27 || landmarkId === 28) return 0.072; // Ankles (Large)
  if (landmarkId === 0) return 0.070; // Head / Cranium
  if (landmarkId === 13 || landmarkId === 14) return 0.062; // Elbows
  if (landmarkId === 15 || landmarkId === 16) return 0.056; // Wrists
  if (landmarkId >= 17 && landmarkId <= 22) return 0.050; // Hands & fingers (min 0.05)
  if (landmarkId >= 29 && landmarkId <= 32) return 0.052; // Heels & foot index
  return 0.058;
}

// Thick visible bone radii for volumetric 3D cylinders
export function getBoneRadius(idx1: number, idx2: number): number {
  const isTorso =
    (idx1 === 11 && idx2 === 12) ||
    (idx1 === 11 && idx2 === 23) ||
    (idx1 === 12 && idx2 === 24) ||
    (idx1 === 23 && idx2 === 24) ||
    (idx1 === 0 && (idx2 === 11 || idx2 === 12));
  if (isTorso) return 0.026;

  const isLeg = idx1 === 23 || idx1 === 24 || idx1 === 25 || idx1 === 26;
  if (isLeg) return 0.024;

  const isUpperArm = (idx1 === 11 && idx2 === 13) || (idx1 === 12 && idx2 === 14);
  if (isUpperArm) return 0.022;

  return 0.018; // Forearms and hands/feet
}

export const IMPORTANT_LANDMARKS: Record<number, string> = {
  0: 'Nose',
  11: 'Left Shoulder',
  12: 'Right Shoulder',
  23: 'Left Hip',
  24: 'Right Hip',
  25: 'Left Knee',
  26: 'Right Knee',
  27: 'Left Ankle',
  28: 'Right Ankle',
};

export const LANDMARKS_META: LandmarkMeta[] = [
  { id: 0, name: 'Nose', group: 'head' },
  { id: 1, name: 'Left Eye Inner', group: 'head', isFaceDetail: true },
  { id: 2, name: 'Left Eye', group: 'head', isFaceDetail: true },
  { id: 3, name: 'Left Eye Outer', group: 'head', isFaceDetail: true },
  { id: 4, name: 'Right Eye Inner', group: 'head', isFaceDetail: true },
  { id: 5, name: 'Right Eye', group: 'head', isFaceDetail: true },
  { id: 6, name: 'Right Eye Outer', group: 'head', isFaceDetail: true },
  { id: 7, name: 'Left Ear', group: 'head', isFaceDetail: true },
  { id: 8, name: 'Right Ear', group: 'head', isFaceDetail: true },
  { id: 9, name: 'Mouth Left', group: 'head', isFaceDetail: true },
  { id: 10, name: 'Mouth Right', group: 'head', isFaceDetail: true },
  { id: 11, name: 'Left Shoulder', group: 'torso' },
  { id: 12, name: 'Right Shoulder', group: 'torso' },
  { id: 13, name: 'Left Elbow', group: 'arms' },
  { id: 14, name: 'Right Elbow', group: 'arms' },
  { id: 15, name: 'Left Wrist', group: 'arms' },
  { id: 16, name: 'Right Wrist', group: 'arms' },
  { id: 17, name: 'Left Pinky', group: 'arms' },
  { id: 18, name: 'Right Pinky', group: 'arms' },
  { id: 19, name: 'Left Index', group: 'arms' },
  { id: 20, name: 'Right Index', group: 'arms' },
  { id: 21, name: 'Left Thumb', group: 'arms' },
  { id: 22, name: 'Right Thumb', group: 'arms' },
  { id: 23, name: 'Left Hip', group: 'torso' },
  { id: 24, name: 'Right Hip', group: 'torso' },
  { id: 25, name: 'Left Knee', group: 'legs' },
  { id: 26, name: 'Right Knee', group: 'legs' },
  { id: 27, name: 'Left Ankle', group: 'legs' },
  { id: 28, name: 'Right Ankle', group: 'legs' },
  { id: 29, name: 'Left Heel', group: 'feet' },
  { id: 30, name: 'Right Heel', group: 'feet' },
  { id: 31, name: 'Left Foot Index', group: 'feet' },
  { id: 32, name: 'Right Foot Index', group: 'feet' },
];

// Clean Anatomical Bone Connections (eliminates overlapping facial polygon spiderweb)
// Landmark 0 (Head/Nose) connects cleanly to shoulders 11 & 12 as the neck
export const CLEAN_POSE_CONNECTIONS: [number, number][] = [
  // Neck connection: Head center (0) to shoulders (11, 12)
  [0, 11],
  [0, 12],
  // Torso frame
  [11, 12],
  [11, 23],
  [12, 24],
  [23, 24],
  // Left arm
  [11, 13],
  [13, 15],
  [15, 17],
  [15, 19],
  [15, 21],
  [17, 19],
  // Right arm
  [12, 14],
  [14, 16],
  [16, 18],
  [16, 20],
  [16, 22],
  [18, 20],
  // Left leg
  [23, 25],
  [25, 27],
  [27, 29],
  [27, 31],
  [29, 31],
  // Right leg
  [24, 26],
  [26, 28],
  [28, 30],
  [28, 32],
  [30, 32],
];

// 3D coordinates for the 3 distinct poses: Normal, Possible Fall, Lying Down
const POSES_3D: Record<DemoPoseType, [number, number, number][]> = {
  // Upright standing pose with natural relaxed stance
  normal: [
    [0.0, 1.74, 0.04],    // 0 Nose / Cranial center
    [-0.03, 1.77, 0.03],  // 1 L Eye In
    [-0.05, 1.77, 0.03],  // 2 L Eye
    [-0.07, 1.77, 0.02],  // 3 L Eye Out
    [0.03, 1.77, 0.03],   // 4 R Eye In
    [0.05, 1.77, 0.03],   // 5 R Eye
    [0.07, 1.77, 0.02],   // 6 R Eye Out
    [-0.10, 1.73, -0.04], // 7 L Ear
    [0.10, 1.73, -0.04],  // 8 R Ear
    [-0.03, 1.68, 0.03],  // 9 Mouth L
    [0.03, 1.68, 0.03],   // 10 Mouth R
    [-0.22, 1.50, 0.0],   // 11 L Shoulder
    [0.22, 1.50, 0.0],    // 12 R Shoulder
    [-0.28, 1.18, 0.03],  // 13 L Elbow
    [0.28, 1.18, 0.03],   // 14 R Elbow
    [-0.30, 0.88, 0.05],  // 15 L Wrist
    [0.30, 0.88, 0.05],   // 16 R Wrist
    [-0.33, 0.80, 0.05],  // 17 L Pinky
    [0.33, 0.80, 0.05],   // 18 R Pinky
    [-0.32, 0.78, 0.06],  // 19 L Index
    [0.32, 0.78, 0.06],   // 20 R Index
    [-0.30, 0.82, 0.06],  // 21 L Thumb
    [0.30, 0.82, 0.06],   // 22 R Thumb
    [-0.14, 0.96, 0.0],   // 23 L Hip
    [0.14, 0.96, 0.0],    // 24 R Hip
    [-0.15, 0.54, 0.03],  // 25 L Knee
    [0.15, 0.54, 0.03],   // 26 R Knee
    [-0.16, 0.12, 0.0],   // 27 L Ankle
    [0.16, 0.12, 0.0],    // 28 R Ankle
    [-0.16, 0.08, -0.07], // 29 L Heel
    [0.16, 0.08, -0.07],  // 30 R Heel
    [-0.16, 0.04, 0.14],  // 31 L Foot Index
    [0.16, 0.04, 0.14],   // 32 R Foot Index
  ],

  // Possible Fall: Stumbling forward, knees buckling, arms bracing downwards
  'possible-fall': [
    [-0.08, 1.14, 0.44],  // 0 Nose / Cranial center
    [-0.12, 1.17, 0.42],  // 1 L Eye In
    [-0.15, 1.16, 0.41],  // 2 L Eye
    [-0.18, 1.15, 0.40],  // 3 L Eye Out
    [-0.05, 1.18, 0.43],  // 4 R Eye In
    [-0.02, 1.17, 0.42],  // 5 R Eye
    [0.01, 1.16, 0.41],   // 6 R Eye Out
    [-0.20, 1.10, 0.32],  // 7 L Ear
    [0.04, 1.12, 0.33],   // 8 R Ear
    [-0.11, 1.07, 0.40],  // 9 Mouth L
    [-0.04, 1.08, 0.41],  // 10 Mouth R
    [-0.30, 0.96, 0.30],  // 11 L Shoulder
    [0.10, 1.02, 0.28],   // 12 R Shoulder
    [-0.48, 0.78, 0.42],  // 13 L Elbow
    [0.26, 0.76, 0.20],   // 14 R Elbow
    [-0.56, 0.52, 0.56],  // 15 L Wrist
    [0.36, 0.50, 0.10],   // 16 R Wrist
    [-0.60, 0.46, 0.58],  // 17 L Pinky
    [0.38, 0.45, 0.08],   // 18 R Pinky
    [-0.58, 0.44, 0.60],  // 19 L Index
    [0.39, 0.44, 0.09],   // 20 R Index
    [-0.54, 0.48, 0.57],  // 21 L Thumb
    [0.35, 0.47, 0.10],   // 22 R Thumb
    [-0.22, 0.64, 0.06],  // 23 L Hip
    [0.04, 0.68, 0.0],    // 24 R Hip
    [-0.34, 0.34, 0.22],  // 25 L Knee
    [0.10, 0.36, -0.10],  // 26 R Knee
    [-0.40, 0.10, 0.08],  // 27 L Ankle
    [0.16, 0.12, -0.20],  // 28 R Ankle
    [-0.42, 0.08, 0.0],   // 29 L Heel
    [0.18, 0.10, -0.26],  // 30 R Heel
    [-0.38, 0.04, 0.18],  // 31 L Foot Index
    [0.14, 0.05, -0.12],  // 32 R Foot Index
  ],

  // Lying Down: Completely collapsed horizontally along the floor plane
  'lying-down': [
    [-0.88, 0.15, 0.06],  // 0 Nose / Cranial center
    [-0.89, 0.17, 0.04],  // 1 L Eye In
    [-0.91, 0.17, 0.03],  // 2 L Eye
    [-0.93, 0.16, 0.02],  // 3 L Eye Out
    [-0.87, 0.18, 0.07],  // 4 R Eye In
    [-0.88, 0.18, 0.09],  // 5 R Eye
    [-0.89, 0.17, 0.11],  // 6 R Eye Out
    [-0.94, 0.13, -0.03], // 7 L Ear
    [-0.85, 0.15, 0.15],  // 8 R Ear
    [-0.85, 0.12, 0.04],  // 9 Mouth L
    [-0.83, 0.13, 0.07],  // 10 Mouth R
    [-0.62, 0.16, -0.18], // 11 L Shoulder
    [-0.60, 0.16, 0.20],  // 12 R Shoulder
    [-0.68, 0.11, -0.38], // 13 L Elbow
    [-0.47, 0.13, 0.36],  // 14 R Elbow
    [-0.76, 0.09, -0.50], // 15 L Wrist
    [-0.34, 0.10, 0.46],  // 16 R Wrist
    [-0.80, 0.07, -0.54], // 17 L Pinky
    [-0.30, 0.08, 0.50],  // 18 R Pinky
    [-0.81, 0.07, -0.53], // 19 L Index
    [-0.29, 0.08, 0.49],  // 20 R Index
    [-0.77, 0.08, -0.50], // 21 L Thumb
    [-0.32, 0.09, 0.45],  // 22 R Thumb
    [-0.10, 0.14, -0.14], // 23 L Hip
    [-0.08, 0.14, 0.14],  // 24 R Hip
    [0.32, 0.12, -0.18],  // 25 L Knee
    [0.34, 0.12, 0.17],   // 26 R Knee
    [0.74, 0.10, -0.16],  // 27 L Ankle
    [0.76, 0.10, 0.15],   // 28 R Ankle
    [0.72, 0.09, -0.21],  // 29 L Heel
    [0.74, 0.09, 0.10],   // 30 R Heel
    [0.84, 0.07, -0.11],  // 31 L Foot Index
    [0.86, 0.07, 0.19],   // 32 R Foot Index
  ],
};

// Dynamic Status Theme Configuration:
// Normal: Green | Possible Fall: Amber / Yellow | Lying Down: Red
export interface StatusTheme {
  name: string;
  sphereHex: number;
  sphereEmissive: number;
  boneHex: number;
  boneEmissive: number;
  accentHex: number;
  badgeBg: string;
  dotColor: string;
  textColor: string;
}

export function getStatusTheme(poseMode: DemoPoseType): StatusTheme {
  switch (poseMode) {
    case 'possible-fall':
      return {
        name: 'Possible Fall',
        sphereHex: 0x00f5ff, // Bright Cyan landmark material
        sphereEmissive: 0x00c4ec,
        boneHex: 0xf59e0b, // Amber thick bones
        boneEmissive: 0xb45309,
        accentHex: 0xf59e0b,
        badgeBg: 'bg-amber-950/90 border-amber-500 text-amber-200',
        dotColor: 'bg-amber-400',
        textColor: 'text-amber-300',
      };
    case 'lying-down':
      return {
        name: 'Lying Down',
        sphereHex: 0x00f5ff, // Bright Cyan landmark material
        sphereEmissive: 0x00c4ec,
        boneHex: 0xef4444, // Red thick bones
        boneEmissive: 0x991b1b,
        accentHex: 0xef4444,
        badgeBg: 'bg-rose-950/90 border-rose-500 text-rose-200',
        dotColor: 'bg-rose-400',
        textColor: 'text-rose-300',
      };
    case 'normal':
    default:
      return {
        name: 'Normal',
        sphereHex: 0x00f5ff, // Bright Cyan landmark material
        sphereEmissive: 0x00b4d8,
        boneHex: 0x0284c7, // Electric cyan-blue thick bones
        boneEmissive: 0x0369a1,
        accentHex: 0x00f5ff,
        badgeBg: 'bg-cyan-950/90 border-cyan-500 text-cyan-200',
        dotColor: 'bg-cyan-400',
        textColor: 'text-cyan-300',
      };
  }
}

export const Skeleton3DViewer: React.FC<Skeleton3DViewerProps> = ({
  status,
  externalPose,
  onPoseChange,
  cameraConnected = true,
  rawLandmarks,
  forcedError = null,
  onClearForcedError,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // States
  const [selectedPose, setSelectedPose] = useState<DemoPoseType>('normal');
  // Landmark labels toggle (shows indexes 0 through 32 beside points and important landmark names)
  const [showLandmarkLabels, setShowLandmarkLabels] = useState<boolean>(true);
  const [activeGroupHighlight, setActiveGroupHighlight] = useState<string | null>(null);
  const [isLegendOpen, setIsLegendOpen] = useState<boolean>(true);
  const [clickedLandmarkId, setClickedLandmarkId] = useState<number | null>(null);

  const [hoveredLandmark, setHoveredLandmark] = useState<{
    id: number;
    name: string;
    group: string;
    coords: [number, number, number];
    screenX: number;
    screenY: number;
  } | null>(null);

  // 2D Projected coordinates for landmark number badges (visible on hover/click or toggle)
  const [projectedLabels, setProjectedLabels] = useState<
    { id: number; x: number; y: number; visible: boolean }[]
  >([]);

  // Determine active pose target
  const activePose = useMemo<DemoPoseType>(() => {
    if (externalPose) return externalPose;
    if (status === 'Possible Fall' || status === 'Checking Response') return 'possible-fall';
    if (status === 'Alert Sent' || status === 'Escalated') return 'lying-down';
    return selectedPose;
  }, [externalPose, selectedPose, status]);

  // Active theme based on pose mode: Green for Normal, Amber for Possible Fall, Red for Lying Down
  const activeTheme = useMemo(() => getStatusTheme(activePose), [activePose]);

  // Real-time landmark validation and error handling
  const landmarkValidation = useMemo(() => {
    if (forcedError === 'missing') {
      return validateAndSanitizeLandmarks(null);
    }
    if (forcedError === 'fewer_landmarks') {
      const truncated = POSES_3D[activePose].slice(0, 14).map((c, i) => ({
        id: i,
        x: c[0],
        y: c[1],
        z: c[2],
        visibility: 0.9,
      }));
      return validateAndSanitizeLandmarks(truncated);
    }
    if (forcedError === 'invalid_coords') {
      const corrupted = POSES_3D[activePose].map((c, i) => ({
        id: i,
        x: i % 2 === 0 ? NaN : c[0],
        y: i % 3 === 0 ? undefined : c[1],
        z: i % 4 === 0 ? 'corrupted' : c[2],
        visibility: undefined,
      }));
      return validateAndSanitizeLandmarks(corrupted);
    }
    if (rawLandmarks !== undefined) {
      return validateAndSanitizeLandmarks(rawLandmarks);
    }
    // Default synthetic input
    const syntheticPoints = POSES_3D[activePose].map((c, i) => ({
      id: i,
      x: c[0],
      y: c[1],
      z: c[2],
      visibility: 1.0,
      name: LANDMARKS_META[i]?.name,
    }));
    return validateAndSanitizeLandmarks(syntheticPoints);
  }, [forcedError, rawLandmarks, activePose]);

  const isPoseDataUnavailable = !landmarkValidation.isValid || landmarkValidation.isPoseDataUnavailable;

  // Sync state when parent status changes
  useEffect(() => {
    if (status === 'Possible Fall' || status === 'Checking Response') {
      setSelectedPose('possible-fall');
    } else if (status === 'Alert Sent' || status === 'Escalated') {
      setSelectedPose('lying-down');
    } else if (status === 'Normal' || status === 'Resolved') {
      setSelectedPose('normal');
    }
  }, [status]);

  const handlePoseSelect = (pose: DemoPoseType) => {
    setSelectedPose(pose);
    if (onPoseChange) onPoseChange(pose);
  };

  // Three.js instances ref
  const threeRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    controls: OrbitControls;
    currentCoords: [number, number, number][];
    targetCoords: [number, number, number][];
    sphereMeshes: THREE.Mesh[];
    boneCylinders: THREE.Mesh[];
    keyLights: {
      ambient: THREE.AmbientLight;
      dirLight: THREE.DirectionalLight;
      rimLight: THREE.DirectionalLight;
      pointAccent: THREE.PointLight;
    };
    shadowPlane: THREE.Mesh;
    contactShadowDisc: THREE.Mesh;
    floorRingMat: THREE.MeshBasicMaterial;
    raycaster: THREE.Raycaster;
    mouse: THREE.Vector2;
    activeThemeRef: StatusTheme;
    cameraTargetPos: THREE.Vector3;
    cameraTargetLookAt: THREE.Vector3;
    isTransitioningCamera: boolean;
  } | null>(null);

  // Helper to compute bounding box of landmarks
  const computeActiveBounds = useCallback((coords: [number, number, number][]) => {
    const box = new THREE.Box3();
    for (let i = 0; i < coords.length; i++) {
      box.expandByPoint(new THREE.Vector3(coords[i][0], coords[i][1], coords[i][2]));
    }
    return box;
  }, []);

  // Auto-framing algorithm: computes bounding box and smoothly frames skeleton with generous padding
  const autoFrameCamera = useCallback(
    (targetPoseType: DemoPoseType = activePose, instant: boolean = false) => {
      const ref = threeRef.current;
      if (!ref) return;

      const coords = POSES_3D[targetPoseType];
      const box = computeActiveBounds(coords);
      const center = new THREE.Vector3();
      box.getCenter(center);
      const size = new THREE.Vector3();
      box.getSize(size);

      // Desired framing distance with optical padding
      const fovRad = (ref.camera.fov * Math.PI) / 180;
      const maxDim = Math.max(size.y, size.x / ref.camera.aspect, size.z * 0.7);
      const paddingFactor = 1.35; // Fills ~75-80% of viewport
      const distance = Math.max(1.35, Math.min(3.4, (maxDim / (2 * Math.tan(fovRad / 2))) * paddingFactor));

      // Determine camera offset direction according to pose archetype
      let camOffset: THREE.Vector3;
      if (targetPoseType === 'lying-down') {
        // Collapsed on floor: angled isometric view closer to the ground
        camOffset = new THREE.Vector3(1.1, 1.4, 2.1).normalize().multiplyScalar(distance);
      } else if (targetPoseType === 'possible-fall') {
        // Forward stumbling: front-three-quarter view
        camOffset = new THREE.Vector3(0.9, 0.9, 2.4).normalize().multiplyScalar(distance);
      } else {
        // Normal standing upright
        camOffset = new THREE.Vector3(0.6, 0.5, 2.5).normalize().multiplyScalar(distance);
      }

      const newCamPos = center.clone().add(camOffset);

      if (instant) {
        ref.camera.position.copy(newCamPos);
        ref.controls.target.copy(center);
        ref.controls.update();
      } else {
        ref.cameraTargetPos.copy(newCamPos);
        ref.cameraTargetLookAt.copy(center);
        ref.isTransitioningCamera = true;
      }
    },
    [activePose, computeActiveBounds]
  );

  // Dynamically update materials and lighting to match active status color (Green -> Amber -> Red)
  useEffect(() => {
    if (threeRef.current) {
      threeRef.current.activeThemeRef = activeTheme;
      const { sphereMeshes, boneCylinders, keyLights, floorRingMat } = threeRef.current;

      // Update spheres
      sphereMeshes.forEach((mesh, idx) => {
        if (idx >= 1 && idx <= 10) return; // Face details are hidden
        const mat = mesh.material as THREE.MeshStandardMaterial;
        mat.color.setHex(activeTheme.sphereHex);
        mat.emissive.setHex(activeTheme.sphereEmissive);
        mat.emissiveIntensity = 1.0;

        const glow = mesh.getObjectByName('glowHalo') as THREE.Mesh;
        if (glow) {
          const glowMat = glow.material as THREE.MeshBasicMaterial;
          glowMat.color.setHex(activeTheme.sphereHex);
        }
      });

      // Update bone cylinders
      boneCylinders.forEach((cyl) => {
        const mat = cyl.material as THREE.MeshStandardMaterial;
        mat.color.setHex(activeTheme.boneHex);
        mat.emissive.setHex(activeTheme.boneEmissive);
        mat.emissiveIntensity = 0.65;
      });

      // Floor beacon ring
      floorRingMat.color.setHex(activeTheme.accentHex);

      // Key light color accent
      keyLights.pointAccent.color.setHex(activeTheme.sphereHex);
      keyLights.pointAccent.intensity = activePose === 'normal' ? 2.4 : 3.2;
    }
  }, [activeTheme, activePose]);

  // Setup Three.js scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 540;

    // 1. Scene: Dark high-contrast background
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617); // Dark high-contrast deep obsidian

    // 2. Camera: Centered and auto-framed on the skeleton
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0.6, 1.4, 2.8);

    // 3. WebGL Renderer with Soft Shadow Mapping enabled
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Beautiful soft contact shadows
    renderer.domElement.style.touchAction = 'none'; // Critical for touch pinch-to-zoom
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. OrbitControls: Mouse wheel zoom on desktop + Pinch-to-zoom on touch
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.target.set(0, 1.05, 0); // Centered on torso/hips centroid
    controls.enableZoom = true; // Enables mouse wheel and touch pinch zoom
    controls.zoomSpeed = 1.15;
    controls.minDistance = 0.8;
    controls.maxDistance = 5.5;
    controls.maxPolarAngle = Math.PI / 2 + 0.08; // Floor boundary
    controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: THREE.TOUCH.DOLLY_PAN, // DOLLY enables two-finger pinch-to-zoom
    };

    // 5. Lighting: Directional Key light casting shadows + Soft fill + Rim light for 3D depth
    const ambient = new THREE.AmbientLight(0xffffff, 0.55);
    scene.add(ambient);

    // Main directional key light positioned to cast dynamic soft shadows beneath the figure
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.8);
    dirLight.position.set(2.2, 4.2, 2.6);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 9;
    dirLight.shadow.camera.left = -1.8;
    dirLight.shadow.camera.right = 1.8;
    dirLight.shadow.camera.top = 2.4;
    dirLight.shadow.camera.bottom = -0.6;
    dirLight.shadow.bias = -0.0008;
    dirLight.shadow.radius = 3.0; // Soft shadow blur
    scene.add(dirLight);

    // Subtle rear-left cyan rim light to cleanly outline limbs against dark background
    const rimLight = new THREE.DirectionalLight(0x00f5ff, 0.8);
    rimLight.position.set(-2.5, 2.5, -2.5);
    scene.add(rimLight);

    // Accent point light
    const pointAccent = new THREE.PointLight(activeTheme.sphereHex, 2.5, 10);
    pointAccent.position.set(0, 2.2, 1.8);
    scene.add(pointAccent);

    // 6. Floor & Shadow Receivers: Subtle Grid + Shadow plane + Coordinate-Axis Indicator
    // Subtle ground grid
    const gridHelper = new THREE.GridHelper(6, 24, 0x334155, 0x1e293b);
    gridHelper.position.y = 0;
    scene.add(gridHelper);

    // Small coordinate-axis indicator on the floor corner for 3D spatial reference
    const axisGroup = new THREE.Group();
    axisGroup.position.set(-1.5, 0.012, -1.5);

    const axesHelper = new THREE.AxesHelper(0.42);
    axisGroup.add(axesHelper);

    // Distinct colored indicator spheres at the axis tips
    const axisTipGeo = new THREE.SphereGeometry(0.026, 12, 12);
    // +X (Red: Lateral)
    const xTip = new THREE.Mesh(axisTipGeo, new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    xTip.position.set(0.42, 0, 0);
    axisGroup.add(xTip);

    // +Y (Green: Elevation / Height)
    const yTip = new THREE.Mesh(axisTipGeo, new THREE.MeshBasicMaterial({ color: 0x10b981 }));
    yTip.position.set(0, 0.42, 0);
    axisGroup.add(yTip);

    // +Z (Cyan/Blue: Sagittal Depth)
    const zTip = new THREE.Mesh(axisTipGeo, new THREE.MeshBasicMaterial({ color: 0x06b6d4 }));
    zTip.position.set(0, 0, 0.42);
    axisGroup.add(zTip);

    scene.add(axisGroup);

    // Subtle floor shadow receiver plane
    const shadowPlaneGeo = new THREE.PlaneGeometry(6.5, 6.5);
    const shadowPlaneMat = new THREE.ShadowMaterial({ opacity: 0.52 });
    const shadowPlane = new THREE.Mesh(shadowPlaneGeo, shadowPlaneMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.001;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    // Dynamic contact shadow disc directly underneath the skeleton's ground projection
    const contactDiscGeo = new THREE.RingGeometry(0, 0.45, 32);
    const contactDiscMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.45,
      side: THREE.DoubleSide,
    });
    const contactShadowDisc = new THREE.Mesh(contactDiscGeo, contactDiscMat);
    contactShadowDisc.rotation.x = -Math.PI / 2;
    contactShadowDisc.position.set(0, 0.002, 0);
    scene.add(contactShadowDisc);

    // Concentric ground radar beacon
    const ringGeo = new THREE.RingGeometry(0.58, 0.61, 48);
    const floorRingMat = new THREE.MeshBasicMaterial({
      color: activeTheme.accentHex,
      opacity: 0.4,
      transparent: true,
      side: THREE.DoubleSide,
    });
    const floorRing = new THREE.Mesh(ringGeo, floorRingMat);
    floorRing.rotation.x = Math.PI / 2;
    floorRing.position.y = 0.004;
    scene.add(floorRing);

    // 7. Spherical Landmark Markers with Bright Cyan Material & Soft Glow Effect
    // - Landmark sphere radius strictly between 0.05 and 0.08
    // - Larger spheres for shoulders (11,12), hips (23,24), knees (25,26), ankles (27,28)
    // - Bright cyan landmark material (0x00f5ff)
    // - Attached soft glow halo mesh for stable volumetric glow effect
    // - Indices 1-10 hidden to avoid face cluster
    const sphereMeshes: THREE.Mesh[] = [];
    const currentCoords = POSES_3D[activePose].map((c) => [...c] as [number, number, number]);
    const targetCoords = POSES_3D[activePose].map((c) => [...c] as [number, number, number]);

    for (let i = 0; i < 33; i++) {
      const isFaceDetail = i >= 1 && i <= 10;
      const radius = getLandmarkRadius(i);
      const sphereGeo = new THREE.SphereGeometry(radius, 24, 24);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: activeTheme.sphereHex,
        emissive: activeTheme.sphereEmissive,
        emissiveIntensity: 1.0,
        roughness: 0.15,
        metalness: 0.25,
      });

      const mesh = new THREE.Mesh(sphereGeo, sphereMat);
      mesh.position.set(currentCoords[i][0], currentCoords[i][1], currentCoords[i][2]);
      mesh.userData = { landmarkId: i, meta: LANDMARKS_META[i] };
      mesh.castShadow = true;

      // Soft glow effect: Attached concentric additive-blending halo sphere
      const glowGeo = new THREE.SphereGeometry(radius * 1.36, 16, 16);
      const glowMat = new THREE.MeshBasicMaterial({
        color: activeTheme.sphereHex,
        transparent: true,
        opacity: 0.28,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.BackSide,
      });
      const glowMesh = new THREE.Mesh(glowGeo, glowMat);
      glowMesh.name = 'glowHalo';
      mesh.add(glowMesh);

      mesh.visible = true;

      scene.add(mesh);
      sphereMeshes.push(mesh);
    }

    // 8. Thick Visible Volumetric Cylindrical Bone Connectors
    // Using 3D cylinders with thickness between 0.018 and 0.026
    const boneCylinders: THREE.Mesh[] = [];
    const boneMaterial = new THREE.MeshStandardMaterial({
      color: activeTheme.boneHex,
      emissive: activeTheme.boneEmissive,
      emissiveIntensity: 0.65,
      roughness: 0.3,
      metalness: 0.35,
    });

    const yAxis = new THREE.Vector3(0, 1, 0);

    for (let c = 0; c < CLEAN_POSE_CONNECTIONS.length; c++) {
      const [idx1, idx2] = CLEAN_POSE_CONNECTIONS[c];
      const radius = getBoneRadius(idx1, idx2);
      const boneGeo = new THREE.CylinderGeometry(radius, radius, 1, 16);
      const cylinder = new THREE.Mesh(boneGeo, boneMaterial.clone());
      cylinder.castShadow = true;
      scene.add(cylinder);
      boneCylinders.push(cylinder);
    }

    // Function to update the bone cylinders between joints
    const updateBoneCylinders = () => {
      for (let i = 0; i < CLEAN_POSE_CONNECTIONS.length; i++) {
        const [idx1, idx2] = CLEAN_POSE_CONNECTIONS[i];
        const p1 = currentCoords[idx1] || SAFE_DEFAULT_COORDINATES[idx1] || [0, 0, 0];
        const p2 = currentCoords[idx2] || SAFE_DEFAULT_COORDINATES[idx2] || [0, 0, 0];
        const cyl = boneCylinders[i];
        if (!cyl) continue;

        const x1 = Number.isFinite(p1[0]) ? p1[0] : 0;
        const y1 = Number.isFinite(p1[1]) ? p1[1] : 0;
        const z1 = Number.isFinite(p1[2]) ? p1[2] : 0;

        const x2 = Number.isFinite(p2[0]) ? p2[0] : 0;
        const y2 = Number.isFinite(p2[1]) ? p2[1] : 0;
        const z2 = Number.isFinite(p2[2]) ? p2[2] : 0;

        const v1 = new THREE.Vector3(x1, y1, z1);
        const v2 = new THREE.Vector3(x2, y2, z2);
        const distance = v1.distanceTo(v2);

        // Midpoint
        const mid = v1.clone().add(v2).multiplyScalar(0.5);
        cyl.position.copy(mid);
        cyl.scale.set(1, Math.max(0.001, distance), 1);

        // Orient along bone direction safely
        const dir = v2.clone().sub(v1);
        if (dir.lengthSq() > 0.00001) {
          dir.normalize();
          const quat = new THREE.Quaternion();
          quat.setFromUnitVectors(yAxis, dir);
          cyl.quaternion.copy(quat);
        }
      }
    };

    updateBoneCylinders();

    // Raycaster for hover/click interaction
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    threeRef.current = {
      scene,
      camera,
      renderer,
      controls,
      currentCoords,
      targetCoords,
      sphereMeshes,
      boneCylinders,
      keyLights: { ambient, dirLight, rimLight, pointAccent },
      shadowPlane,
      contactShadowDisc,
      floorRingMat,
      raycaster,
      mouse,
      activeThemeRef: activeTheme,
      cameraTargetPos: camera.position.clone(),
      cameraTargetLookAt: controls.target.clone(),
      isTransitioningCamera: false,
    };

    // Auto-frame immediately on initial mount
    autoFrameCamera(activePose, true);

    // Animation Loop
    let animationFrameId: number;
    let frameCounter = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const data = threeRef.current;
      if (data) {
        // Coordinate interpolation (Smooth Animation between poses)
        let maxDelta = 0;
        const lerpSpeed = 0.088;
        for (let i = 0; i < 33; i++) {
          const curr = data.currentCoords[i];
          const tgt = data.targetCoords[i] || SAFE_DEFAULT_COORDINATES[i] || [0, 1.2, 0];
          const fallback = SAFE_DEFAULT_COORDINATES[i] || [0, 1.2, 0];

          if (!Number.isFinite(curr[0])) curr[0] = fallback[0];
          if (!Number.isFinite(curr[1])) curr[1] = fallback[1];
          if (!Number.isFinite(curr[2])) curr[2] = fallback[2];

          const tgtX = Number.isFinite(tgt[0]) ? tgt[0] : fallback[0];
          const tgtY = Number.isFinite(tgt[1]) ? tgt[1] : fallback[1];
          const tgtZ = Number.isFinite(tgt[2]) ? tgt[2] : fallback[2];

          const dx = tgtX - curr[0];
          const dy = tgtY - curr[1];
          const dz = tgtZ - curr[2];
          curr[0] += dx * lerpSpeed;
          curr[1] += dy * lerpSpeed;
          curr[2] += dz * lerpSpeed;
          maxDelta = Math.max(maxDelta, Math.abs(dx) + Math.abs(dy) + Math.abs(dz));

          if (data.sphereMeshes[i]) {
            data.sphereMeshes[i].position.set(curr[0], curr[1], curr[2]);
          }
        }

        updateBoneCylinders();

        // Update dynamic contact shadow disc underneath the skeleton
        const hip1 = data.currentCoords[23] || SAFE_DEFAULT_COORDINATES[23];
        const hip2 = data.currentCoords[24] || SAFE_DEFAULT_COORDINATES[24];
        const midHipsX = ((Number.isFinite(hip1[0]) ? hip1[0] : 0) + (Number.isFinite(hip2[0]) ? hip2[0] : 0)) * 0.5;
        const midHipsZ = ((Number.isFinite(hip1[2]) ? hip1[2] : 0) + (Number.isFinite(hip2[2]) ? hip2[2] : 0)) * 0.5;
        const midHipsY = ((Number.isFinite(hip1[1]) ? hip1[1] : 0) + (Number.isFinite(hip2[1]) ? hip2[1] : 0)) * 0.5;
        data.contactShadowDisc.position.x = midHipsX;
        data.contactShadowDisc.position.z = midHipsZ;
        const discScale = Math.max(0.6, Math.min(2.0, 1.0 + (1.2 - midHipsY) * 0.8));
        data.contactShadowDisc.scale.set(discScale, discScale, discScale);

        // Smooth camera transitions for Auto-Framing
        if (data.isTransitioningCamera) {
          data.camera.position.lerp(data.cameraTargetPos, 0.08);
          data.controls.target.lerp(data.cameraTargetLookAt, 0.08);
          if (
            data.camera.position.distanceTo(data.cameraTargetPos) < 0.02 &&
            data.controls.target.distanceTo(data.cameraTargetLookAt) < 0.02
          ) {
            data.isTransitioningCamera = false;
          }
        }

        // Natural respiratory micro-motion in normal standing pose
        if (activePose === 'normal' && maxDelta < 0.015) {
          const t = performance.now() * 0.002;
          const chestDelta = Math.sin(t) * 0.0025;
          data.sphereMeshes[11].position.y += chestDelta;
          data.sphereMeshes[12].position.y += chestDelta;
          data.sphereMeshes[0].position.y += chestDelta * 0.5;
        }

        data.controls.update();
        data.renderer.render(data.scene, data.camera);

        // Project 3D coordinates to 2D screen positions for landmark number labels
        frameCounter++;
        if (frameCounter % 2 === 0 && container) {
          const rect = container.getBoundingClientRect();
          const labels: { id: number; x: number; y: number; visible: boolean }[] = [];
          const tempVec = new THREE.Vector3();

          // Project all landmark indexes 0 through 32
          for (let i = 0; i < 33; i++) {
            const pos = data.currentCoords[i];
            tempVec.set(pos[0], pos[1], pos[2]);
            tempVec.project(data.camera);

            const inFront = tempVec.z < 1.0;
            const screenX = ((tempVec.x + 1) * rect.width) / 2;
            const screenY = ((-tempVec.y + 1) * rect.height) / 2;

            labels.push({
              id: i,
              x: screenX,
              y: screenY,
              visible: inFront && screenX >= 0 && screenX <= rect.width && screenY >= 0 && screenY <= rect.height,
            });
          }
          setProjectedLabels(labels);
        }
      }
    };

    animate();

    // Responsive Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        if (newW > 0 && newH > 0) {
          camera.aspect = newW / newH;
          camera.updateProjectionMatrix();
          renderer.setSize(newW, newH);
        }
      }
    });

    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      controls.dispose();
      renderer.dispose();
      if (container) container.innerHTML = '';
    };
  }, []); // Mount once

  // Update target coordinates and trigger auto-framing whenever activePose changes
  useEffect(() => {
    if (!threeRef.current) return;
    const sanitizedList = landmarkValidation.sanitizedLandmarks;
    if (sanitizedList && sanitizedList.length >= 33) {
      for (let i = 0; i < 33; i++) {
        const item = sanitizedList[i];
        const defaultPt = SAFE_DEFAULT_COORDINATES[i] || [0, 1.2, 0];
        threeRef.current.targetCoords[i] = [
          item && Number.isFinite(item.x) ? item.x : defaultPt[0],
          item && Number.isFinite(item.y) ? item.y : defaultPt[1],
          item && Number.isFinite(item.z) ? item.z : defaultPt[2],
        ];
      }
    }
    // Smoothly auto-frame camera to fit the newly selected pose!
    autoFrameCamera(activePose, false);
  }, [activePose, autoFrameCamera, landmarkValidation]);

  // Pointer move handler for landmark hover & interaction
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const container = mountRef.current;
    const ref = threeRef.current;
    if (!container || !ref) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    ref.mouse.x = x;
    ref.mouse.y = y;
    ref.raycaster.setFromCamera(ref.mouse, ref.camera);

    // Only raycast visible spheres
    const visibleSpheres = ref.sphereMeshes.filter((s) => s.visible);
    const intersects = ref.raycaster.intersectObjects(visibleSpheres, false);

    if (intersects.length > 0) {
      const hit = intersects[0].object as THREE.Mesh;
      const id = hit.userData.landmarkId as number;
      const meta = hit.userData.meta as LandmarkMeta;
      const p = ref.currentCoords[id];

      // Highlight hit point
      ref.sphereMeshes.forEach((s, idx) => {
        if (!s.visible) return;
        const mat = s.material as THREE.MeshStandardMaterial;
        if (idx === id) {
          mat.color.setHex(0xfacc15); // amber highlight on hover
          mat.emissive.setHex(0xf59e0b);
          mat.emissiveIntensity = 1.8;
          s.scale.set(1.4, 1.4, 1.4);
        } else if (clickedLandmarkId !== idx && (!activeGroupHighlight || meta.group !== activeGroupHighlight)) {
          mat.color.setHex(ref.activeThemeRef.sphereHex);
          mat.emissive.setHex(ref.activeThemeRef.sphereEmissive);
          mat.emissiveIntensity = 0.95;
          s.scale.set(1.0, 1.0, 1.0);
        }
      });

      setHoveredLandmark({
        id,
        name: meta.name,
        group: meta.group,
        coords: [p[0], p[1], p[2]],
        screenX: e.clientX - rect.left,
        screenY: e.clientY - rect.top,
      });
    } else {
      if (hoveredLandmark !== null) {
        ref.sphereMeshes.forEach((s, idx) => {
          if (!s.visible) return;
          const mat = s.material as THREE.MeshStandardMaterial;
          if (clickedLandmarkId === idx) {
            mat.color.setHex(0x38bdf8);
            mat.emissive.setHex(0x0284c7);
            s.scale.set(1.3, 1.3, 1.3);
          } else {
            mat.color.setHex(ref.activeThemeRef.sphereHex);
            mat.emissive.setHex(ref.activeThemeRef.sphereEmissive);
            mat.emissiveIntensity = 0.95;
            s.scale.set(1.0, 1.0, 1.0);
          }
        });
        setHoveredLandmark(null);
      }
    }
  };

  const handlePointerLeave = () => {
    const ref = threeRef.current;
    if (ref) {
      ref.sphereMeshes.forEach((s, idx) => {
        if (!s.visible) return;
        const mat = s.material as THREE.MeshStandardMaterial;
        if (clickedLandmarkId === idx) {
          mat.color.setHex(0x38bdf8);
          mat.emissive.setHex(0x0284c7);
          s.scale.set(1.3, 1.3, 1.3);
        } else {
          mat.color.setHex(ref.activeThemeRef.sphereHex);
          mat.emissive.setHex(ref.activeThemeRef.sphereEmissive);
          mat.emissiveIntensity = 0.95;
          s.scale.set(1.0, 1.0, 1.0);
        }
      });
    }
    setHoveredLandmark(null);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = mountRef.current;
    const ref = threeRef.current;
    if (!container || !ref) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    ref.mouse.x = x;
    ref.mouse.y = y;
    ref.raycaster.setFromCamera(ref.mouse, ref.camera);

    const visibleSpheres = ref.sphereMeshes.filter((s) => s.visible);
    const intersects = ref.raycaster.intersectObjects(visibleSpheres, false);

    if (intersects.length > 0) {
      const hit = intersects[0].object as THREE.Mesh;
      const id = hit.userData.landmarkId as number;
      setClickedLandmarkId(clickedLandmarkId === id ? null : id);
    } else {
      setClickedLandmarkId(null);
    }
  };

  // View Presets: Front View, Side View, Top View, and Reset
  const setCameraPreset = (preset: CameraViewPreset) => {
    const ref = threeRef.current;
    if (!ref) return;

    // Center on hips/torso centroid
    const targetY = activePose === 'lying-down' ? 0.15 : 1.05;
    ref.controls.target.set(0, targetY, 0);

    if (preset === 'front') {
      ref.camera.position.set(0, targetY, 2.6);
    } else if (preset === 'side') {
      ref.camera.position.set(2.6, targetY, 0);
    } else if (preset === 'top') {
      ref.camera.position.set(0, 3.2, 0.001);
    } else if (preset === 'isometric') {
      autoFrameCamera(activePose, false);
      return;
    }
    ref.controls.update();
  };

  // Reset View handler
  const handleResetView = () => {
    autoFrameCamera(activePose, false);
  };

  // Zoom In / Zoom Out handlers
  const handleZoom = (direction: 'in' | 'out') => {
    const ref = threeRef.current;
    if (!ref) return;
    const offset = ref.camera.position.clone().sub(ref.controls.target);
    const currentDist = offset.length();
    const zoomFactor = direction === 'in' ? 0.78 : 1.25;
    const newDist = Math.max(0.85, Math.min(5.0, currentDist * zoomFactor));

    offset.normalize().multiplyScalar(newDist);
    ref.camera.position.copy(ref.controls.target).add(offset);
    ref.controls.update();
  };

  // Highlight specific anatomical group
  const handleGroupHighlight = (group: string) => {
    const ref = threeRef.current;
    if (!ref) return;
    if (activeGroupHighlight === group) {
      setActiveGroupHighlight(null);
      ref.sphereMeshes.forEach((s) => {
        if (!s.visible) return;
        const mat = s.material as THREE.MeshStandardMaterial;
        mat.color.setHex(ref.activeThemeRef.sphereHex);
        mat.emissive.setHex(ref.activeThemeRef.sphereEmissive);
        s.scale.set(1.0, 1.0, 1.0);
      });
      return;
    }

    setActiveGroupHighlight(group);
    ref.sphereMeshes.forEach((s, idx) => {
      if (!s.visible) return;
      const meta = LANDMARKS_META[idx];
      const mat = s.material as THREE.MeshStandardMaterial;
      if (meta.group === group) {
        mat.color.setHex(0xfacc15); // amber highlight
        mat.emissive.setHex(0xf59e0b);
        mat.emissiveIntensity = 1.6;
        s.scale.set(1.4, 1.4, 1.4);
      } else {
        mat.color.setHex(0x334155);
        mat.emissive.setHex(0x1e293b);
        mat.emissiveIntensity = 0.2;
        s.scale.set(0.8, 0.8, 0.8);
      }
    });
  };

  return (
    <div
      ref={containerRef}
      id="threejs-skeleton-viewer"
      className="relative w-full min-h-[500px] h-[540px] md:h-[600px] rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col shadow-inner select-none"
    >
      {/* Top Header Bar: 33 Landmarks Active, Status Color Pill, Poses, Numbers Toggle */}
      <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2.5 pointer-events-none">
        {/* Status pill: "33 landmarks active" or "Pose data unavailable" or "Waiting for camera data" */}
        <div className="pointer-events-auto flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 backdrop-blur-md shadow-lg">
          {!cameraConnected ? (
            <>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-xs font-mono font-bold tracking-wide text-amber-300">
                Waiting for camera data
              </span>
            </>
          ) : isPoseDataUnavailable ? (
            <>
              <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-pulse" />
              <span className="text-xs font-mono font-bold tracking-wide text-rose-300">
                Pose data unavailable
              </span>
            </>
          ) : (
            <>
              <span className={`w-2.5 h-2.5 rounded-full ${activeTheme.dotColor} animate-ping`} />
              <span className={`text-xs font-mono font-bold tracking-wide ${activeTheme.textColor}`}>
                33 body points
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-[11px] font-mono uppercase font-semibold text-slate-300">
                {activeTheme.name}
              </span>
            </>
          )}
        </div>

        {/* Pose Selection: Normal (Green), Possible Fall (Amber/Yellow), Lying Down (Red) */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/90 border border-slate-700/80 p-1 rounded-xl backdrop-blur-md text-xs font-mono shadow-md">
          <button
            id="btn-pose-normal"
            onClick={() => handlePoseSelect('normal')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all ${
              activePose === 'normal'
                ? 'bg-emerald-600 text-white shadow-sm ring-1 ring-emerald-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Normal Upright Standing Pose (Green skeleton)"
          >
            Normal
          </button>
          <button
            id="btn-pose-possible-fall"
            onClick={() => handlePoseSelect('possible-fall')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all ${
              activePose === 'possible-fall'
                ? 'bg-amber-600 text-white shadow-sm ring-1 ring-amber-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Possible Fall (Amber/Yellow skeleton)"
          >
            Possible Fall
          </button>
          <button
            id="btn-pose-lying-down"
            onClick={() => handlePoseSelect('lying-down')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all ${
              activePose === 'lying-down'
                ? 'bg-rose-600 text-white shadow-sm ring-1 ring-rose-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Lying Down (Red skeleton, auto-framed to floor)"
          >
            Lying Down
          </button>
        </div>

        {/* Action Controls: Auto-Frame & Landmark Numbers Toggle */}
        <div className="pointer-events-auto flex items-center gap-1.5">
          {/* Auto-Frame Button */}
          <button
            id="btn-auto-frame"
            onClick={() => autoFrameCamera(activePose, false)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-700/80 bg-slate-900/90 text-slate-300 hover:text-white backdrop-blur-md text-xs font-mono transition-all shadow-md hover:border-slate-600"
            title="Auto-Frame: Automatically zoom and center camera to fill viewport"
          >
            <Maximize2 className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">Auto Frame</span>
          </button>

          {/* Show landmark labels toggle */}
          <button
            id="btn-toggle-landmark-labels"
            onClick={() => setShowLandmarkLabels(!showLandmarkLabels)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border backdrop-blur-md text-xs font-mono font-medium transition-all shadow-md ${
              showLandmarkLabels
                ? 'bg-cyan-950/90 text-cyan-200 border-cyan-500/80 ring-1 ring-cyan-500/30'
                : 'bg-slate-900/90 text-slate-400 border-slate-700/80 hover:text-slate-200'
            }`}
            title="Show landmark labels: Toggle indexes 0-32 and landmark names beside points"
            aria-pressed={showLandmarkLabels}
          >
            {/* Interactive switch slider */}
            <div
              className={`w-6 h-3.5 rounded-full p-0.5 transition-colors duration-200 ease-in-out flex items-center ${
                showLandmarkLabels ? 'bg-cyan-400 justify-end' : 'bg-slate-700 justify-start'
              }`}
            >
              <div className="w-2.5 h-2.5 rounded-full bg-slate-950 shadow-sm" />
            </div>
            <span>Show landmark labels</span>
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas Mounting Container */}
      <div
        ref={mountRef}
        onClick={handleCanvasClick}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        className="w-full flex-1 cursor-grab active:cursor-grabbing relative touch-none"
        title="Orbit Controls: Drag to rotate, scroll or pinch to zoom"
      />

      {/* Sensor Error State Overlays: "Waiting for camera data" or "Pose data unavailable" */}
      {!cameraConnected && (
        <div
          id="overlay-camera-disconnected"
          className="absolute inset-0 z-30 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center"
        >
          <div className="p-3.5 rounded-2xl bg-amber-950/80 border border-amber-600/70 text-amber-400 mb-3 shadow-xl animate-pulse">
            <VideoOff className="w-8 h-8" />
          </div>
          <h4 className="text-base font-bold text-white font-['Plus_Jakarta_Sans'] mb-1">
            Waiting for camera data
          </h4>
          <p className="text-xs text-slate-300 max-w-sm leading-relaxed mb-3">
            Optical video feed is currently disconnected or waiting for sensor handshake. MediaPipe 33-point pose estimation will resume automatically upon camera link re-establishment.
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/60 border border-amber-700/60 text-amber-300 text-[11px] font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
            Camera module: Disconnected • Listening on RTSP/USB
          </div>
        </div>
      )}

      {cameraConnected && isPoseDataUnavailable && (
        <div
          id="overlay-pose-unavailable"
          className="absolute inset-0 z-30 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center"
        >
          <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-600/70 text-rose-400 mb-3 shadow-xl">
            <AlertTriangle className="w-8 h-8 animate-bounce" />
          </div>
          <h4 className="text-base font-bold text-white font-['Plus_Jakarta_Sans'] mb-1">
            Pose data unavailable
          </h4>
          <p className="text-xs text-slate-300 max-w-sm leading-relaxed mb-3">
            {landmarkValidation.errorReason || 'Malformed landmark coordinate stream detected. Safe recovery active.'}
          </p>
          {onClearForcedError && (
            <button
              id="btn-recover-pose-data"
              onClick={onClearForcedError}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 text-xs font-semibold shadow-md transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
              Restore Nominal Pose Stream
            </button>
          )}
        </div>
      )}

      {/* Projected Landmark Labels (Indexes 0 through 32 beside points; hidden when disabled) */}
      {showLandmarkLabels && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
          {projectedLabels.map((lbl) => {
            if (!lbl.visible) return null;
            const isImportant = lbl.id in IMPORTANT_LANDMARKS;
            const importantName = IMPORTANT_LANDMARKS[lbl.id];
            const meta = LANDMARKS_META[lbl.id];
            const isHovered = hoveredLandmark?.id === lbl.id || clickedLandmarkId === lbl.id;

            // Offset beside the landmark point: shift right, or shift left if near the right boundary
            const isNearRightEdge = lbl.x > 360;
            const leftPos = isNearRightEdge ? lbl.x - 8 : lbl.x + 8;
            const transformClass = isNearRightEdge
              ? '-translate-x-full -translate-y-1/2'
              : 'translate-x-0 -translate-y-1/2';

            return (
              <div
                key={`lbl-${lbl.id}`}
                id={`landmark-label-${lbl.id}`}
                onMouseEnter={() => {
                  if (threeRef.current) {
                    const p = threeRef.current.currentCoords[lbl.id];
                    setHoveredLandmark({
                      id: lbl.id,
                      name: meta?.name || `Point ${lbl.id}`,
                      group: meta?.group || 'body',
                      coords: [p[0], p[1], p[2]],
                      screenX: lbl.x,
                      screenY: lbl.y,
                    });
                  }
                }}
                onMouseLeave={() => setHoveredLandmark(null)}
                className={`pointer-events-auto cursor-pointer absolute transform transition-all duration-75 select-none ${transformClass} ${
                  isHovered ? 'scale-110 z-30' : 'z-10'
                }`}
                style={{
                  left: `${leftPos}px`,
                  top: `${lbl.y}px`,
                }}
                title={`${lbl.id} ${meta?.name || ''}`}
              >
                {isImportant ? (
                  // Important landmark label: small, readable pill with index & landmark name
                  <div
                    className={`flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold border shadow-md backdrop-blur-md whitespace-nowrap transition-all ${
                      isHovered
                        ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-500 shadow-amber-500/50 scale-105'
                        : activePose === 'normal'
                        ? 'bg-slate-900/95 text-cyan-200 border-cyan-500/80 shadow-cyan-950/60'
                        : activePose === 'possible-fall'
                        ? 'bg-amber-950/95 text-amber-200 border-amber-500/80 shadow-amber-950/60'
                        : 'bg-rose-950/95 text-rose-200 border-rose-500/80 shadow-rose-950/60'
                    }`}
                  >
                    <span className="opacity-80 text-[9px] font-extrabold bg-slate-950/70 px-1 py-0.2 rounded border border-white/10">
                      {lbl.id}
                    </span>
                    <span className="tracking-tight">{importantName}</span>
                  </div>
                ) : (
                  // General landmark label: small readable index pill (0 through 32)
                  <div
                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-semibold border shadow-sm backdrop-blur-md transition-all ${
                      isHovered
                        ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-500 scale-110'
                        : 'bg-slate-950/90 text-slate-300 border-slate-700/80'
                    }`}
                  >
                    {lbl.id}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Tooltip Card for Detailed Landmark Inspection on Hover or Click */}
      {(hoveredLandmark || clickedLandmarkId !== null) && (
        (() => {
          const activeItem =
            hoveredLandmark ||
            (clickedLandmarkId !== null && threeRef.current
              ? {
                  id: clickedLandmarkId,
                  name: LANDMARKS_META[clickedLandmarkId].name,
                  group: LANDMARKS_META[clickedLandmarkId].group,
                  coords: threeRef.current.currentCoords[clickedLandmarkId],
                  screenX:
                    projectedLabels.find((l) => l.id === clickedLandmarkId)?.x || 120,
                  screenY:
                    projectedLabels.find((l) => l.id === clickedLandmarkId)?.y || 120,
                }
              : null);

          if (!activeItem) return null;

          return (
            <div
              className="absolute z-30 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-3 bg-slate-900/95 border border-cyan-500/80 px-3 py-2 rounded-xl shadow-2xl text-xs font-mono backdrop-blur-md min-w-44"
              style={{
                left: `${Math.max(90, Math.min(activeItem.screenX, 420))}px`,
                top: `${Math.max(40, activeItem.screenY - 16)}px`,
              }}
            >
              <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1">
                <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  <span>
                    #{activeItem.id} {activeItem.name}
                  </span>
                </div>
                <span className="text-[10px] uppercase font-semibold text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                  {activeItem.group}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1 pt-1.5 text-[10px] text-slate-300">
                <div>
                  <span className="text-slate-500 block">X</span>
                  <span className="font-mono text-cyan-400">{activeItem.coords[0].toFixed(2)}m</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Y (Height)</span>
                  <span className="font-mono text-emerald-400">{activeItem.coords[1].toFixed(2)}m</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Z (Depth)</span>
                  <span className="font-mono text-indigo-400">{activeItem.coords[2].toFixed(2)}m</span>
                </div>
              </div>
            </div>
          );
        })()
      )}

      {/* Camera Orientation & Coordinate-Axis Indicator Bar */}
      <div className="absolute bottom-16 sm:bottom-14 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Left cluster: Preset Views & Small Coordinate-Axis Indicator */}
        <div className="flex flex-wrap items-center gap-1.5 pointer-events-auto">
          {/* Preset Angle Buttons: Front View, Side View, Top View */}
          <div className="flex items-center gap-1 bg-slate-900/90 border border-slate-700/80 p-1 rounded-xl backdrop-blur-md text-xs font-mono shadow-md">
            <span className="text-[10px] text-slate-400 px-2 flex items-center gap-1 font-semibold uppercase">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              Views:
            </span>
            <button
              id="btn-view-front"
              onClick={() => setCameraPreset('front')}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 active:bg-slate-850 text-slate-200 hover:text-white font-medium transition-colors"
              title="Front View: look directly at resident"
            >
              Front View
            </button>
            <button
              id="btn-view-side"
              onClick={() => setCameraPreset('side')}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 active:bg-slate-850 text-slate-200 hover:text-white font-medium transition-colors"
              title="Side View: profile sagittal view"
            >
              Side View
            </button>
            <button
              id="btn-view-top"
              onClick={() => setCameraPreset('top')}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 active:bg-slate-850 text-slate-200 hover:text-white font-medium transition-colors"
              title="Top View: top-down view looking onto floor"
            >
              Top View
            </button>
          </div>

          {/* Small Coordinate-Axis Indicator Badge */}
          <div
            id="coordinate-axis-indicator"
            className="hidden sm:flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-900/90 border border-slate-700/80 backdrop-blur-md shadow-md text-[10px] font-mono text-slate-300"
            title="3D Coordinate System: X (Lateral / Red), Y (Elevation Height / Green), Z (Sagittal Depth / Cyan)"
          >
            <span className="text-slate-400 font-bold uppercase">Axes:</span>
            <span className="flex items-center gap-1 text-rose-400 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-sm" />
              +X
            </span>
            <span className="flex items-center gap-1 text-emerald-400 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-sm" />
              +Y
            </span>
            <span className="flex items-center gap-1 text-cyan-400 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-sm" />
              +Z
            </span>
          </div>
        </div>

        {/* Visible Zoom In, Zoom Out, and Reset View Buttons */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/90 border border-slate-700/80 p-1 rounded-xl backdrop-blur-md shadow-md">
          <button
            id="btn-zoom-in"
            onClick={() => handleZoom('in')}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-slate-850 text-slate-200 hover:text-white text-xs font-mono font-medium transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5 text-cyan-400" />
            <span>Zoom In</span>
          </button>
          <button
            id="btn-zoom-out"
            onClick={() => handleZoom('out')}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-slate-850 text-slate-200 hover:text-white text-xs font-mono font-medium transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5 text-cyan-400" />
            <span>Zoom Out</span>
          </button>
          <button
            id="btn-reset-view"
            onClick={handleResetView}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 active:bg-slate-850 text-slate-200 hover:text-white text-xs font-mono font-medium transition-colors"
            title="Reset view and auto-frame skeleton"
          >
            <RotateCcw className="w-3.5 h-3.5 text-teal-400" />
            <span>Reset View</span>
          </button>
        </div>
      </div>

      {/* Bottom Footer: Collapsible & Scrollable Legend (Head, Arms, Torso, Legs, Feet) & Privacy Guarantee */}
      {/* Requirement 6: Wrapped in a scrollable and collapsible container so it NEVER clips regardless of screen height */}
      <div className="relative z-20 px-3 py-2 bg-slate-950/95 border-t border-slate-800 flex flex-col gap-1 text-xs">
        <div className="flex items-center justify-between gap-2">
          {/* Legend Toggle & Header */}
          <button
            onClick={() => setIsLegendOpen(!isLegendOpen)}
            className="flex items-center gap-1.5 text-[11px] font-mono text-slate-300 font-semibold uppercase hover:text-white transition-colors"
            title="Toggle Anatomical Legend Panel"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Anatomical Groups</span>
            {isLegendOpen ? (
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            ) : (
              <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
            )}
          </button>

          {/* Privacy Guarantee: 3D skeletal representation only */}
          <div
            id="label-3d-skeletal-privacy"
            className="flex items-center gap-1.5 text-[11px] text-cyan-200/90 font-medium shrink-0"
          >
            <Shield className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="font-semibold text-cyan-100">
              3D skeletal representation only
            </span>
            <span className="text-slate-600 hidden md:inline">•</span>
            <span className="text-slate-400 text-[10px] hidden md:inline">
              No face, body texture, clothing, or raw video
            </span>
          </div>
        </div>

        {/* Collapsible, Scrollable Legend Button Bar */}
        {isLegendOpen && (
          <div
            id="skeleton-anatomical-legend"
            className="flex items-center flex-wrap gap-1.5 max-h-24 sm:max-h-32 overflow-x-auto overflow-y-auto py-1 pr-1 text-[11px] font-mono scrollbar-thin scrollbar-thumb-slate-700"
          >
            <button
              onClick={() => handleGroupHighlight('head')}
              className={`px-2 py-0.5 rounded-md border transition-all ${
                activeGroupHighlight === 'head'
                  ? 'bg-amber-950 text-amber-200 border-amber-500 font-bold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
              title="Head (Landmark 0): Cranium center (Facial detail hidden for privacy & clarity)"
            >
              Head (0)
            </button>
            <button
              onClick={() => handleGroupHighlight('torso')}
              className={`px-2 py-0.5 rounded-md border transition-all ${
                activeGroupHighlight === 'torso'
                  ? 'bg-amber-950 text-amber-200 border-amber-500 font-bold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
              title="Torso (11, 12, 23, 24): Shoulders & Hips Centroid"
            >
              Torso (11, 12, 23, 24)
            </button>
            <button
              onClick={() => handleGroupHighlight('arms')}
              className={`px-2 py-0.5 rounded-md border transition-all ${
                activeGroupHighlight === 'arms'
                  ? 'bg-amber-950 text-amber-200 border-amber-500 font-bold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
              title="Arms (13–22): Elbows, Wrists, Hands, Fingers"
            >
              Arms (13–22)
            </button>
            <button
              onClick={() => handleGroupHighlight('legs')}
              className={`px-2 py-0.5 rounded-md border transition-all ${
                activeGroupHighlight === 'legs'
                  ? 'bg-amber-950 text-amber-200 border-amber-500 font-bold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
              title="Legs (25–28): Knees & Ankles"
            >
              Legs (25–28)
            </button>
            <button
              onClick={() => handleGroupHighlight('feet')}
              className={`px-2 py-0.5 rounded-md border transition-all ${
                activeGroupHighlight === 'feet'
                  ? 'bg-amber-950 text-amber-200 border-amber-500 font-bold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
              title="Feet (29–32): Heels & Foot Indices"
            >
              Feet (29–32)
            </button>

            {activeGroupHighlight && (
              <button
                onClick={() => handleGroupHighlight(activeGroupHighlight)}
                className="text-[10px] text-slate-400 underline hover:text-slate-200 ml-1"
              >
                Clear filter
              </button>
            )}

            {/* Important Landmarks Quick Reference Row */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-1 border-t border-slate-800/80 mt-1 w-full text-[10px] font-mono scrollbar-thin scrollbar-thumb-slate-700">
              <span className="text-cyan-400 font-bold uppercase shrink-0 mr-0.5">
                Key Landmarks:
              </span>
              {[
                { id: 0, label: '0 Nose' },
                { id: 11, label: '11 Left Shoulder' },
                { id: 12, label: '12 Right Shoulder' },
                { id: 23, label: '23 Left Hip' },
                { id: 24, label: '24 Right Hip' },
                { id: 25, label: '25 Left Knee' },
                { id: 26, label: '26 Right Knee' },
                { id: 27, label: '27 Left Ankle' },
                { id: 28, label: '28 Right Ankle' },
              ].map(({ id, label }) => (
                <button
                  key={`key-lm-${id}`}
                  onClick={() => setClickedLandmarkId(clickedLandmarkId === id ? null : id)}
                  onMouseEnter={() => {
                    if (threeRef.current) {
                      const p = threeRef.current.currentCoords[id];
                      setHoveredLandmark({
                        id,
                        name: LANDMARKS_META[id].name,
                        group: LANDMARKS_META[id].group,
                        coords: [p[0], p[1], p[2]],
                        screenX: projectedLabels.find((l) => l.id === id)?.x || 160,
                        screenY: projectedLabels.find((l) => l.id === id)?.y || 160,
                      });
                    }
                  }}
                  onMouseLeave={() => setHoveredLandmark(null)}
                  className={`shrink-0 px-2 py-0.5 rounded border transition-all ${
                    clickedLandmarkId === id || hoveredLandmark?.id === id
                      ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold shadow-sm'
                      : 'bg-slate-900/90 text-cyan-200 border-slate-800 hover:border-cyan-500/60'
                  }`}
                  title={`Inspect landmark #${id}: ${LANDMARKS_META[id].name}`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
