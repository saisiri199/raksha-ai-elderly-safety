import React, { useState } from 'react';
import { CheckCircle2, AlertTriangle, VideoOff, Wifi, EyeOff, ShieldCheck, Box, Layers } from 'lucide-react';
import { LivingRoomStatus } from '../types';
import { Skeleton3DViewer, DemoPoseType, ForcedLandmarkError } from './Skeleton3DViewer';
import { SkeletonVisualizer } from './SkeletonVisualizer';

interface LivingRoomCardProps {
  status: LivingRoomStatus;
  cameraConnected: boolean;
  room?: string;
  incidentTimestamp?: string;
  onStatusChange?: (newStatus: LivingRoomStatus) => void;
  rawLandmarks?: unknown;
  forcedLandmarkError?: ForcedLandmarkError;
  onClearForcedError?: () => void;
  isDemoMode?: boolean;
}

export const LivingRoomCard: React.FC<LivingRoomCardProps> = ({
  status,
  cameraConnected,
  incidentTimestamp,
  rawLandmarks,
  forcedLandmarkError,
  onClearForcedError,
  isDemoMode = true,
}) => {
  const [viewMode, setViewMode] = useState<'3d' | '2d'>('3d');
  const [current3DPose, setCurrent3DPose] = useState<DemoPoseType | undefined>(undefined);

  const isAlertState =
    status === 'POSSIBLE_FALL' ||
    status === 'Possible Fall' ||
    status === 'CHECKING_RESPONSE' ||
    status === 'Checking Response' ||
    status === 'ALERT_SENT' ||
    status === 'Alert Sent' ||
    status === 'ESCALATED' ||
    status === 'Escalated';

  return (
    <article
      id="living-room-card"
      className={`bg-white rounded-2xl border p-5 sm:p-6 shadow-sm flex flex-col justify-between transition-all ${
        isAlertState ? 'border-amber-400 ring-2 ring-amber-100' : 'border-slate-200'
      }`}
    >
      <div className="space-y-4">
        {/* Header: Room Name & Large Status Text */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Room 1
              </span>
              <span className="text-slate-300">•</span>
              <span className="text-xs text-slate-600 font-medium">33 Body Points Sensor</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
              Living Room
            </h3>
          </div>

          {/* Large Status Text */}
          <div
            id="living-room-status-badge"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl border text-sm font-bold ${
              isAlertState
                ? 'bg-amber-50 text-amber-900 border-amber-300'
                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
            }`}
          >
            {isAlertState ? (
              <>
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                <span className="text-base">Please check the living room</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span className="text-base">Everything is okay</span>
              </>
            )}
          </div>
        </div>

        {/* Small secondary row: Camera connection status & view toggle */}
        <div className="flex items-center justify-between text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
          <div className="flex items-center gap-2">
            <Wifi className={`w-4 h-4 ${cameraConnected ? 'text-emerald-600' : 'text-amber-600'}`} />
            <span className="font-semibold text-slate-700">Camera:</span>
            <span
              id="camera-connection-status"
              className={`font-semibold ${
                cameraConnected ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {cameraConnected ? 'Connected' : 'Waiting for camera data'}
            </span>
          </div>

          {/* View toggle (3D / 2D) */}
          <div className="flex items-center gap-1 bg-white border border-slate-200 p-0.5 rounded-lg text-xs">
            <button
              id="btn-switch-3d-view"
              onClick={() => setViewMode('3d')}
              className={`px-2 py-1 rounded font-medium transition-colors ${
                viewMode === '3d'
                  ? 'bg-slate-900 text-white font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              3D View
            </button>
            <button
              id="btn-switch-2d-view"
              onClick={() => setViewMode('2d')}
              className={`px-2 py-1 rounded font-medium transition-colors ${
                viewMode === '2d'
                  ? 'bg-slate-900 text-white font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              2D View
            </button>
          </div>
        </div>

        {/* 3D Skeleton Viewer in large clear area */}
        <div className="relative rounded-xl overflow-hidden border border-slate-200 shadow-inner">
          {viewMode === '3d' ? (
            <Skeleton3DViewer
              status={status}
              externalPose={current3DPose}
              onPoseChange={(p) => setCurrent3DPose(p)}
              cameraConnected={cameraConnected}
              rawLandmarks={rawLandmarks}
              forcedError={forcedLandmarkError}
              onClearForcedError={onClearForcedError}
            />
          ) : (
            <SkeletonVisualizer
              status={status}
              cameraConnected={cameraConnected}
              isPoseUnavailable={Boolean(forcedLandmarkError)}
            />
          )}
        </div>
      </div>

      {/* Footer: Privacy Label */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <EyeOff className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold text-slate-800">
            No face or video is shared.
          </span>
        </div>
        <span className="text-slate-500">
          Real-time 33 body points processed locally
        </span>
      </div>
    </article>
  );
};
export default LivingRoomCard;
