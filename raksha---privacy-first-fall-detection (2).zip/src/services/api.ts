import { FallState, TimelineEvent, SystemHealthData, ApiConnectionState } from '../types';

export interface LiveLandmark {
  x: number;
  y: number;
  z: number;
  visibility: number;
}

export interface LivePoseFrame {
  timestamp: string;
  landmarks: LiveLandmark[];
  confidence: number;
  posture: 'standing' | 'sitting' | 'horizontal_floor' | 'transition';
  fallProbability: number;
  dataSource: 'real';
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  httpStatus?: number;
  latencyMs: number;
  isRealData: boolean;
  endpoint: string;
}

class ApiService {
  private baseEndpoint: string = '/api';
  private simulateServerDown: boolean = false;
  private currentConnectionState: ApiConnectionState = {
    status: 'connected',
    endpoint: '/api',
    latencyMs: 12,
    lastChecked: 'Just now',
    isRealData: true,
  };

  public setEndpoint(url: string) {
    this.baseEndpoint = url.replace(/\/+$/, '');
    this.currentConnectionState.endpoint = this.baseEndpoint;
  }

  public getEndpoint(): string {
    return this.baseEndpoint;
  }

  public getConnectionState(): ApiConnectionState {
    return this.currentConnectionState;
  }

  public setSimulateServerDown(down: boolean) {
    this.simulateServerDown = down;
  }

  public isSimulatingServerDown(): boolean {
    return this.simulateServerDown;
  }

  public async getEvents(): Promise<ApiResponse<TimelineEvent[]>> {
    return this.fetchEvents();
  }

  public async getLandmarks(): Promise<ApiResponse<LivePoseFrame>> {
    return this.fetchLandmarks();
  }

  public async getSystemStatus(): Promise<ApiResponse<SystemHealthData>> {
    return this.fetchSystemHealth();
  }

  /**
   * Ping the API to test connectivity and measure latency.
   * STRICT RULE: Never silently return fake data if the API fails.
   */
  public async checkConnection(): Promise<ApiConnectionState> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/health`;

    if (this.simulateServerDown) {
      const latency = Math.round(performance.now() - start);
      const state: ApiConnectionState = {
        status: 'disconnected',
        endpoint: this.baseEndpoint,
        latencyMs: latency,
        lastChecked: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        errorMessage: 'Simulated API server offline (HTTP 503 Service Unavailable). Fake data fallback disabled.',
        isRealData: true,
        httpStatus: 503,
      };
      this.currentConnectionState = state;
      return state;
    }

    try {
      const res = await fetch(endpoint, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        cache: 'no-cache',
      });
      const latency = Math.round(performance.now() - start);

      if (!res.ok) {
        const state: ApiConnectionState = {
          status: 'disconnected',
          endpoint: this.baseEndpoint,
          latencyMs: latency,
          lastChecked: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          errorMessage: `API server returned HTTP ${res.status}: ${res.statusText}`,
          isRealData: true,
          httpStatus: res.status,
        };
        this.currentConnectionState = state;
        return state;
      }

      await res.json();
      const state: ApiConnectionState = {
        status: 'connected',
        endpoint: this.baseEndpoint,
        latencyMs: latency,
        lastChecked: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        isRealData: true,
        httpStatus: 200,
      };
      this.currentConnectionState = state;
      return state;
    } catch (err) {
      const latency = Math.round(performance.now() - start);
      const msg = err instanceof Error ? err.message : 'Network error';
      const state: ApiConnectionState = {
        status: 'disconnected',
        endpoint: this.baseEndpoint,
        latencyMs: latency,
        lastChecked: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        errorMessage: `Failed to connect to API at ${this.baseEndpoint}: ${msg}. Zero fake data fallback in Live Mode.`,
        isRealData: true,
        httpStatus: 0,
      };
      this.currentConnectionState = state;
      return state;
    }

  }

  /**
   * Fetch real event data from API.
   * If offline or error, returns success: false. NEVER generates fake events!
   */
  public async fetchEvents(): Promise<ApiResponse<TimelineEvent[]>> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/events`;

    if (this.simulateServerDown) {
      return {
        success: false,
        latencyMs: Math.round(performance.now() - start),
        error: 'Live API server offline (HTTP 503). Zero synthetic fallback data injected.',
        isRealData: true,
        endpoint,
        httpStatus: 503,
      };
    }

    try {
      const res = await fetch(endpoint, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        cache: 'no-cache',
      });
      const latency = Math.round(performance.now() - start);

      if (!res.ok) {
        return {
          success: false,
          latencyMs: latency,
          error: `API error HTTP ${res.status}: ${res.statusText}`,
          isRealData: true,
          endpoint,
          httpStatus: res.status,
        };
      }

      const events: TimelineEvent[] = await res.json();
      return {
        success: true,
        data: events,
        latencyMs: latency,
        isRealData: true,
        endpoint,
        httpStatus: 200,
      };
    } catch (err) {
      const latency = Math.round(performance.now() - start);
      return {
        success: false,
        latencyMs: latency,
        error: err instanceof Error ? err.message : 'Failed to fetch API events',
        isRealData: true,
        endpoint,
        httpStatus: 0,
      };
    }
  }

  /**
   * Fetch real 33-point MediaPipe landmark frame from edge camera stream API.
   * If unavailable, returns success: false.
   */
  public async fetchLandmarks(): Promise<ApiResponse<LivePoseFrame>> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/landmarks`;

    if (this.simulateServerDown) {
      return {
        success: false,
        latencyMs: Math.round(performance.now() - start),
        error: 'Edge optical stream offline (HTTP 503).',
        isRealData: true,
        endpoint,
        httpStatus: 503,
      };
    }

    try {
      const res = await fetch(endpoint, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        cache: 'no-cache',
      });
      const latency = Math.round(performance.now() - start);

      if (!res.ok) {
        return {
          success: false,
          latencyMs: latency,
          error: `API error HTTP ${res.status}: ${res.statusText}`,
          isRealData: true,
          endpoint,
          httpStatus: res.status,
        };
      }

      const frame: LivePoseFrame = await res.json();
      return {
        success: true,
        data: frame,
        latencyMs: latency,
        isRealData: true,
        endpoint,
        httpStatus: 200,
      };
    } catch (err) {
      const latency = Math.round(performance.now() - start);
      return {
        success: false,
        latencyMs: latency,
        error: err instanceof Error ? err.message : 'Landmark stream unavailable',
        isRealData: true,
        endpoint,
        httpStatus: 0,
      };
    }
  }

  /**
   * Fetch real system telemetry & sensor health from API.
   */
  public async fetchSystemHealth(): Promise<ApiResponse<SystemHealthData>> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/system-status`;

    if (this.simulateServerDown) {
      return {
        success: false,
        latencyMs: Math.round(performance.now() - start),
        error: 'Backend system telemetry offline.',
        isRealData: true,
        endpoint,
        httpStatus: 503,
      };
    }

    try {
      const res = await fetch(endpoint, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        cache: 'no-cache',
      });
      const latency = Math.round(performance.now() - start);

      if (!res.ok) {
        return {
          success: false,
          latencyMs: latency,
          error: `API error HTTP ${res.status}`,
          isRealData: true,
          endpoint,
          httpStatus: res.status,
        };
      }

      const data: SystemHealthData = await res.json();
      return {
        success: true,
        data,
        latencyMs: latency,
        isRealData: true,
        endpoint,
        httpStatus: 200,
      };
    } catch (err) {
      const latency = Math.round(performance.now() - start);
      return {
        success: false,
        latencyMs: latency,
        error: err instanceof Error ? err.message : 'Connection failed',
        isRealData: true,
        endpoint,
        httpStatus: 0,
      };
    }
  }

  /**
   * Post a state transition or real event to the API gateway.
   */
  public async postEvent(event: Partial<TimelineEvent>): Promise<ApiResponse<TimelineEvent>> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/events`;

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(event),
      });
      const latency = Math.round(performance.now() - start);

      if (!res.ok) {
        return {
          success: false,
          latencyMs: latency,
          error: `HTTP ${res.status}: ${res.statusText}`,
          isRealData: true,
          endpoint,
          httpStatus: res.status,
        };
      }

      const saved = await res.json();
      return {
        success: true,
        data: saved,
        latencyMs: latency,
        isRealData: true,
        endpoint,
        httpStatus: 200,
      };
    } catch (err) {
      return {
        success: false,
        latencyMs: Math.round(performance.now() - start),
        error: err instanceof Error ? err.message : 'Post event failed',
        isRealData: true,
        endpoint,
        httpStatus: 0,
      };
    }
  }

  /**
   * Acknowledge alert on live API
   */
  public async acknowledgeAlert(alertId?: string): Promise<ApiResponse<{ status: string; resolvedAt: string }>> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/alerts/acknowledge`;

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId, resolvedAt: new Date().toISOString() }),
      });
      const latency = Math.round(performance.now() - start);
      if (!res.ok) {
        return {
          success: false,
          latencyMs: latency,
          error: `HTTP ${res.status}`,
          isRealData: true,
          endpoint,
          httpStatus: res.status,
        };
      }
      const data = await res.json();
      return { success: true, data, latencyMs: latency, isRealData: true, endpoint, httpStatus: 200 };
    } catch (err) {
      return {
        success: false,
        latencyMs: Math.round(performance.now() - start),
        error: err instanceof Error ? err.message : 'Acknowledge failed',
        isRealData: true,
        endpoint,
      };
    }
  }

  /**
   * Escalate alert on live API
   */
  public async escalateAlert(alertId?: string, reason?: string): Promise<ApiResponse<{ status: string; escalatedAt: string }>> {
    const start = performance.now();
    const endpoint = `${this.baseEndpoint}/alerts/escalate`;

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId, reason, escalatedAt: new Date().toISOString() }),
      });
      const latency = Math.round(performance.now() - start);
      if (!res.ok) {
        return {
          success: false,
          latencyMs: latency,
          error: `HTTP ${res.status}`,
          isRealData: true,
          endpoint,
          httpStatus: res.status,
        };
      }
      const data = await res.json();
      return { success: true, data, latencyMs: latency, isRealData: true, endpoint, httpStatus: 200 };
    } catch (err) {
      return {
        success: false,
        latencyMs: Math.round(performance.now() - start),
        error: err instanceof Error ? err.message : 'Escalate failed',
        isRealData: true,
        endpoint,
      };
    }
  }
}

export const api = new ApiService();
