import React, { useState } from 'react';
import { ShieldCheck, ChevronDown, ChevronUp, EyeOff, Lock, UserCheck, VideoOff, Check } from 'lucide-react';

export const PrivacySection: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const points = [
    'No face recognition.',
    'No bathroom camera.',
    'Living-room video is converted into body points.',
    'Only safety information is shared.',
    'The caregiver sees the room and alert, not private video.',
  ];

  return (
    <section
      id="privacy-section"
      aria-label="How Raksha protects privacy"
      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
    >
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-100">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
              How Raksha protects privacy
            </h3>
            <p className="text-xs text-slate-500">
              Complete dignity and zero invasive surveillance
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-500 text-xs font-semibold">
          <span>{isOpen ? 'Hide details' : 'Learn more'}</span>
          {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </button>

      {isOpen && (
        <div className="px-5 pb-5 pt-2 border-t border-slate-100">
          <ul className="space-y-2.5">
            {points.map((point, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-700">
                <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <span className="font-medium text-slate-800">{point}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
};
export default PrivacySection;
