import React, { useState } from 'react';
import {
  Cpu,
  Server,
  Radio,
  Camera,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { ConnectionStatus, ReadyStatus, OnlineStatus, ApiConnectionState } from '../types';

interface SystemHealthSectionProps {
  cameraModule?: ConnectionStatus;
  mediaPipe?: ReadyStatus;
  bathroomRadar?: ConnectionStatus;
  backend?: OnlineStatus;
  lastCameraEvent?: string;
  lastRadarEvent?: string;
  lastDashboardUpdate?: string;
  onToggleCamera?: () => void;
  onToggleMediaPipe?: () => void;
  onToggleRadar?: () => void;
  onToggleBackend?: () => void;
  onRestoreAll?: () => void;
  onRefreshDashboard?: () => void;
  isDemoMode?: boolean;
  apiStatus?: ApiConnectionState;
  onOpenApiSettings?: () => void;
}

export const SystemHealthSection: React.FC<SystemHealthSectionProps> = ({
  cameraModule = 'Connected',
  mediaPipe = 'Ready',
  bathroomRadar = 'Connected',
  backend = 'Online',
  lastCameraEvent = 'Just now • 33 body points tracked',
  lastRadarEvent = '15s ago • Radar active',
  lastDashboardUpdate = 'Just now',
  onToggleCamera,
  onToggleMediaPipe,
  onToggleRadar,
  onToggleBackend,
  onRestoreAll,
  onRefreshDashboard,
  isDemoMode = true,
  apiStatus,
  onOpenApiSettings,
}) => {
  const [showTechnicalControls, setShowTechnicalControls] = useState(false);

  const isBackendOnline = backend === 'Online';
  const isCameraConnected = cameraModule === 'Connected';
  const isMediaPipeReady = mediaPipe === 'Ready';
  const isRadarConnected = bathroomRadar === 'Connected';

  const isAnyModuleDisconnected =
    !isCameraConnected || !isMediaPipeReady || !isRadarConnected || !isBackendOnline;

  return (
    <section
      id="system-health-section"
      aria-label="Sensor health information"
      className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0 border border-slate-200">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
                Sensor Health &amp; Devices
              </h3>
              {/* Overall status badge */}
              {!isBackendOnline ? (
                <span
                  id="system-status-backend-offline"
                  className="text-xs font-semibold text-red-800 bg-red-100 border border-red-300 px-2 py-0.5 rounded flex items-center gap-1"
                >
                  <XCircle className="w-3.5 h-3.5 text-red-600" />
                  System Offline
                </span>
              ) : isAnyModuleDisconnected ? (
                <span
                  id="system-status-degraded"
                  className="text-xs font-semibold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded flex items-center gap-1"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  Sensor Needs Attention
                </span>
              ) : (
                <span
                  id="system-status-all-online"
                  className="text-xs font-semibold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  All Sensors Working
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Live status of living room optical node, bathroom radar, and alert dispatcher
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onRefreshDashboard && (
            <button
              onClick={onRefreshDashboard}
              className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
              title="Refresh connection status"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh</span>
            </button>
          )}
        </div>
      </div>

      {/* Disconnection Warning if any module is offline */}
      {isAnyModuleDisconnected && (
        <div
          id="system-health-warning-banner"
          className="mt-4 p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs flex items-center justify-between gap-3"
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0" />
            <div>
              <span className="font-bold">One or more sensors require attention: </span>
              <span>
                {[
                  !isCameraConnected && 'Living room camera',
                  !isRadarConnected && 'Bathroom radar',
                  !isBackendOnline && 'Alert gateway',
                ]
                  .filter(Boolean)
                  .join(', ')}
              </span>
            </div>
          </div>
          {onRestoreAll && (
            <button
              onClick={onRestoreAll}
              className="px-2.5 py-1 rounded bg-amber-200 hover:bg-amber-300 font-semibold text-amber-900 transition-colors shrink-0"
            >
              Restore all
            </button>
          )}
        </div>
      )}

      {/* Grid of 4 Core Sensor Modules */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mt-4">
        {/* 1. Living Room Camera */}
        <div
          id="health-card-camera"
          className={`p-3.5 rounded-xl border flex flex-col justify-between ${
            isCameraConnected ? 'bg-slate-50 border-slate-200' : 'bg-red-50 border-red-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-slate-700" />
              <span className="text-xs font-bold text-slate-900">Living Room Camera</span>
            </div>
            {isCameraConnected ? (
              <span className="text-emerald-700 flex items-center gap-1 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> Working
              </span>
            ) : (
              <span className="text-red-700 flex items-center gap-1 text-xs font-semibold">
                <XCircle className="w-3.5 h-3.5" /> Offline
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">
            {lastCameraEvent}
          </span>
          {onToggleCamera && (
            <button
              onClick={onToggleCamera}
              className="mt-2 text-[11px] font-semibold text-slate-600 hover:text-slate-900 text-left underline"
            >
              {isCameraConnected ? 'Simulate disconnect' : 'Reconnect camera'}
            </button>
          )}
        </div>

        {/* 2. 33 Body Points ML */}
        <div
          id="health-card-mediapipe"
          className={`p-3.5 rounded-xl border flex flex-col justify-between ${
            isMediaPipeReady ? 'bg-slate-50 border-slate-200' : 'bg-red-50 border-red-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-slate-700" />
              <span className="text-xs font-bold text-slate-900">Body Points AI</span>
            </div>
            {isMediaPipeReady ? (
              <span className="text-emerald-700 flex items-center gap-1 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> 33 Points Active
              </span>
            ) : (
              <span className="text-red-700 flex items-center gap-1 text-xs font-semibold">
                <XCircle className="w-3.5 h-3.5" /> Paused
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">
            On-device edge inference
          </span>
          {onToggleMediaPipe && (
            <button
              onClick={onToggleMediaPipe}
              className="mt-2 text-[11px] font-semibold text-slate-600 hover:text-slate-900 text-left underline"
            >
              {isMediaPipeReady ? 'Pause AI' : 'Resume AI'}
            </button>
          )}
        </div>

        {/* 3. Bathroom Radar */}
        <div
          id="health-card-radar"
          className={`p-3.5 rounded-xl border flex flex-col justify-between ${
            isRadarConnected ? 'bg-slate-50 border-slate-200' : 'bg-red-50 border-red-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-slate-700" />
              <span className="text-xs font-bold text-slate-900">Bathroom Radar</span>
            </div>
            {isRadarConnected ? (
              <span className="text-emerald-700 flex items-center gap-1 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> Working
              </span>
            ) : (
              <span className="text-red-700 flex items-center gap-1 text-xs font-semibold">
                <XCircle className="w-3.5 h-3.5" /> Offline
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">
            {lastRadarEvent}
          </span>
          {onToggleRadar && (
            <button
              onClick={onToggleRadar}
              className="mt-2 text-[11px] font-semibold text-slate-600 hover:text-slate-900 text-left underline"
            >
              {isRadarConnected ? 'Simulate disconnect' : 'Reconnect radar'}
            </button>
          )}
        </div>

        {/* 4. Alert Gateway */}
        <div
          id="health-card-backend"
          className={`p-3.5 rounded-xl border flex flex-col justify-between ${
            isBackendOnline ? 'bg-slate-50 border-slate-200' : 'bg-red-50 border-red-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-slate-700" />
              <span className="text-xs font-bold text-slate-900">Alert Dispatcher</span>
            </div>
            {isBackendOnline ? (
              <span className="text-emerald-700 flex items-center gap-1 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> Online
              </span>
            ) : (
              <span className="text-red-700 flex items-center gap-1 text-xs font-semibold">
                <XCircle className="w-3.5 h-3.5" /> Unavailable
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">
            Updated {lastDashboardUpdate}
          </span>
          {onToggleBackend && (
            <button
              onClick={onToggleBackend}
              className="mt-2 text-[11px] font-semibold text-slate-600 hover:text-slate-900 text-left underline"
            >
              {isBackendOnline ? 'Simulate outage' : 'Restore gateway'}
            </button>
          )}
        </div>
      </div>
    </section>
  );
};
export default SystemHealthSection;
