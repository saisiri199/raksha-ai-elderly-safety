import React, { useState } from 'react';
import { RakshaWelcomePage } from './components/RakshaWelcomePage';
import { CaregiverDashboard } from './components/CaregiverDashboard';

export default function App() {
  // Page 1: Raksha Welcome Page
  // Page 2: Caregiver Dashboard
  const [currentPage, setCurrentPage] = useState<'welcome' | 'dashboard'>('welcome');

  const handleOpenDashboard = () => {
    setCurrentPage('dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToWelcome = () => {
    setCurrentPage('welcome');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen ${currentPage === 'welcome' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {currentPage === 'welcome' ? (
        <RakshaWelcomePage onOpenDashboard={handleOpenDashboard} />
      ) : (
        <CaregiverDashboard onBackToWelcome={handleBackToWelcome} />
      )}
    </div>
  );
}
