import React, { useState, useMemo } from 'react';
import {
  Clock,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  Radio,
  Activity,
  UserCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { TimelineEvent, AlertSeverity, ApiConnectionState } from '../types';
import { deduplicateEvents, sanitizeTimelineEvent } from '../utils/sensorValidation';

interface RecentEventsTimelineProps {
  events: TimelineEvent[];
  onClear?: () => void;
  backendStatus?: 'Online' | 'Offline';
  isDemoMode?: boolean;
  apiStatus?: ApiConnectionState;
}

// Helper to translate event into plain, everyday language
function toPlainLanguage(event: TimelineEvent): string {
  const title = (event.title || '').toLowerCase();
  const desc = (event.description || '').toLowerCase();
  const room = event.room || '';

  if (event.state === 'POSSIBLE_FALL' || title.includes('possible fall') || title.includes('fall detected')) {
    return room === 'Bathroom'
      ? 'Possible fall detected in the bathroom.'
      : 'Possible fall detected in the living room.';
  }
  if (event.state === 'CHECKING_RESPONSE' || title.includes('checking response') || desc.includes('countdown')) {
    return 'The system asked if the resident was okay.';
  }
  if (event.state === 'ALERT_SENT' || title.includes('countdown expired') || desc.includes('no confirmation')) {
    return 'No response received. Caregiver was notified.';
  }
  if (event.state === 'ESCALATED' || title.includes('escalate')) {
    return 'Emergency call for help was placed.';
  }
  if (event.state === 'RESOLVED' || title.includes('safe') || title.includes('resolved') || desc.includes('okay')) {
    return 'Resident confirmed they are okay.';
  }
  if (title.includes('checking movement') || desc.includes('checking movement')) {
    return 'Radar detected movement. Verifying across 3 readings...';
  }
  if (title.includes('human likely') || desc.includes('human likely') || title.includes('human presence')) {
    return 'Human presence likely in the bathroom (verified across 3 readings).';
  }
  if (title.includes('non-human') || desc.includes('non-human') || title.includes('curtain') || title.includes('flutter')) {
    return 'Brief or unstable movement safely filtered out (curtain, fan, or pet).';
  }
  if (title.includes('vacated') || desc.includes('vacated') || desc.includes('left the bathroom')) {
    return 'Resident left the bathroom.';
  }
  if (title.includes('acknowledge') || desc.includes('checking on')) {
    return 'Caregiver acknowledged the alert.';
  }
  if (title.includes('presence') || desc.includes('entered')) {
    return `Resident entered the ${room.toLowerCase() || 'room'}.`;
  }
  if (title.includes('movement')) {
    return `Normal movement in the ${room.toLowerCase() || 'room'}.`;
  }
  if (title.includes('normal') || title.includes('resumed')) {
    return 'System returned to peaceful monitoring.';
  }

  // Fallback to title without technical jargon
  return event.title.replace(/\[.*?\]/g, '').replace(/State: /gi, '');
}

export const RecentEventsTimeline: React.FC<RecentEventsTimelineProps> = ({
  events,
  onClear,
  backendStatus = 'Online',
  isDemoMode = true,
}) => {
  const [showTechnicalDetails, setShowTechnicalDetails] = useState(false);

  // Sanitize, deduplicate and take latest 5 for the primary list
  const sanitizedEvents = useMemo(() => {
    if (!Array.isArray(events)) return [];
    const cleaned = events
      .filter((ev): ev is TimelineEvent => Boolean(ev))
      .map((ev) => sanitizeTimelineEvent(ev));
    return deduplicateEvents(cleaned);
  }, [events]);

  const latestFiveEvents = useMemo(() => {
    return sanitizedEvents.slice(0, 5);
  }, [sanitizedEvents]);

  const getEventIcon = (event: TimelineEvent) => {
    if (event.severity === 'critical' || event.type === 'fall') {
      return <AlertTriangle className="w-4 h-4 text-red-600" />;
    }
    if (event.severity === 'warning') {
      return <AlertTriangle className="w-4 h-4 text-amber-600" />;
    }
    if (event.type === 'safe' || event.state === 'RESOLVED') {
      return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
    }
    if (event.type === 'presence') {
      return <UserCheck className="w-4 h-4 text-blue-600" />;
    }
    return <Clock className="w-4 h-4 text-slate-500" />;
  };

  return (
    <section
      id="recent-events-section"
      aria-label="What happened recently"
      className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm"
    >
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-lg font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
            What happened recently
          </h3>
          <p className="text-xs text-slate-500">
            Plain-language record of the latest 5 updates
          </p>
        </div>

        {onClear && sanitizedEvents.length > 0 && (
          <button
            onClick={onClear}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
          >
            Clear log
          </button>
        )}
      </div>

      {/* Events List */}
      <div id="events-timeline-list" className="divide-y divide-slate-100 mt-2">
        {latestFiveEvents.length === 0 ? (
          <div className="py-6 text-center text-slate-500 text-sm">
            No recent activity recorded yet.
          </div>
        ) : (
          latestFiveEvents.map((item) => (
            <div
              key={item.id}
              className="py-3 flex items-start gap-3 text-slate-800"
            >
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 shrink-0 mt-0.5">
                {getEventIcon(item)}
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-900">
                  {toPlainLanguage(item)}
                </p>
                <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                  <span className="font-mono">{item.timeString || item.timestamp}</span>
                  {item.room && (
                    <>
                      <span>•</span>
                      <span>{item.room}</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Collapsible Technical Details Section */}
      <div className="mt-4 pt-3 border-t border-slate-100">
        <button
          type="button"
          onClick={() => setShowTechnicalDetails(!showTechnicalDetails)}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <span>Technical details ({sanitizedEvents.length} events total)</span>
          {showTechnicalDetails ? (
            <ChevronUp className="w-3.5 h-3.5" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5" />
          )}
        </button>

        {showTechnicalDetails && (
          <div className="mt-2 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs font-mono text-slate-600 max-h-48 overflow-y-auto space-y-1">
            {sanitizedEvents.map((ev) => (
              <div key={ev.id} className="pb-1 border-b border-slate-200/60 last:border-none">
                <span className="text-slate-400">[{ev.timeString}]</span>{' '}
                <span className="font-bold text-slate-700">{ev.title}</span> —{' '}
                <span className="text-slate-500">{ev.description}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
export default RecentEventsTimeline;
