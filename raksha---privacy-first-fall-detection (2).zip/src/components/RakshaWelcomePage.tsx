import React, { useState, useEffect } from 'react';
import {
  Shield,
  ArrowRight,
  Activity,
  EyeOff,
  Radio,
  HeartPulse,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Lock,
  Bell,
  Sparkles,
  Clock,
  Layers,
  Wifi,
  PhoneCall,
  UserCheck,
  ChevronRight,
  Sliders,
  PlayCircle
} from 'lucide-react';

interface RakshaWelcomePageProps {
  onOpenDashboard: () => void;
}

export const RakshaWelcomePage: React.FC<RakshaWelcomePageProps> = ({ onOpenDashboard }) => {
  const [pulseTick, setPulseTick] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'privacy' | 'radar' | 'escalation'>('privacy');

  useEffect(() => {
    const timer = setInterval(() => {
      setPulseTick((prev) => (prev + 1) % 100);
    }, 1200);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans'] selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Navigation Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50 px-4 sm:px-8 py-3.5 shadow-lg shadow-black/20">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-lg shadow-emerald-900/30 ring-1 ring-emerald-400/30">
              <Shield className="w-5 h-5 text-emerald-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
                  Raksha
                </span>
                <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800/80">
                  Privacy-First Safety
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Continuous Fall Detection &amp; Caregiver Telemetry
              </p>
            </div>
          </div>

          {/* System Status & CTA */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs font-mono text-emerald-400">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Edge AI &amp; Radar Active</span>
            </div>

            <button
              id="open-caregiver-dashboard-nav-btn"
              onClick={onOpenDashboard}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-900/40 hover:shadow-emerald-700/50 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <span>Open Caregiver Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-8 border-b border-slate-800/60 bg-gradient-to-b from-slate-900/50 via-slate-950 to-slate-950">
        {/* Subtle grid background accent */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b12_1px,transparent_1px),linear-gradient(to_bottom,#1e293b12_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>

        <div className="max-w-6xl mx-auto relative z-10 text-center space-y-6">
          {/* Eyebrow Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-800/70 text-emerald-300 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Zero Optical Lenses in Bathrooms • 100% On-Device Biomechanics</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-[1.15]">
            Elderly Fall Detection that Safeguards{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
              Dignity &amp; Privacy
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
            Raksha protects your loved ones 24/7 without sending raw video feeds outside the home.
            Living room video is transformed into mathematical 33-point stick-figure skeletons on local edge silicon,
            while bathrooms are monitored using lens-free 60GHz mmWave radar.
          </p>

          {/* Primary Action Button Bar */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              id="open-caregiver-dashboard-hero-btn"
              onClick={onOpenDashboard}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-base shadow-xl shadow-emerald-500/25 hover:shadow-emerald-400/35 hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer ring-2 ring-emerald-400/50 group"
            >
              <span>Open Caregiver Dashboard</span>
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>

            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>Resident: Eleanor V. (79) • Apt 4B • Telemetry Ready</span>
            </div>
          </div>

          {/* Micro Value Metrics */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-emerald-400 mb-1">
                <EyeOff className="w-4 h-4" />
                <span className="text-xs font-semibold">100% Privacy</span>
              </div>
              <p className="text-xl font-bold text-white">0 Raw Images</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Video discarded in RAM</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-teal-400 mb-1">
                <Radio className="w-4 h-4" />
                <span className="text-xs font-semibold">Bathroom Safety</span>
              </div>
              <p className="text-xl font-bold text-white">mmWave Radar</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Penetrates steam &amp; water</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-cyan-400 mb-1">
                <Clock className="w-4 h-4" />
                <span className="text-xs font-semibold">Fast Response</span>
              </div>
              <p className="text-xl font-bold text-white">&lt; 400 ms</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Edge kinematic inference</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <div className="flex items-center gap-2 text-amber-400 mb-1">
                <Bell className="w-4 h-4" />
                <span className="text-xs font-semibold">Escalation Chain</span>
              </div>
              <p className="text-xl font-bold text-white">30s Auto Alert</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Two-way chime + SMS</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive System Architecture Tabs */}
      <section className="py-12 px-4 sm:px-8 border-b border-slate-800/60">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">
              The Three Pillars of Raksha Protection
            </h2>
            <p className="text-sm text-slate-400 max-w-xl mx-auto">
              How edge artificial intelligence and radio telemetry keep residents safe without surveillance cameras.
            </p>
          </div>

          {/* Tab Selector */}
          <div className="flex justify-center">
            <div className="inline-flex p-1 rounded-xl bg-slate-900 border border-slate-800">
              <button
                onClick={() => setActiveTab('privacy')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'privacy'
                    ? 'bg-emerald-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>1. Living Room Edge AI</span>
              </button>

              <button
                onClick={() => setActiveTab('radar')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'radar'
                    ? 'bg-emerald-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Radio className="w-3.5 h-3.5" />
                <span>2. Bathroom mmWave Radar</span>
              </button>

              <button
                onClick={() => setActiveTab('escalation')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'escalation'
                    ? 'bg-emerald-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Bell className="w-3.5 h-3.5" />
                <span>3. Rapid Escalation Chain</span>
              </button>
            </div>
          </div>

          {/* Tab Panels */}
          <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl">
            {activeTab === 'privacy' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-800">
                    <Cpu className="w-3.5 h-3.5" />
                    <span>On-Device MediaPipe Kinematics</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    Living Room: 33-Point Skeleton Vectorization
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Unlike standard smart home cameras that broadcast video to cloud servers,
                    Raksha uses a lightweight embedded neural model running directly at the camera hardware level.
                  </p>
                  <ul className="space-y-2 text-xs text-slate-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                      <span><strong>Zero cloud video streaming:</strong> Video pixels are instantly overwritten in ephemeral memory.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                      <span><strong>Anonymized stick-figure avatar:</strong> Caregivers only view 3D wireframe joint coordinates (X, Y, Z).</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                      <span><strong>Impact &amp; velocity detection:</strong> Calculates vertical acceleration and torso angle drop in real-time.</span>
                    </li>
                  </ul>
                </div>

                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-slate-400">
                    <span>Edge AI Pipeline Status</span>
                    <span className="text-emerald-400 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      Active (30 FPS)
                    </span>
                  </div>
                  <div className="text-slate-400 space-y-1">
                    <p className="text-emerald-300">✓ Video Buffer: OVERWRITTEN (0 bytes saved)</p>
                    <p className="text-slate-300">✓ Landmarks: 33 joint vectors extracted</p>
                    <p className="text-slate-300">✓ Torso Height: 1.42m (Normal posture)</p>
                    <p className="text-slate-300">✓ Incline Angle: 84° (Standing / Walking)</p>
                    <p className="text-emerald-400">✓ State: NORMAL • No rapid downward trajectory</p>
                  </div>
                  <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500">
                    Hardware: Edge Coral TPU / RK3588 NPU acceleration
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'radar' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 text-xs font-semibold px-2.5 py-1 rounded-md bg-teal-950 text-teal-300 border border-teal-800">
                    <Radio className="w-3.5 h-3.5" />
                    <span>Contactless 60GHz FMCW Radar</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    Bathroom: Zero Optical Cameras or Lenses
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Over 80% of dangerous elderly falls occur in bathrooms or during night transitions.
                    Placing cameras in bathrooms is intrusive and unacceptable. Raksha solves this with
                    micro-radar sweeps.
                  </p>
                  <ul className="space-y-2 text-xs text-slate-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-400 mt-0.5 shrink-0" />
                      <span><strong>Operates through dense steam &amp; darkness:</strong> High-frequency radar waves are unaffected by humidity.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-400 mt-0.5 shrink-0" />
                      <span><strong>Micro-Doppler respiration sensing:</strong> Detects breathing and subtle movements even while motionless.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-400 mt-0.5 shrink-0" />
                      <span><strong>Floor-level proximity trigger:</strong> Identifies if body mass suddenly remains on the floor plane.</span>
                    </li>
                  </ul>
                </div>

                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-slate-400">
                    <span>Bathroom Radar Gateway</span>
                    <span className="text-teal-400 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
                      Radar Beam Active
                    </span>
                  </div>
                  <div className="text-slate-400 space-y-1">
                    <p className="text-teal-300">✓ RF Frequency: 60 - 64 GHz Frequency Modulated</p>
                    <p className="text-slate-300">✓ Optical Hardware: NONE (No camera, no glass)</p>
                    <p className="text-slate-300">✓ Detected Distance: 1.84 m (Range Gate #4)</p>
                    <p className="text-slate-300">✓ Micro-Movement: Breathing detected (16 bpm)</p>
                    <p className="text-teal-400">✓ Floor Height Z-axis: 0.85m (Sitting / Upright)</p>
                  </div>
                  <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500">
                    Interference Shielding: Multi-path reflection filtering enabled
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'escalation' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-2 text-xs font-semibold px-2.5 py-1 rounded-md bg-amber-950 text-amber-300 border border-amber-800">
                    <Bell className="w-3.5 h-3.5" />
                    <span>Autonomous Escalation Protocol</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    30-Second Verification &amp; Caregiver Alert
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Falls require immediate attention, yet false alarms erode trust. Raksha uses a proven
                    two-tier response workflow that reassures the resident while keeping emergency teams on standby.
                  </p>
                  <ul className="space-y-2 text-xs text-slate-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                      <span><strong>Stage 1 - In-Room Audio Chime:</strong> Friendly voice asks &quot;Eleanor, are you okay? Say yes or stand up to cancel.&quot;</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                      <span><strong>Stage 2 - Caregiver Push &amp; SMS:</strong> Dashboard displays red emergency banner with live biomechanics and location.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                      <span><strong>Stage 3 - Emergency Dispatch:</strong> Automatic escalation if unattended after 30 seconds.</span>
                    </li>
                  </ul>
                </div>

                <div className="p-5 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-slate-400">
                    <span>Escalation Engine Rules</span>
                    <span className="text-amber-400 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                      Standby
                    </span>
                  </div>
                  <div className="text-slate-400 space-y-1">
                    <p className="text-slate-300">T + 0.0s: Sudden downward acceleration &gt; 2.4g</p>
                    <p className="text-slate-300">T + 0.4s: Torso horizontal immobility confirmed</p>
                    <p className="text-amber-300">T + 1.0s: In-Room Verification Chime triggered</p>
                    <p className="text-amber-300">T + 5.0s: Caregiver dashboard alerts triggered</p>
                    <p className="text-rose-400">T + 30.0s: Emergency dispatch notification sent</p>
                  </div>
                  <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500">
                    One-touch caregiver override or cancellation available at all times
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Live System Preview / Dashboard Quick Launch Card */}
      <section className="py-12 px-4 sm:px-8 border-b border-slate-800/60 bg-slate-900/30">
        <div className="max-w-5xl mx-auto rounded-2xl border border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-white">Live Caregiver Monitoring System</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  READY
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Monitored Residence: Apt 4B • Eleanor Vance (Age 79) • High Care Priority
              </p>
            </div>

            <button
              id="open-caregiver-dashboard-card-btn"
              onClick={onOpenDashboard}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-md shadow-emerald-500/30 transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>Launch Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Zone 1: Living Room */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">Zone 1: Living Room</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                  NORMAL
                </span>
              </div>
              <p className="text-xs text-slate-400">
                MediaPipe 33-point skeletal kinematics. Person detected upright and seated.
              </p>
              <div className="text-[11px] font-mono text-emerald-400 flex items-center gap-1.5 pt-1">
                <Activity className="w-3.5 h-3.5" />
                <span>Torso Angle: 86° • Steady</span>
              </div>
            </div>

            {/* Zone 2: Bathroom */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">Zone 2: Bathroom</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-mono">
                  VACANT
                </span>
              </div>
              <p className="text-xs text-slate-400">
                60GHz mmWave Radar. Zero cameras or microphones. Range gate clear.
              </p>
              <div className="text-[11px] font-mono text-teal-400 flex items-center gap-1.5 pt-1">
                <Radio className="w-3.5 h-3.5" />
                <span>Radar Sweep: Active</span>
              </div>
            </div>

            {/* Subsystems */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">Subsystems Health</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                  100% ONLINE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Camera edge node, inference model, radar transceiver, and alert escalation server.
              </p>
              <div className="text-[11px] font-mono text-cyan-400 flex items-center gap-1.5 pt-1">
                <Wifi className="w-3.5 h-3.5" />
                <span>Latency: 14ms (Local LAN)</span>
              </div>
            </div>
          </div>

          <div className="pt-2 text-center">
            <button
              id="open-caregiver-dashboard-bottom-btn"
              onClick={onOpenDashboard}
              className="inline-flex items-center gap-2 text-sm font-bold text-emerald-400 hover:text-emerald-300 underline underline-offset-4 cursor-pointer"
            >
              <span>Proceed to interactive 3D skeleton view &amp; simulation controls →</span>
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 px-4 sm:px-8 bg-slate-950 text-slate-500 text-xs border-t border-slate-900">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-slate-400">
            <Shield className="w-4 h-4 text-emerald-500" />
            <span className="font-semibold text-slate-300">Raksha Fall-Detection System</span>
            <span>• Built for Privacy, Safety &amp; Dignity</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onOpenDashboard}
              className="text-emerald-400 hover:text-emerald-300 transition-colors font-medium cursor-pointer"
            >
              Open Caregiver Dashboard
            </button>
            <span>•</span>
            <span>Local Edge AI Architecture</span>
            <span>•</span>
            <span>HIPAA Compliant</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
