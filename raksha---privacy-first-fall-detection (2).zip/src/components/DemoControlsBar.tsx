import React, { useState } from 'react';
import {
  RotateCcw,
  AlertTriangle,
  Radio,
  PhoneCall,
  Sparkles,
  CheckCircle2,
  Timer,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Sliders,
  Bug,
  VideoOff,
  WifiOff,
  Waves,
  RefreshCw,
} from 'lucide-react';
import { FallState, ApiConnectionState, RadarTargetState } from '../types';
import { ForcedLandmarkError } from './Skeleton3DViewer';

interface DemoControlsBarProps {
  onSimulateLivingRoomFall: () => void;
  onSimulateBathroomPresence: () => void;
  onSimulateNonHumanMovement?: () => void;
  onSimulateBathroomFall?: () => void;
  onSimulateNoResponse: () => void;
  onMarkResidentSafe: () => void;
  onResetDemo: () => void;
  activeScenario?: string | null;
  activeState?: FallState;
  activeRadarState?: RadarTargetState;
  onSelectState?: (state: FallState) => void;
  onSelectRadarState?: (state: RadarTargetState) => void;
  isDemoMode?: boolean;
  onToggleDemoMode?: (enabled: boolean) => void;
  apiStatus?: ApiConnectionState;
  onOpenApiSettings?: () => void;
  forcedLandmarkError?: ForcedLandmarkError;
  onSetForcedLandmarkError?: (err: ForcedLandmarkError) => void;
  backendStatus?: 'Online' | 'Offline';
  onToggleBackend?: () => void;
  cameraConnected?: boolean;
  onToggleCamera?: () => void;
  radarConnected?: boolean;
  onToggleRadar?: () => void;
  onInjectDuplicateEvents?: () => void;
  onInjectInvalidStatusEvent?: () => void;
  onClearEvents?: () => void;
}

export const DemoControlsBar: React.FC<DemoControlsBarProps> = ({
  onSimulateLivingRoomFall,
  onSimulateBathroomPresence,
  onSimulateNonHumanMovement,
  onSimulateBathroomFall,
  onSimulateNoResponse,
  onMarkResidentSafe,
  onResetDemo,
  activeScenario,
  activeState = 'NORMAL',
  activeRadarState = 'NO_TARGET',
  onSelectState,
  onSelectRadarState,
  isDemoMode = true,
  onToggleDemoMode,
  apiStatus,
  onOpenApiSettings,
  forcedLandmarkError = null,
  onSetForcedLandmarkError,
  backendStatus = 'Online',
  onToggleBackend,
  cameraConnected = true,
  onToggleCamera,
  radarConnected = true,
  onToggleRadar,
  onInjectDuplicateEvents,
  onInjectInvalidStatusEvent,
  onClearEvents,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const radarStates: { id: RadarTargetState; label: string; desc: string }[] = [
    { id: 'NO_TARGET', label: '1. No Target', desc: 'Bathroom empty' },
    { id: 'TARGET_CHECKING', label: '2. Target Checking', desc: 'Checking movement…' },
    { id: 'HUMAN_LIKELY', label: '3. Human Likely', desc: 'Verified 3+ samples' },
    { id: 'NON_HUMAN_LIKELY', label: '4. Non-Human Likely', desc: 'Curtain/fan/pet filter' },
    { id: 'POSSIBLE_FALL', label: '5. Possible Fall', desc: 'Low-position impact' },
    { id: 'CHECKING_RESPONSE', label: '6. Checking Response', desc: '20s countdown' },
    { id: 'ALERT_SENT', label: '7. Alert Sent', desc: 'Caregiver notified' },
  ];

  return (
    <aside
      id="demo-controls-panel"
      aria-label="Caregiver Simulation &amp; Demo Tools"
      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
    >
      {/* Header Bar */}
      <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 border border-amber-200">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
                Testing &amp; Demo Tools
              </h3>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
                Radar Verification Enabled
              </span>
            </div>
            <p className="text-xs text-slate-600">
              Simulate radar multi-sample checking (2–5s window), non-human filtering, and fall transitions
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
          >
            <span>{isOpen ? 'Hide simulation controls' : 'Show simulation controls'}</span>
            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Simulation Buttons */}
      <div className="p-4 sm:p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* 1. Simulate Living Room Fall */}
          <button
            id="demo-btn-living-room-fall"
            onClick={onSimulateLivingRoomFall}
            className="min-h-[48px] px-3 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 active:bg-amber-200 text-amber-900 border border-amber-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer text-center"
            title="Simulate possible fall in living room"
          >
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>Living Room Fall</span>
          </button>

          {/* 2. Simulate Bathroom Radar (with 3-sample verification) */}
          <button
            id="demo-btn-bathroom-presence"
            onClick={onSimulateBathroomPresence}
            className="min-h-[48px] px-3 py-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:bg-blue-200 text-blue-900 border border-blue-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer text-center"
            title="Trigger radar verification (Checking movement… -> Human likely over 3 samples)"
          >
            <Radio className="w-4 h-4 text-blue-700 shrink-0" />
            <span>Radar Presence</span>
          </button>

          {/* 3. Simulate Non-Human Movement (Filter Test) */}
          {onSimulateNonHumanMovement && (
            <button
              id="demo-btn-non-human-movement"
              onClick={onSimulateNonHumanMovement}
              className="min-h-[48px] px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 border border-slate-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer text-center"
              title="Simulate curtain flutter or pet movement (filtered out of emergency alert)"
            >
              <Waves className="w-4 h-4 text-slate-600 shrink-0" />
              <span>Non-Human Echo</span>
            </button>
          )}

          {/* 4. Simulate Bathroom Fall (Low-position impact) */}
          {onSimulateBathroomFall && (
            <button
              id="demo-btn-bathroom-fall"
              onClick={onSimulateBathroomFall}
              className="min-h-[48px] px-3 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 active:bg-red-200 text-red-900 border border-red-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer text-center"
              title="Simulate sudden transition & low-position impact in bathroom"
            >
              <AlertTriangle className="w-4 h-4 text-red-700 shrink-0" />
              <span>Bathroom Fall</span>
            </button>
          )}

          {/* 5. Mark Resident Safe */}
          <button
            id="demo-btn-mark-safe"
            onClick={onMarkResidentSafe}
            className="min-h-[48px] px-3 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 text-emerald-900 border border-emerald-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer text-center"
            title="Mark resident safe and resolve alert"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>Mark Safe</span>
          </button>

          {/* 6. Reset All Demo */}
          <button
            id="demo-btn-reset-all"
            onClick={onResetDemo}
            className="min-h-[48px] px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 border border-slate-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer text-center"
            title="Reset system back to normal"
          >
            <RotateCcw className="w-4 h-4 text-slate-600 shrink-0" />
            <span>Reset All</span>
          </button>
        </div>

        {/* Collapsible Advanced Technical Testing Panel */}
        {isOpen && (
          <div className="pt-4 border-t border-slate-200 space-y-4">
            {/* 7-State Radar Verification Machine Selector */}
            {onSelectRadarState && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    Radar Human-Presence State Machine (7 States)
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Current: <strong>{activeRadarState}</strong>
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                  {radarStates.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => onSelectRadarState(s.id)}
                      className={`p-2 rounded-xl text-xs font-semibold text-left border transition-all cursor-pointer ${
                        activeRadarState === s.id
                          ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span className="block font-bold truncate">{s.label}</span>
                      <span
                        className={`text-[10px] block truncate ${
                          activeRadarState === s.id ? 'text-slate-300' : 'text-slate-500'
                        }`}
                      >
                        {s.desc}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Error Injection and Device Toggles */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex flex-wrap items-center gap-2">
                {onToggleCamera && (
                  <button
                    onClick={onToggleCamera}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                  >
                    <VideoOff className="w-3.5 h-3.5 text-slate-500" />
                    <span>{cameraConnected ? 'Disconnect Camera' : 'Reconnect Camera'}</span>
                  </button>
                )}

                {onToggleRadar && (
                  <button
                    onClick={onToggleRadar}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                  >
                    <WifiOff className="w-3.5 h-3.5 text-slate-500" />
                    <span>{radarConnected ? 'Disconnect Radar' : 'Reconnect Radar'}</span>
                  </button>
                )}

                {onToggleBackend && (
                  <button
                    onClick={onToggleBackend}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-slate-500" />
                    <span>{backendStatus === 'Online' ? 'Simulate Server Outage' : 'Restore Server'}</span>
                  </button>
                )}

                {onSetForcedLandmarkError && (
                  <button
                    onClick={() =>
                      onSetForcedLandmarkError(forcedLandmarkError ? null : 'missing')
                    }
                    className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Bug className="w-3.5 h-3.5 text-slate-500" />
                    <span>{forcedLandmarkError ? 'Clear Pose Error' : 'Inject Pose Error'}</span>
                  </button>
                )}
              </div>

              {onClearEvents && (
                <button
                  onClick={onClearEvents}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Clear event history
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
export default DemoControlsBar;
