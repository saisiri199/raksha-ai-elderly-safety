import React, { useMemo } from 'react';
import { LivingRoomStatus } from '../types';
import { VideoOff, AlertTriangle } from 'lucide-react';

interface SkeletonVisualizerProps {
  status: LivingRoomStatus;
  customPose?: 'standing' | 'sitting' | 'fallen';
  cameraConnected?: boolean;
  isPoseUnavailable?: boolean;
}

interface Point3D {
  id: number;
  x: number;
  y: number;
  z?: number;
  name: string;
}

// 33 Landmark configurations in normalized 0-100 coordinates
export const SkeletonVisualizer: React.FC<SkeletonVisualizerProps> = ({
  status,
  customPose,
  cameraConnected = true,
  isPoseUnavailable = false,
}) => {
  const activePose = useMemo(() => {
    if (customPose) return customPose;
    if (
      status === 'Possible Fall' ||
      status === 'Checking Response' ||
      status === 'Alert Sent' ||
      status === 'Escalated'
    ) {
      return 'fallen';
    }
    return 'standing';
  }, [status, customPose]);

  // Points for Standing Pose (Centered upright, 33 points)
  const standingPoints: Point3D[] = [
    { id: 0, x: 50, y: 15, name: 'Nose' },
    { id: 1, x: 48.5, y: 14, name: 'L Eye Inner' },
    { id: 2, x: 47.5, y: 14, name: 'L Eye' },
    { id: 3, x: 46.5, y: 14, name: 'L Eye Outer' },
    { id: 4, x: 51.5, y: 14, name: 'R Eye Inner' },
    { id: 5, x: 52.5, y: 14, name: 'R Eye' },
    { id: 6, x: 53.5, y: 14, name: 'R Eye Outer' },
    { id: 7, x: 45, y: 16, name: 'L Ear' },
    { id: 8, x: 55, y: 16, name: 'R Ear' },
    { id: 9, x: 48.5, y: 18, name: 'Mouth L' },
    { id: 10, x: 51.5, y: 18, name: 'Mouth R' },
    { id: 11, x: 40, y: 24, name: 'L Shoulder' },
    { id: 12, x: 60, y: 24, name: 'R Shoulder' },
    { id: 13, x: 35, y: 38, name: 'L Elbow' },
    { id: 14, x: 65, y: 38, name: 'R Elbow' },
    { id: 15, x: 32, y: 50, name: 'L Wrist' },
    { id: 16, x: 68, y: 50, name: 'R Wrist' },
    { id: 17, x: 30, y: 54, name: 'L Pinky' },
    { id: 18, x: 70, y: 54, name: 'R Pinky' },
    { id: 19, x: 31, y: 55, name: 'L Index' },
    { id: 20, x: 69, y: 55, name: 'R Index' },
    { id: 21, x: 33, y: 52, name: 'L Thumb' },
    { id: 22, x: 67, y: 52, name: 'R Thumb' },
    { id: 23, x: 43, y: 54, name: 'L Hip' },
    { id: 24, x: 57, y: 54, name: 'R Hip' },
    { id: 25, x: 42, y: 70, name: 'L Knee' },
    { id: 26, x: 58, y: 70, name: 'R Knee' },
    { id: 27, x: 41, y: 88, name: 'L Ankle' },
    { id: 28, x: 59, y: 88, name: 'R Ankle' },
    { id: 29, x: 40, y: 91, name: 'L Heel' },
    { id: 30, x: 60, y: 91, name: 'R Heel' },
    { id: 31, x: 38, y: 93, name: 'L Foot Index' },
    { id: 32, x: 62, y: 93, name: 'R Foot Index' },
  ];

  // Points for Fallen Pose (Horizontal across bottom plane, z-collapsed)
  const fallenPoints: Point3D[] = [
    { id: 0, x: 18, y: 76, name: 'Nose' },
    { id: 1, x: 19, y: 75, name: 'L Eye Inner' },
    { id: 2, x: 20, y: 74.5, name: 'L Eye' },
    { id: 3, x: 21, y: 74, name: 'L Eye Outer' },
    { id: 4, x: 19, y: 77, name: 'R Eye Inner' },
    { id: 5, x: 20, y: 77.5, name: 'R Eye' },
    { id: 6, x: 21, y: 78, name: 'R Eye Outer' },
    { id: 7, x: 23, y: 73, name: 'L Ear' },
    { id: 8, x: 23, y: 79, name: 'R Ear' },
    { id: 9, x: 19, y: 75.5, name: 'Mouth L' },
    { id: 10, x: 19, y: 76.5, name: 'Mouth R' },
    { id: 11, x: 29, y: 71, name: 'L Shoulder' },
    { id: 12, x: 31, y: 83, name: 'R Shoulder' },
    { id: 13, x: 22, y: 64, name: 'L Elbow' },
    { id: 14, x: 26, y: 90, name: 'R Elbow' },
    { id: 15, x: 15, y: 60, name: 'L Wrist' },
    { id: 16, x: 20, y: 92, name: 'R Wrist' },
    { id: 17, x: 13, y: 59, name: 'L Pinky' },
    { id: 18, x: 18, y: 93, name: 'R Pinky' },
    { id: 19, x: 12, y: 60, name: 'L Index' },
    { id: 20, x: 17, y: 92.5, name: 'R Index' },
    { id: 21, x: 14, y: 62, name: 'L Thumb' },
    { id: 22, x: 19, y: 90.5, name: 'R Thumb' },
    { id: 23, x: 53, y: 73, name: 'L Hip' },
    { id: 24, x: 55, y: 82, name: 'R Hip' },
    { id: 25, x: 71, y: 70, name: 'L Knee' },
    { id: 26, x: 74, y: 84, name: 'R Knee' },
    { id: 27, x: 86, y: 74, name: 'L Ankle' },
    { id: 28, x: 89, y: 86, name: 'R Ankle' },
    { id: 29, x: 88, y: 76, name: 'L Heel' },
    { id: 30, x: 91, y: 88, name: 'R Heel' },
    { id: 31, x: 92, y: 72, name: 'L Foot Index' },
    { id: 32, x: 94, y: 84, name: 'R Foot Index' },
  ];

  // Standard connections between MediaPipe 33 keypoints
  const connections: [number, number][] = [
    // Face outline
    [0, 1], [1, 2], [2, 3], [3, 7],
    [0, 4], [4, 5], [5, 6], [6, 8],
    [9, 10],
    // Torso box
    [11, 12], [11, 23], [12, 24], [23, 24],
    // Left arm
    [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19],
    // Right arm
    [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20],
    // Left leg
    [23, 25], [25, 27], [27, 29], [27, 31], [29, 31],
    // Right leg
    [24, 26], [26, 28], [28, 30], [28, 32], [30, 32],
  ];

  const points = activePose === 'fallen' ? fallenPoints : standingPoints;
  const isFallen = activePose === 'fallen';

  const strokeColor = isFallen ? '#ef4444' : '#059669';
  const nodeFill = isFallen ? '#f87171' : '#34d399';
  const glowColor = isFallen ? 'rgba(239, 68, 68, 0.4)' : 'rgba(16, 185, 129, 0.3)';

  return (
    <div
      id="living-room-skeleton-container"
      className="relative w-full aspect-4/3 max-h-72 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col justify-between p-3 select-none"
    >
      {/* Privacy Watermark grid lines & coordinates */}
      <div className="absolute inset-0 opacity-15 pointer-events-none bg-[linear-gradient(to_right,#334155_1px,transparent_1px),linear-gradient(to_bottom,#334155_1px,transparent_1px)] bg-[size:24px_24px]" />

      {/* Top telemetry HUD inside skeleton view */}
      <div className="relative z-10 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-slate-900/90 border border-slate-700/80 font-mono text-[11px]">
          {!cameraConnected ? (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-amber-300 font-bold">Waiting for camera data</span>
            </>
          ) : isPoseUnavailable ? (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
              <span className="text-rose-300 font-bold">Pose data unavailable</span>
            </>
          ) : (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-400">33-POINT VECTOR MESH</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-2 font-mono text-[10px] text-slate-400">
          <span>ALT: {isFallen ? '0.12m (FLOOR)' : '1.68m (STANDING)'}</span>
          <span className="text-slate-600">|</span>
          <span>CONF: {isFallen ? '96.4%' : '98.8%'}</span>
        </div>
      </div>

      {/* Sensor Error Overlays if camera disconnected or pose unavailable */}
      {!cameraConnected && (
        <div className="absolute inset-0 z-20 bg-slate-950/90 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center">
          <VideoOff className="w-6 h-6 text-amber-400 mb-1.5 animate-pulse" />
          <span className="text-xs font-bold text-amber-300 font-mono">Waiting for camera data</span>
          <span className="text-[10px] text-slate-400 mt-0.5">Camera disconnected • Pose ingest paused</span>
        </div>
      )}

      {cameraConnected && isPoseUnavailable && (
        <div className="absolute inset-0 z-20 bg-slate-950/90 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center">
          <AlertTriangle className="w-6 h-6 text-rose-400 mb-1.5" />
          <span className="text-xs font-bold text-rose-300 font-mono">Pose data unavailable</span>
          <span className="text-[10px] text-slate-400 mt-0.5">Malformed landmark data detected</span>
        </div>
      )}

      {/* Main SVG Render of 33-Point Skeleton */}
      <div className="relative z-10 flex-1 flex items-center justify-center my-1">
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full max-h-56 filter drop-shadow-[0_0_8px_var(--glow)] transition-all duration-700 ease-out"
          style={{ '--glow': glowColor } as React.CSSProperties}
        >
          {/* Ground Plane reference line */}
          <line
            x1="5"
            y1="93"
            x2="95"
            y2="93"
            stroke={isFallen ? '#dc2626' : '#334155'}
            strokeWidth="1.2"
            strokeDasharray="3 3"
            opacity="0.7"
          />
          <text
            x="94"
            y="91"
            fill="#64748b"
            fontSize="3.5"
            textAnchor="end"
            fontFamily="monospace"
          >
            FLOOR REFERENCE
          </text>

          {/* Skeleton Bones / Connections */}
          {connections.map(([startIdx, endIdx], i) => {
            const p1 = points[startIdx];
            const p2 = points[endIdx];
            if (!p1 || !p2) return null;
            return (
              <line
                key={`bone-${i}`}
                x1={p1.x}
                y1={p1.y}
                x2={p2.x}
                y2={p2.y}
                stroke={strokeColor}
                strokeWidth={isFallen ? '2' : '1.8'}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            );
          })}

          {/* 33 Skeleton Keypoint Nodes */}
          {points.map((pt) => {
            const isHead = pt.id <= 10;
            const isPrimary = [11, 12, 23, 24, 25, 26, 27, 28].includes(pt.id);
            const r = isHead ? 1.4 : isPrimary ? 2.2 : 1.7;
            return (
              <g key={`pt-${pt.id}`}>
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r={r}
                  fill={nodeFill}
                  stroke="#0f172a"
                  strokeWidth="0.8"
                  className="transition-all duration-700 ease-out"
                />
              </g>
            );
          })}

          {/* Torso Center of Gravity Marker */}
          {(() => {
            const p11 = points[11];
            const p12 = points[12];
            const p23 = points[23];
            const p24 = points[24];
            if (p11 && p12 && p23 && p24) {
              const cogX = (p11.x + p12.x + p23.x + p24.x) / 4;
              const cogY = (p11.y + p12.y + p23.y + p24.y) / 4;
              return (
                <g>
                  <circle
                    cx={cogX}
                    cy={cogY}
                    r="3.5"
                    fill="none"
                    stroke={isFallen ? '#ef4444' : '#38bdf8'}
                    strokeWidth="1"
                    strokeDasharray="1.5 1.5"
                  />
                  <circle
                    cx={cogX}
                    cy={cogY}
                    r="1.2"
                    fill={isFallen ? '#ef4444' : '#38bdf8'}
                  />
                </g>
              );
            }
            return null;
          })()}
        </svg>
      </div>

      {/* Bottom Privacy Overlay Badge */}
      <div className="relative z-10 flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px] text-slate-400 font-mono">
        <span className="flex items-center gap-1 text-slate-300">
          <svg
            className="w-3 h-3 text-emerald-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
            />
          </svg>
          ANONYMOUS BLIND EXTRACTION
        </span>
        <span className="text-slate-400">
          {isFallen ? '⚠ FLR HORIZONTAL AXIS' : '✓ VERTICAL POSTURE'}
        </span>
      </div>
    </div>
  );
};
