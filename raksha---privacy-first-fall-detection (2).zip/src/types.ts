export type FallState =
  | 'NORMAL'
  | 'POSSIBLE_FALL'
  | 'CHECKING_RESPONSE'
  | 'ALERT_SENT'
  | 'RESOLVED'
  | 'ESCALATED';

export type LivingRoomStatus =
  | FallState
  | 'Normal'
  | 'Possible Fall'
  | 'Checking Response'
  | 'Alert Sent'
  | 'Resolved'
  | 'Escalated';

export type PresenceStatus = 'Presence detected' | 'Not detected';
export type MovementStatus = 'Movement detected' | 'Low movement' | 'Static breathing' | 'No movement';

export type RadarTargetState =
  | 'NO_TARGET'
  | 'TARGET_CHECKING'
  | 'HUMAN_LIKELY'
  | 'NON_HUMAN_LIKELY'
  | 'POSSIBLE_FALL'
  | 'CHECKING_RESPONSE'
  | 'ALERT_SENT';

export type RadarConfidenceLevel =
  | 'Human likely'
  | 'Needs checking'
  | 'Non-human movement likely'
  | 'No target';

export interface RadarSample {
  timestamp: number;
  presence: boolean;
  movement: boolean;
  distanceGate: number;
  distanceMeters: number;
  signalEnergy: number;
  stabilityScore: number;
  isLowPositionImpact?: boolean;
  targetProfile?: 'human_candidate' | 'micro_flutter' | 'pet_or_debris' | 'low_position_impact';
}

export interface RadarVerificationState {
  state: RadarTargetState;
  confidence: RadarConfidenceLevel;
  consecutiveReadings: number;
  sampleCount: number;
  presenceDurationSec: number;
  movementDurationSec: number;
  distanceGate: number;
  distanceMeters: number;
  signalStabilityPct: number;
  lastEvaluationReason: string;
  isVerifying: boolean;
  rawSamples: RadarSample[];
}

export type AlertSeverity = 'critical' | 'warning' | 'info' | 'success';

export interface EmergencyAlert {
  isActive: boolean;
  type: 'living_room_fall' | 'bathroom_inactivity' | 'manual_panic' | null;
  state: FallState;
  room: string;
  location: string;
  timestamp: string;
  confidence: number;
  countdownSeconds: number;
  maxCountdown: number;
  status: 'pending' | 'checking' | 'escalated' | 'resolved' | 'safe';
  acknowledged: boolean;
  residentResponded: boolean;
  details: string;
}

export interface TimelineEvent {
  id: string;
  timestamp: string;
  timeString: string;
  room: 'Living Room' | 'Bathroom' | 'System' | 'Resident';
  type: 'fall' | 'presence' | 'alert' | 'safe' | 'system' | 'sensor';
  severity: AlertSeverity;
  title: string;
  description: string;
  state?: FallState;
  dataSource?: 'simulated' | 'real';
}

export interface SensorStatus {
  id: string;
  name: string;
  location: string;
  model: string;
  type: 'edge_vision_tpu' | 'mmwave_radar' | 'gateway_hub';
  status: 'Online' | 'Active' | 'Optimal' | 'Degraded' | 'Offline';
  latencyMs: number;
  privacyGuarantee: string;
  lastHeartbeat: string;
}

export type ConnectionStatus = 'Connected' | 'Disconnected';
export type ReadyStatus = 'Ready' | 'Unavailable';
export type OnlineStatus = 'Online' | 'Offline';

export interface SystemHealthData {
  cameraModule: ConnectionStatus;
  mediaPipe: ReadyStatus;
  bathroomRadar: ConnectionStatus;
  backend: OnlineStatus;
  lastCameraEvent: string;
  lastRadarEvent: string;
  lastDashboardUpdate: string;
}

export type DataSourceMode = 'demo' | 'live_api';

export interface ApiConnectionState {
  status: 'connected' | 'connecting' | 'disconnected' | 'error';
  endpoint: string;
  latencyMs: number;
  lastChecked: string;
  errorMessage?: string;
  isRealData: boolean;
  httpStatus?: number;
}
