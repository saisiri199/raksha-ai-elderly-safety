import React, { useState } from 'react';
import {
  Radio,
  EyeOff,
  CheckCircle2,
  AlertTriangle,
  Activity,
  UserCheck,
  UserX,
  ChevronDown,
  ChevronUp,
  Clock,
  Waves,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { PresenceStatus, MovementStatus, RadarVerificationState } from '../types';

interface BathroomCardProps {
  radarState?: RadarVerificationState;
  presence?: PresenceStatus;
  movement?: MovementStatus;
  sensorStatus?: 'Online' | 'Calibrating' | 'Offline';
  radarConnected?: boolean;
  dwellSeconds?: number;
  distanceMeters?: number;
  isDemoMode?: boolean;
}

export const BathroomCard: React.FC<BathroomCardProps> = ({
  radarState,
  presence = 'Not detected',
  movement = 'No movement',
  sensorStatus = 'Online',
  radarConnected = true,
  dwellSeconds = 0,
  distanceMeters = 0,
  isDemoMode = true,
}) => {
  const [showTechnicalDetails, setShowTechnicalDetails] = useState(false);

  const isDisconnected = sensorStatus === 'Offline' || !radarConnected;

  // Use radarState if provided, otherwise fallback to backward-compatible presence
  const currentRadarState = radarState?.state || (presence === 'Presence detected' ? 'HUMAN_LIKELY' : 'NO_TARGET');
  const confidence = radarState?.confidence || (presence === 'Presence detected' ? 'Human likely' : 'No target');
  const consecutiveReadings = radarState?.consecutiveReadings ?? (presence === 'Presence detected' ? 3 : 0);
  const stabilityPct = radarState?.signalStabilityPct ?? (presence === 'Presence detected' ? 92 : 0);
  const distance = radarState?.distanceMeters ?? distanceMeters;
  const gate = radarState?.distanceGate ?? 2;
  const dwellSec = dwellSeconds || (radarState?.presenceDurationSec ? Math.round(radarState.presenceDurationSec) : 0);

  const formatDwell = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}m ${s < 10 ? '0' : ''}${s}s`;
  };

  // Determine header status text, badge style, and icon
  let statusText = 'Bathroom is empty';
  let statusBadgeClass = 'bg-slate-100 text-slate-700 border-slate-200';
  let StatusIcon = CheckCircle2;

  if (isDisconnected) {
    statusText = 'Please check the bathroom';
    statusBadgeClass = 'bg-amber-50 text-amber-900 border-amber-300';
    StatusIcon = AlertTriangle;
  } else if (
    currentRadarState === 'POSSIBLE_FALL' ||
    currentRadarState === 'CHECKING_RESPONSE' ||
    currentRadarState === 'ALERT_SENT'
  ) {
    statusText = 'Please check the bathroom';
    statusBadgeClass = 'bg-red-50 text-red-900 border-red-300 ring-2 ring-red-100 animate-pulse';
    StatusIcon = AlertTriangle;
  } else if (currentRadarState === 'TARGET_CHECKING') {
    statusText = 'Checking movement…';
    statusBadgeClass = 'bg-amber-50 text-amber-900 border-amber-300';
    StatusIcon = RefreshCw;
  } else if (currentRadarState === 'HUMAN_LIKELY') {
    statusText = 'Bathroom is occupied';
    statusBadgeClass = 'bg-blue-50 text-blue-900 border-blue-200';
    StatusIcon = UserCheck;
  } else if (currentRadarState === 'NON_HUMAN_LIKELY') {
    statusText = 'Non-human movement';
    statusBadgeClass = 'bg-slate-100 text-slate-800 border-slate-300';
    StatusIcon = Waves;
  }

  return (
    <article
      id="bathroom-card"
      className={`bg-white rounded-2xl border p-5 sm:p-6 shadow-sm flex flex-col justify-between transition-all ${
        currentRadarState === 'POSSIBLE_FALL' ||
        currentRadarState === 'CHECKING_RESPONSE' ||
        currentRadarState === 'ALERT_SENT'
          ? 'border-red-400 ring-2 ring-red-100'
          : 'border-slate-200'
      }`}
    >
      <div className="space-y-4">
        {/* Header: Room Name & Large Status Text */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Room 2
              </span>
              <span className="text-slate-300">•</span>
              <span className="text-xs text-slate-600 font-medium">24GHz Radar Presence Sensor</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
              Bathroom
            </h3>
          </div>

          {/* Large Status Text */}
          <div
            id="bathroom-status-badge"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl border text-sm font-bold ${statusBadgeClass}`}
          >
            <StatusIcon
              className={`w-5 h-5 shrink-0 ${
                currentRadarState === 'TARGET_CHECKING' ? 'animate-spin text-amber-600' : ''
              }`}
            />
            <span className="text-base">{statusText}</span>
          </div>
        </div>

        {/* Simple explanation banner */}
        <div className="flex items-center gap-2.5 p-3 rounded-xl bg-blue-50/80 border border-blue-100 text-blue-900">
          <EyeOff className="w-5 h-5 text-blue-700 shrink-0" />
          <span className="text-sm font-semibold">
            Bathroom sensor — no camera used.
          </span>
        </div>

        {/* 3 Main Status Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* 1. Target presence & verification confidence */}
          <div
            id="bathroom-presence-box"
            className={`p-3.5 rounded-xl border flex flex-col justify-between ${
              currentRadarState === 'TARGET_CHECKING'
                ? 'bg-amber-50 border-amber-300 text-amber-950'
                : currentRadarState === 'HUMAN_LIKELY'
                ? 'bg-blue-50 border-blue-200 text-blue-950'
                : currentRadarState === 'NON_HUMAN_LIKELY'
                ? 'bg-slate-100 border-slate-300 text-slate-900'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-600">Verification</span>
              <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-white/80 border border-slate-200 text-slate-700">
                {confidence}
              </span>
            </div>

            <div className="flex items-center gap-2 mt-2">
              {currentRadarState === 'TARGET_CHECKING' ? (
                <>
                  <RefreshCw className="w-5 h-5 text-amber-600 animate-spin shrink-0" />
                  <span id="presence-status-text" className="font-bold text-sm text-amber-900">
                    Checking movement…
                  </span>
                </>
              ) : currentRadarState === 'HUMAN_LIKELY' ? (
                <>
                  <UserCheck className="w-5 h-5 text-blue-600 shrink-0" />
                  <span id="presence-status-text" className="font-bold text-base text-blue-900">
                    Human likely
                  </span>
                </>
              ) : currentRadarState === 'NON_HUMAN_LIKELY' ? (
                <>
                  <Waves className="w-5 h-5 text-slate-600 shrink-0" />
                  <span id="presence-status-text" className="font-bold text-sm text-slate-800">
                    Non-human movement
                  </span>
                </>
              ) : (
                <>
                  <UserX className="w-5 h-5 text-slate-400 shrink-0" />
                  <span id="presence-status-text" className="font-semibold text-sm text-slate-600">
                    No target
                  </span>
                </>
              )}
            </div>

            <span className="text-xs text-slate-600 font-medium mt-1.5">
              {currentRadarState === 'TARGET_CHECKING'
                ? `Reading ${consecutiveReadings} of 3 samples (2–5s window)`
                : currentRadarState === 'HUMAN_LIKELY'
                ? `Active for ${formatDwell(dwellSec)} (${consecutiveReadings}+ verified)`
                : currentRadarState === 'NON_HUMAN_LIKELY'
                ? 'Filtered out of alerts'
                : 'Noise floor normal'}
            </span>
          </div>

          {/* 2. Movement & Signal Stability */}
          <div
            id="bathroom-movement-box"
            className={`p-3.5 rounded-xl border flex flex-col justify-between ${
              currentRadarState === 'HUMAN_LIKELY'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : currentRadarState === 'TARGET_CHECKING'
                ? 'bg-amber-50 border-amber-200 text-amber-950'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-600">Motion &amp; Gate</span>
              {currentRadarState !== 'NO_TARGET' && (
                <span className="text-[10px] font-semibold text-slate-500">
                  Gate {gate}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 mt-2">
              {currentRadarState === 'HUMAN_LIKELY' ? (
                <>
                  <Activity className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span id="movement-status-text" className="font-bold text-base text-emerald-900">
                    {movement}
                  </span>
                </>
              ) : currentRadarState === 'TARGET_CHECKING' ? (
                <>
                  <Activity className="w-5 h-5 text-amber-600 shrink-0 animate-pulse" />
                  <span id="movement-status-text" className="font-bold text-sm text-amber-900">
                    Evaluating Doppler
                  </span>
                </>
              ) : currentRadarState === 'NON_HUMAN_LIKELY' ? (
                <>
                  <Waves className="w-5 h-5 text-slate-500 shrink-0" />
                  <span id="movement-status-text" className="font-semibold text-sm text-slate-700">
                    Unstable / Jitter
                  </span>
                </>
              ) : (
                <>
                  <Activity className="w-5 h-5 text-slate-400 shrink-0" />
                  <span id="movement-status-text" className="font-semibold text-sm text-slate-600">
                    No movement
                  </span>
                </>
              )}
            </div>

            <span className="text-xs text-slate-500 font-medium mt-1.5">
              {currentRadarState !== 'NO_TARGET'
                ? `Stability: ${stabilityPct}% • ~${distance.toFixed(1)}m away`
                : 'No reflection above threshold'}
            </span>
          </div>

          {/* 3. Sensor working */}
          <div
            id="bathroom-sensor-status-box"
            className={`p-3.5 rounded-xl border flex flex-col justify-between ${
              !isDisconnected
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : 'bg-amber-50 border-amber-200 text-amber-950'
            }`}
          >
            <span className="text-xs font-medium text-slate-600">Sensor Status</span>
            <div className="flex items-center gap-2 mt-2">
              {!isDisconnected ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span className="font-bold text-base text-emerald-900">
                    Sensor working
                  </span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                  <span className="font-bold text-base text-amber-900">
                    Needs attention
                  </span>
                </>
              )}
            </div>
            <span className="text-xs text-slate-500 font-medium mt-1.5">
              {!isDisconnected ? 'Radio signal active (24GHz)' : 'Check connection'}
            </span>
          </div>
        </div>

        {/* Clean visual representation: Occupancy & Room Status (No raw video) */}
        <div
          id="bathroom-radar-display"
          className="rounded-xl border border-slate-200 bg-slate-50 p-4 sm:p-5 flex flex-col items-center justify-center text-center min-h-[160px]"
        >
          {isDisconnected ? (
            <div className="space-y-1.5">
              <AlertTriangle className="w-8 h-8 text-amber-600 mx-auto" />
              <p className="font-bold text-slate-800 text-base">Bathroom sensor offline</p>
              <p className="text-xs text-slate-500">Checking wireless connection</p>
            </div>
          ) : currentRadarState === 'TARGET_CHECKING' ? (
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mx-auto shadow-sm animate-pulse">
                <RefreshCw className="w-6 h-6 animate-spin text-amber-700" />
              </div>
              <div>
                <p className="text-base font-bold text-slate-900">
                  Checking movement…
                </p>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  A raw radar trigger was detected. Evaluating presence duration, distance gate, and signal stability across 3 consecutive readings (2–5s) before confirming.
                </p>
              </div>
            </div>
          ) : currentRadarState === 'HUMAN_LIKELY' ? (
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center mx-auto shadow-sm">
                <UserCheck className="w-6 h-6" />
              </div>
              <div>
                <p className="text-base font-bold text-slate-900">
                  Resident is likely in the bathroom
                </p>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  Human-sized presence verified over {consecutiveReadings} consecutive radar samples. Confidence: <strong className="text-slate-800">Human likely</strong> (non-medical observation).
                </p>
              </div>
            </div>
          ) : currentRadarState === 'NON_HUMAN_LIKELY' ? (
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center mx-auto shadow-sm">
                <Waves className="w-6 h-6 text-slate-600" />
              </div>
              <div>
                <p className="text-base font-bold text-slate-900">
                  Non-human movement likely
                </p>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  The echo was brief, unstable, or inconsistent with human presence (e.g. curtain flutter, steam, or small pet). It is safely kept out of the emergency alert system.
                </p>
              </div>
            </div>
          ) : currentRadarState === 'POSSIBLE_FALL' ||
            currentRadarState === 'CHECKING_RESPONSE' ||
            currentRadarState === 'ALERT_SENT' ? (
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto shadow-sm animate-bounce">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <p className="text-base font-bold text-red-900">
                  Possible fall detected in bathroom
                </p>
                <p className="text-xs text-slate-700 max-w-sm mx-auto">
                  Sudden downward transition and sustained low-position echo verified across multiple readings. 20-second caregiver safety workflow active.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-1.5 text-slate-500">
              <Radio className="w-7 h-7 text-slate-400 mx-auto" />
              <p className="font-semibold text-slate-700 text-sm">Bathroom is currently empty</p>
              <p className="text-xs text-slate-400">The radar sensor is scanning quietly (No target)</p>
            </div>
          )}
        </div>

        {/* Collapsible Technical Details Section */}
        <div className="border border-slate-200 rounded-xl bg-slate-50 overflow-hidden">
          <button
            type="button"
            onClick={() => setShowTechnicalDetails(!showTechnicalDetails)}
            className="w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <span>Technical details &amp; Verification State</span>
            {showTechnicalDetails ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>

          {showTechnicalDetails && (
            <div className="px-3.5 pb-3 pt-1 border-t border-slate-200 text-xs text-slate-600 space-y-1.5 font-mono">
              <p>
                <strong>Hardware:</strong> HLK-LD2410C 24GHz FMCW Radar
              </p>
              <p>
                <strong>Verification State:</strong>{' '}
                <span className="font-bold text-slate-900">{currentRadarState}</span>
              </p>
              <p>
                <strong>Confidence Level:</strong>{' '}
                <span className="font-bold text-slate-900">{confidence}</span>{' '}
                <span className="text-slate-400">(Non-medical estimate)</span>
              </p>
              <p>
                <strong>Consecutive Readings:</strong> {consecutiveReadings} / 3 required
              </p>
              <p>
                <strong>Temporal Evaluation Window:</strong> 2–5 seconds
              </p>
              <p>
                <strong>Distance Gate:</strong> Gate {gate} (~{distance.toFixed(2)}m)
              </p>
              <p>
                <strong>Signal Stability:</strong> {stabilityPct}%
              </p>
              {radarState?.lastEvaluationReason && (
                <p className="text-slate-500 font-sans text-[11px] pt-1 border-t border-slate-200">
                  <strong>Engine Reason:</strong> {radarState.lastEvaluationReason}
                </p>
              )}
              <p id="hlk-sensor-status">
                <strong>Sensor Link:</strong> {isDisconnected ? 'Offline' : 'Online (Connected)'}
              </p>
              <p id="bathroom-camera-not-used">
                <strong>Camera:</strong> Not used (100% lens-free)
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Footer: Privacy Notice */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
        <span className="font-semibold text-slate-800">
          Privacy guarantee: 100% lens-free
        </span>
        <span className="text-slate-500">Zero cameras in private zones</span>
      </div>
    </article>
  );
};
export default BathroomCard;
