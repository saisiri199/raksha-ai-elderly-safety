import React, { useState, useEffect } from 'react';
import { Shield, CheckCircle2, AlertTriangle, ArrowLeft, Volume2, VolumeX, Sliders } from 'lucide-react';
import { OnlineStatus, ApiConnectionState } from '../types';

interface TopBarProps {
  systemActive: boolean;
  backendStatus?: OnlineStatus;
  isAnyModuleDisconnected?: boolean;
  onToggleSound?: (enabled: boolean) => void;
  soundEnabled: boolean;
  isDemoMode: boolean;
  onToggleDemoMode: (enabled: boolean) => void;
  apiStatus: ApiConnectionState;
  onOpenApiSettings?: () => void;
  onBackToWelcome?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  systemActive,
  backendStatus = 'Online',
  isAnyModuleDisconnected = false,
  onToggleSound,
  soundEnabled,
  isDemoMode,
  onToggleDemoMode,
  apiStatus,
  onOpenApiSettings,
  onBackToWelcome,
}) => {
  const [lastUpdateTime, setLastUpdateTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setLastUpdateTime(
        now.toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const isSystemWorking = !isAnyModuleDisconnected && backendStatus === 'Online' && systemActive;

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Left: Brand & Subtitle */}
          <div className="flex items-center gap-3">
            {onBackToWelcome && (
              <button
                id="topbar-back-to-welcome-btn"
                onClick={onBackToWelcome}
                title="Return to Welcome Page"
                className="p-2 -ml-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                aria-label="Back to welcome page"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}

            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-sm">
              <Shield className="w-6 h-6" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-slate-900 font-['Plus_Jakarta_Sans']">
                  Raksha
                </span>
                {isDemoMode && (
                  <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                    Demo Mode
                  </span>
                )}
              </div>
              <p className="text-sm font-medium text-slate-600">
                Keeping your loved one safe.
              </p>
            </div>
          </div>

          {/* Right: Connection Indicator & Time */}
          <div className="flex items-center justify-between sm:justify-end gap-4">
            {/* Status indicator: System working or System needs attention */}
            <div
              id="topbar-system-status"
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-semibold ${
                isSystemWorking
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}
            >
              {isSystemWorking ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>System working</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>System needs attention</span>
                </>
              )}
            </div>

            {/* Last update time */}
            <div className="text-right text-xs text-slate-500">
              <span className="block font-medium">Last update</span>
              <span className="font-mono text-slate-700">{lastUpdateTime}</span>
            </div>

            {/* Utility controls: sound & settings */}
            <div className="flex items-center gap-1">
              {onToggleSound && (
                <button
                  id="topbar-sound-toggle-btn"
                  onClick={() => onToggleSound(!soundEnabled)}
                  className={`p-2 rounded-lg text-sm border transition-colors ${
                    soundEnabled
                      ? 'text-slate-700 bg-slate-100 border-slate-200 hover:bg-slate-200'
                      : 'text-slate-400 bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                  title={soundEnabled ? 'Alert sounds enabled' : 'Alert sounds muted'}
                  aria-label={soundEnabled ? 'Mute alert sounds' : 'Enable alert sounds'}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
              )}

              {onOpenApiSettings && (
                <button
                  id="topbar-api-settings-btn"
                  onClick={onOpenApiSettings}
                  className="p-2 rounded-lg text-slate-600 bg-slate-100 border border-slate-200 hover:bg-slate-200 transition-colors"
                  title="Connection Settings"
                  aria-label="Connection Settings"
                >
                  <Sliders className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
export default TopBar;
