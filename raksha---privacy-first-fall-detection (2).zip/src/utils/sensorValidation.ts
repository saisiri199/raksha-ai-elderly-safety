import { TimelineEvent, FallState, AlertSeverity } from '../types';

export interface RawLandmarkPoint {
  x?: unknown;
  y?: unknown;
  z?: unknown;
  visibility?: unknown;
  name?: unknown;
  id?: unknown;
}

export interface SanitizedLandmarkPoint {
  id: number;
  x: number;
  y: number;
  z: number;
  visibility: number;
  name: string;
}

export interface LandmarkValidationResult {
  isValid: boolean;
  isPoseDataUnavailable: boolean;
  userMessage?: string;
  errorReason?: string;
  sanitizedLandmarks: SanitizedLandmarkPoint[];
  pointCount: number;
  validCoordinateCount: number;
  missingVisibilityCount: number;
}

// Fallback 33 standard landmark names
export const DEFAULT_LANDMARK_NAMES: string[] = [
  'Nose',
  'Left Eye Inner',
  'Left Eye',
  'Left Eye Outer',
  'Right Eye Inner',
  'Right Eye',
  'Right Eye Outer',
  'Left Ear',
  'Right Ear',
  'Mouth Left',
  'Mouth Right',
  'Left Shoulder',
  'Right Shoulder',
  'Left Elbow',
  'Right Elbow',
  'Left Wrist',
  'Right Wrist',
  'Left Pinky',
  'Right Pinky',
  'Left Index',
  'Right Index',
  'Left Thumb',
  'Right Thumb',
  'Left Hip',
  'Right Hip',
  'Left Knee',
  'Right Knee',
  'Left Ankle',
  'Right Ankle',
  'Left Heel',
  'Right Heel',
  'Left Foot Index',
  'Right Foot Index',
];

// Reference safe default 3D pose coordinates (standing neutral)
export const SAFE_DEFAULT_COORDINATES: [number, number, number][] = [
  [0.0, 1.74, 0.04],    // 0 Nose
  [-0.03, 1.77, 0.03],  // 1 L Eye In
  [-0.05, 1.77, 0.03],  // 2 L Eye
  [-0.07, 1.77, 0.02],  // 3 L Eye Out
  [0.03, 1.77, 0.03],   // 4 R Eye In
  [0.05, 1.77, 0.03],   // 5 R Eye
  [0.07, 1.77, 0.02],   // 6 R Eye Out
  [-0.10, 1.73, -0.04], // 7 L Ear
  [0.10, 1.73, -0.04],  // 8 R Ear
  [-0.03, 1.68, 0.03],  // 9 Mouth L
  [0.03, 1.68, 0.03],   // 10 Mouth R
  [-0.22, 1.50, 0.0],   // 11 L Shoulder
  [0.22, 1.50, 0.0],    // 12 R Shoulder
  [-0.28, 1.18, 0.03],  // 13 L Elbow
  [0.28, 1.18, 0.03],   // 14 R Elbow
  [-0.30, 0.88, 0.05],  // 15 L Wrist
  [0.30, 0.88, 0.05],   // 16 R Wrist
  [-0.32, 0.80, 0.05],  // 17 L Pinky
  [0.32, 0.80, 0.05],   // 18 R Pinky
  [-0.31, 0.79, 0.05],  // 19 L Index
  [0.31, 0.79, 0.05],   // 20 R Index
  [-0.28, 0.83, 0.05],  // 21 L Thumb
  [0.28, 0.83, 0.05],   // 22 R Thumb
  [-0.14, 0.94, 0.0],   // 23 L Hip
  [0.14, 0.94, 0.0],    // 24 R Hip
  [-0.15, 0.50, 0.02],  // 25 L Knee
  [0.15, 0.50, 0.02],   // 26 R Knee
  [-0.14, 0.10, -0.02], // 27 L Ankle
  [0.14, 0.10, -0.02],  // 28 R Ankle
  [-0.14, 0.04, -0.06], // 29 L Heel
  [0.14, 0.04, -0.06],  // 30 R Heel
  [-0.14, 0.02, 0.08],  // 31 L Foot Index
  [0.14, 0.02, 0.08],   // 32 R Foot Index
];

/**
 * Validates and sanitizes raw pose landmark data according to strict safety rules:
 * 1. Missing landmark data (null, undefined, not an array)
 * 2. Fewer than 33 landmarks
 * 3. Invalid x, y, or z values (NaN, null, undefined, Infinity, non-numeric strings)
 * 4. Missing visibility (defaults safely to 1.0)
 *
 * Guarantees zero runtime crashes.
 */
export function validateAndSanitizeLandmarks(
  rawLandmarks: unknown,
  options?: {
    allowSafeDefaultFallback?: boolean;
  }
): LandmarkValidationResult {
  // Case 1: Missing landmark data
  if (!rawLandmarks || !Array.isArray(rawLandmarks)) {
    return {
      isValid: false,
      isPoseDataUnavailable: true,
      userMessage: 'Pose data unavailable',
      errorReason: 'Missing landmark data (null, undefined, or non-array input)',
      pointCount: 0,
      validCoordinateCount: 0,
      missingVisibilityCount: 0,
      sanitizedLandmarks: options?.allowSafeDefaultFallback ? getSafeDefaultLandmarks() : [],
    };
  }

  const pointCount = rawLandmarks.length;

  // Case 2: Fewer than 33 landmarks
  if (pointCount < 33) {
    return {
      isValid: false,
      isPoseDataUnavailable: true,
      userMessage: 'Pose data unavailable',
      errorReason: `Fewer than 33 landmarks received (${pointCount}/33 detected)`,
      pointCount,
      validCoordinateCount: 0,
      missingVisibilityCount: 0,
      sanitizedLandmarks: options?.allowSafeDefaultFallback ? getSafeDefaultLandmarks() : [],
    };
  }

  let invalidCoordinateCount = 0;
  let missingVisibilityCount = 0;
  const sanitized: SanitizedLandmarkPoint[] = [];

  for (let i = 0; i < 33; i++) {
    const rawPoint = rawLandmarks[i] as RawLandmarkPoint | undefined | null;
    const fallbackCoord = SAFE_DEFAULT_COORDINATES[i] || [0, 0, 0];
    const defaultName = DEFAULT_LANDMARK_NAMES[i] || `Landmark ${i}`;

    if (!rawPoint || typeof rawPoint !== 'object') {
      invalidCoordinateCount++;
      sanitized.push({
        id: i,
        x: fallbackCoord[0],
        y: fallbackCoord[1],
        z: fallbackCoord[2],
        visibility: 0,
        name: defaultName,
      });
      continue;
    }

    // Validate X
    let x = Number(rawPoint.x);
    let xValid = typeof rawPoint.x === 'number' && Number.isFinite(x) && !Number.isNaN(x);
    if (!xValid) {
      invalidCoordinateCount++;
      x = fallbackCoord[0];
    }

    // Validate Y
    let y = Number(rawPoint.y);
    let yValid = typeof rawPoint.y === 'number' && Number.isFinite(y) && !Number.isNaN(y);
    if (!yValid) {
      invalidCoordinateCount++;
      y = fallbackCoord[1];
    }

    // Validate Z
    let z = Number(rawPoint.z);
    let zValid = typeof rawPoint.z === 'number' && Number.isFinite(z) && !Number.isNaN(z);
    if (!zValid) {
      invalidCoordinateCount++;
      z = fallbackCoord[2];
    }

    // Validate Visibility: Missing visibility default to 1.0 (or 0.0 if point was corrupted)
    let vis = 1.0;
    if (rawPoint.visibility === undefined || rawPoint.visibility === null) {
      missingVisibilityCount++;
      vis = 1.0; // Default gracefully
    } else {
      const numVis = Number(rawPoint.visibility);
      if (Number.isFinite(numVis) && !Number.isNaN(numVis)) {
        vis = Math.max(0, Math.min(1, numVis));
      } else {
        missingVisibilityCount++;
        vis = 1.0;
      }
    }

    sanitized.push({
      id: typeof rawPoint.id === 'number' ? rawPoint.id : i,
      x,
      y,
      z,
      visibility: vis,
      name: typeof rawPoint.name === 'string' && rawPoint.name ? rawPoint.name : defaultName,
    });
  }

  // If too many invalid coordinates, mark pose data unavailable
  const hasSevereCoordinateCorruption = invalidCoordinateCount > 8;

  if (hasSevereCoordinateCorruption) {
    return {
      isValid: false,
      isPoseDataUnavailable: true,
      userMessage: 'Pose data unavailable',
      errorReason: `Invalid x, y, or z coordinates detected in ${invalidCoordinateCount} landmarks`,
      pointCount,
      validCoordinateCount: 33 * 3 - invalidCoordinateCount,
      missingVisibilityCount,
      sanitizedLandmarks: options?.allowSafeDefaultFallback ? sanitized : [],
    };
  }

  return {
    isValid: true,
    isPoseDataUnavailable: false,
    sanitizedLandmarks: sanitized,
    pointCount,
    validCoordinateCount: 33 * 3 - invalidCoordinateCount,
    missingVisibilityCount,
  };
}

export function getSafeDefaultLandmarks(): SanitizedLandmarkPoint[] {
  return SAFE_DEFAULT_COORDINATES.map((coord, idx) => ({
    id: idx,
    x: coord[0],
    y: coord[1],
    z: coord[2],
    visibility: 1.0,
    name: DEFAULT_LANDMARK_NAMES[idx] || `Landmark ${idx}`,
  }));
}

/**
 * Valid event statuses for FallState.
 */
const VALID_FALL_STATES: Set<string> = new Set([
  'NORMAL',
  'POSSIBLE_FALL',
  'CHECKING_RESPONSE',
  'ALERT_SENT',
  'RESOLVED',
  'ESCALATED',
]);

const VALID_SEVERITIES: Set<string> = new Set([
  'info',
  'warning',
  'critical',
  'success',
]);

const VALID_EVENT_TYPES: Set<string> = new Set([
  'fall',
  'presence',
  'sensor',
  'system',
  'alert',
  'safe',
]);

/**
 * Sanitizes an event item to guard against invalid event status, missing fields, or corruption.
 */
export function sanitizeTimelineEvent(raw: unknown): TimelineEvent {
  const defaultEvent: TimelineEvent = {
    id: `ev-safe-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString(),
    timeString: 'Just now',
    room: 'System',
    type: 'system',
    severity: 'info',
    title: 'System Event',
    description: 'Telemetry event registered.',
    state: 'NORMAL',
  };

  if (!raw || typeof raw !== 'object') {
    return defaultEvent;
  }

  const ev = raw as Record<string, unknown>;

  // Sanitize ID
  const id = typeof ev.id === 'string' && ev.id ? ev.id : defaultEvent.id;

  // Sanitize timestamp & timeString
  let timestamp = defaultEvent.timestamp;
  if (typeof ev.timestamp === 'string' && ev.timestamp) {
    const parsed = Date.parse(ev.timestamp);
    if (!Number.isNaN(parsed)) {
      timestamp = ev.timestamp;
    }
  }

  const timeString =
    typeof ev.timeString === 'string' && ev.timeString
      ? ev.timeString
      : new Date(timestamp).toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });

  // Sanitize Room
  let room: TimelineEvent['room'] = 'System';
  if (ev.room === 'Living Room' || ev.room === 'Bathroom' || ev.room === 'Resident' || ev.room === 'System') {
    room = ev.room;
  }

  // Sanitize Type
  let type: TimelineEvent['type'] = 'system';
  if (typeof ev.type === 'string' && VALID_EVENT_TYPES.has(ev.type)) {
    type = ev.type as TimelineEvent['type'];
  }

  // Sanitize Severity
  let severity: AlertSeverity = 'info';
  if (typeof ev.severity === 'string' && VALID_SEVERITIES.has(ev.severity)) {
    severity = ev.severity as AlertSeverity;
  }

  // Sanitize Fall State (Handles "Invalid event status")
  let state: FallState | undefined = undefined;
  if (typeof ev.state === 'string') {
    const normalized = ev.state.toUpperCase();
    if (VALID_FALL_STATES.has(normalized)) {
      state = normalized as FallState;
    } else {
      // Fallback for invalid event status
      state = 'NORMAL';
    }
  }

  return {
    id,
    timestamp,
    timeString,
    room,
    type,
    severity,
    title: typeof ev.title === 'string' && ev.title ? ev.title : 'Telemetry update',
    description: typeof ev.description === 'string' && ev.description ? ev.description : 'Sensor event logged.',
    state,
  };
}

/**
 * Deduplicates an event array by ID and semantic signature.
 * Prevents React key duplication errors and clutter.
 */
export function deduplicateEvents(events: unknown[]): TimelineEvent[] {
  if (!Array.isArray(events)) return [];

  const seenIds = new Set<string>();
  const seenSignatures = new Set<string>();
  const result: TimelineEvent[] = [];

  for (const raw of events) {
    const sanitized = sanitizeTimelineEvent(raw);

    // Signature based on timestamp + room + type + title to detect duplicates with different IDs
    const signature = `${sanitized.timestamp}__${sanitized.room}__${sanitized.type}__${sanitized.title}`;

    if (seenIds.has(sanitized.id) || seenSignatures.has(signature)) {
      continue; // Skip duplicate event
    }

    seenIds.add(sanitized.id);
    seenSignatures.add(signature);
    result.push(sanitized);
  }

  return result;
}
