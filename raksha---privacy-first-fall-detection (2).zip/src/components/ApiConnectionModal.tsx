import React, { useState } from 'react';
import { X, Wifi, WifiOff, RefreshCw, AlertTriangle, ShieldCheck, CheckCircle2, Server, Globe } from 'lucide-react';
import { ApiConnectionState } from '../types';
import { api } from '../services/api';

interface ApiConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiStatus: ApiConnectionState;
  onRefresh: () => void;
  isDemoMode: boolean;
  onToggleDemoMode?: (enabled: boolean) => void;
}

export const ApiConnectionModal: React.FC<ApiConnectionModalProps> = ({
  isOpen,
  onClose,
  apiStatus,
  onRefresh,
  isDemoMode,
  onToggleDemoMode,
}) => {
  const [customEndpoint, setCustomEndpoint] = useState(api.getEndpoint());
  const [isSimulatingDown, setIsSimulatingDown] = useState(api.isSimulatingServerDown());
  const [isApplying, setIsApplying] = useState(false);

  if (!isOpen) return null;

  const handleApplyEndpoint = (e: React.FormEvent) => {
    e.preventDefault();
    setIsApplying(true);
    api.setEndpoint(customEndpoint);
    setTimeout(() => {
      onRefresh();
      setIsApplying(false);
    }, 200);
  };

  const handleToggleSimulatedOutage = () => {
    const next = !isSimulatingDown;
    setIsSimulatingDown(next);
    api.setSimulateServerDown(next);
    onRefresh();
  };

  const isConnected = apiStatus.status === 'connected';

  return (
    <div
      id="api-connection-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="api-connection-modal"
        className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-750 p-6 shadow-2xl text-slate-100 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div
              className={`p-2 rounded-xl ${
                isConnected
                  ? 'bg-emerald-950 border border-emerald-700 text-emerald-400'
                  : 'bg-rose-950 border border-rose-700 text-rose-400'
              }`}
            >
              {isConnected ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-white flex items-center gap-2">
                Live Sensor API Connection
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                    isConnected
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                      : 'bg-rose-950 text-rose-300 border-rose-700'
                  }`}
                >
                  {isConnected ? 'ONLINE' : 'DISCONNECTED'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                On-premise Edge TPU &amp; 24GHz FMCW Radar telemetry gateway
              </p>
            </div>
          </div>
          <button
            id="btn-close-api-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Mode Callout */}
        <div
          id="api-modal-mode-banner"
          className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-3 ${
            isDemoMode
              ? 'bg-amber-950/40 border-amber-700/60 text-amber-200'
              : isConnected
              ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
              : 'bg-rose-950/50 border-rose-700/60 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 shrink-0" />
            <div>
              <span className="font-bold block">
                {isDemoMode
                  ? 'Current Mode: DEMO (Local Simulation)'
                  : isConnected
                  ? 'Current Mode: LIVE API (Real Sensor Data Active)'
                  : 'Current Mode: LIVE API (Offline / Stream Lost)'}
              </span>
              <span className="text-[11px] opacity-80">
                {isDemoMode
                  ? 'Dashboard is using local synthetic events & landmark keyframes.'
                  : isConnected
                  ? 'Real edge events and live 33-point coordinates streamed from API.'
                  : 'STRICT POLICY: Zero synthetic fallback data is injected when API is offline.'}
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono uppercase px-2 py-1 rounded bg-slate-900 border border-slate-750 shrink-0">
            {isDemoMode ? 'Simulated' : 'Real Telemetry'}
          </span>
        </div>

        {/* Diagnostic Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-mono">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-0.5">HTTP Status</span>
            <span
              className={`font-bold ${
                isConnected ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {apiStatus.httpStatus ? `${apiStatus.httpStatus} ${isConnected ? 'OK' : 'Error'}` : '0 Network Error'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-0.5">Gateway Latency</span>
            <span className="font-bold text-slate-200">
              {apiStatus.latencyMs} ms
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 col-span-2 sm:col-span-1">
            <span className="text-[10px] text-slate-400 block mb-0.5">Last Checked</span>
            <span className="font-bold text-slate-200">{apiStatus.lastChecked || 'Just now'}</span>
          </div>
        </div>

        {/* Error message if disconnected */}
        {!isConnected && (
          <div
            id="api-connection-error-box"
            className="p-3 rounded-xl bg-rose-950/70 border border-rose-700/80 text-rose-200 text-xs flex items-start gap-2.5"
          >
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">Live API Disconnected</span>
              <p className="text-[11px] text-rose-300/90 mt-0.5 font-mono">
                {apiStatus.errorMessage || 'Unable to communicate with edge sensor API gateway.'}
              </p>
              <p className="text-[11px] text-rose-300 mt-1 font-sans">
                In Live API Mode, the application adheres strictly to verifiable telemetry. It will not silently invent fake events or poses.
              </p>
            </div>
          </div>
        )}

        {/* API Endpoint Configuration Form */}
        <form onSubmit={handleApplyEndpoint} className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-teal-400" />
              API Gateway Base URL
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Default: /api</span>
          </label>
          <div className="flex gap-2">
            <input
              id="input-api-endpoint"
              type="text"
              value={customEndpoint}
              onChange={(e) => setCustomEndpoint(e.target.value)}
              placeholder="/api or http://192.168.1.120:8000/api"
              className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-750 text-xs font-mono text-slate-200 focus:outline-none focus:border-teal-500"
            />
            <button
              type="submit"
              disabled={isApplying}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-semibold text-white transition-colors"
            >
              {isApplying ? 'Applying...' : 'Set URL'}
            </button>
          </div>
        </form>

        {/* Failure Testing Suite: Simulate Outage */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold text-slate-200 block">Simulate API Outage (Test Fallback Rule)</span>
            <span className="text-[11px] text-slate-400 block">
              Forces HTTP 503 to verify that zero fake data is silently generated.
            </span>
          </div>
          <button
            id="btn-simulate-api-outage"
            onClick={handleToggleSimulatedOutage}
            className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors shrink-0 ${
              isSimulatingDown
                ? 'bg-rose-950 border-rose-600 text-rose-200'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
            }`}
          >
            {isSimulatingDown ? 'Restore API Server' : 'Simulate API Down'}
          </button>
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <button
            id="btn-refresh-api-connection"
            onClick={onRefresh}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-teal-400" />
            Ping &amp; Refresh Connection
          </button>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
