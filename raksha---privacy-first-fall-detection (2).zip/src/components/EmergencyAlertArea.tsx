import React from 'react';
import {
  AlertTriangle,
  PhoneCall,
  CheckCircle2,
  ShieldCheck,
  Timer,
  Clock,
  MapPin,
  RotateCcw,
  UserCheck,
} from 'lucide-react';
import { EmergencyAlert, FallState } from '../types';

interface EmergencyAlertAreaProps {
  alert: EmergencyAlert;
  onImOkay: () => void;
  onAcknowledge?: () => void;
  onEscalate: () => void;
  onReset: () => void;
}

export const EmergencyAlertArea: React.FC<EmergencyAlertAreaProps> = ({
  alert,
  onImOkay,
  onAcknowledge,
  onEscalate,
  onReset,
}) => {
  const currentState: FallState = alert.state || 'NORMAL';
  const isNormal = currentState === 'NORMAL';
  const isResolved = currentState === 'RESOLVED';
  const hasPossibleFall = !isNormal && !isResolved;

  // If there is no active emergency, show a small calm panel
  if (!hasPossibleFall) {
    return (
      <section
        id="emergency-alert-section"
        aria-label="Safety status"
        className="w-full"
      >
        <div
          id="standby-emergency-card"
          className="bg-white border border-emerald-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
                {isResolved ? 'Resident confirmed safe' : 'No emergency right now.'}
              </h2>
              <p className="text-sm text-slate-600">
                {isResolved
                  ? 'The alert has been resolved. Both rooms are monitoring normally.'
                  : 'Sensors in the living room and bathroom are monitoring quietly.'}
              </p>
            </div>
          </div>

          {isResolved && (
            <button
              onClick={onReset}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-lg border border-slate-300 transition-colors"
              title="Return to standard monitoring"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to normal</span>
            </button>
          )}
        </div>
      </section>
    );
  }

  // Active Possible Fall Alert Panel
  const isCheckingResponse = currentState === 'CHECKING_RESPONSE';
  const isAlertSent = currentState === 'ALERT_SENT';
  const isEscalated = currentState === 'ESCALATED';

  return (
    <section
      id="emergency-alert-section"
      aria-label="Emergency Fall Alert"
      className="w-full animate-fadeIn"
    >
      <div
        id="active-emergency-card"
        className="bg-red-50 border-2 border-red-500 rounded-2xl p-5 sm:p-6 shadow-md"
      >
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          {/* Left: Icon and Primary Alert Message */}
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm animate-pulse">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider text-red-700 bg-red-100 border border-red-300 px-2.5 py-0.5 rounded-full">
                  Urgent Attention
                </span>
                {alert.acknowledged && (
                  <span className="text-xs font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded-full">
                    Caregiver Responding
                  </span>
                )}
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Plus_Jakarta_Sans']">
                Possible fall detected
              </h2>
              <p className="text-base sm:text-lg font-semibold text-red-800">
                Please check the resident.
              </p>

              {/* Room name & time information */}
              <div className="flex flex-wrap items-center gap-4 text-sm text-slate-700 pt-1">
                <div className="flex items-center gap-1.5 font-medium">
                  <MapPin className="w-4 h-4 text-slate-600" />
                  <span>Room:</span>
                  <strong className="text-slate-900">{alert.room || 'Living Room'}</strong>
                </div>

                <div className="flex items-center gap-1.5 font-medium">
                  <Clock className="w-4 h-4 text-slate-600" />
                  <span>Time:</span>
                  <strong className="text-slate-900">{alert.timestamp || 'Just now'}</strong>
                </div>

                {/* Response Countdown */}
                <div className="flex items-center gap-1.5 font-medium">
                  <Timer className="w-4 h-4 text-red-600" />
                  <span>Status:</span>
                  {isCheckingResponse ? (
                    <strong className="text-red-700 font-mono">
                      Checking response: {alert.countdownSeconds}s remaining
                    </strong>
                  ) : isAlertSent ? (
                    <strong className="text-red-800">
                      No response from resident — Caregiver notified
                    </strong>
                  ) : isEscalated ? (
                    <strong className="text-red-900">
                      Help called — Emergency team notified
                    </strong>
                  ) : (
                    <strong className="text-red-800">Verifying movement</strong>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Three Large Buttons (min 48px high) */}
          <div className="flex flex-col sm:flex-row lg:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
            {/* Button 1: Resident is okay */}
            <button
              id="btn-im-okay"
              onClick={onImOkay}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-base flex items-center justify-center gap-2.5 shadow-sm transition-all cursor-pointer"
              title="Confirm the resident is okay (clears alert)"
            >
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>Resident is okay</span>
            </button>

            {/* Button 2: I am checking */}
            <button
              id="btn-i-am-checking"
              onClick={() => {
                if (onAcknowledge) onAcknowledge();
              }}
              className={`min-h-[48px] px-6 py-3 rounded-xl font-bold text-base flex items-center justify-center gap-2.5 border shadow-sm transition-all cursor-pointer ${
                alert.acknowledged
                  ? 'bg-amber-100 text-amber-900 border-amber-400'
                  : 'bg-white hover:bg-amber-50 active:bg-amber-100 text-amber-900 border-amber-300'
              }`}
              title="Let others know you are checking on the resident"
            >
              <UserCheck className="w-5 h-5 text-amber-700 shrink-0" />
              <span>{alert.acknowledged ? 'I am checking' : 'I am checking'}</span>
            </button>

            {/* Button 3: Call for help */}
            <button
              id="btn-escalate"
              onClick={onEscalate}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-base flex items-center justify-center gap-2.5 shadow-sm transition-all cursor-pointer"
              title="Escalate and contact emergency help"
            >
              <PhoneCall className="w-5 h-5 shrink-0" />
              <span>Call for help</span>
            </button>

            {/* Small quiet reset button for demo/testing */}
            <button
              id="btn-reset-normal"
              onClick={onReset}
              className="min-h-[48px] px-3 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1 border border-slate-300 transition-colors"
              title="Reset alert state for testing"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
export default EmergencyAlertArea;
