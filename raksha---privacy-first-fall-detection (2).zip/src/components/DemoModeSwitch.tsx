import React from 'react';
import { Sparkles, Radio, Activity, AlertCircle, Settings2, Wifi, WifiOff } from 'lucide-react';
import { ApiConnectionState } from '../types';

interface DemoModeSwitchProps {
  isDemoMode: boolean;
  onToggle: (enabled: boolean) => void;
  apiStatus?: ApiConnectionState;
  onOpenApiSettings?: () => void;
  className?: string;
}

export const DemoModeSwitch: React.FC<DemoModeSwitchProps> = ({
  isDemoMode,
  onToggle,
  apiStatus,
  onOpenApiSettings,
  className = '',
}) => {
  const isApiConnected = apiStatus?.status === 'connected';

  return (
    <div
      id="demo-mode-switch-container"
      className={`flex items-center gap-2.5 p-1.5 rounded-xl border transition-all ${
        isDemoMode
          ? 'bg-amber-950/60 border-amber-600/80 shadow-inner'
          : isApiConnected
          ? 'bg-slate-900 border-emerald-600/80 shadow-inner'
          : 'bg-rose-950/60 border-rose-600/80 shadow-inner'
      } ${className}`}
    >
      {/* Toggle Button */}
      <button
        id="toggle-demo-mode"
        type="button"
        role="switch"
        aria-checked={isDemoMode}
        onClick={() => onToggle(!isDemoMode)}
        className="relative inline-flex h-7 w-14 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2 focus:ring-offset-slate-900 bg-slate-800"
        title={isDemoMode ? 'Switch to Live API Mode' : 'Switch to Demo Mode'}
      >
        <span className="sr-only">Toggle Demo Mode</span>
        <span
          aria-hidden="true"
          className={`pointer-events-none inline-block h-6 w-6 transform rounded-full shadow-lg ring-0 transition duration-200 ease-in-out flex items-center justify-center ${
            isDemoMode
              ? 'translate-x-7 bg-amber-400 text-amber-950'
              : 'translate-x-0 bg-emerald-500 text-slate-950'
          }`}
        >
          {isDemoMode ? (
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          ) : (
            <Radio className="w-3.5 h-3.5 animate-pulse" />
          )}
        </span>
      </button>

      {/* Label and Status */}
      <div className="flex items-center gap-2 pr-1 select-none">
        {isDemoMode ? (
          <div className="flex items-center gap-2">
            <span
              id="label-demo-mode"
              className="font-bold text-xs tracking-wider uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              DEMO MODE
            </span>
            <span className="text-[11px] font-mono text-amber-200/80 hidden sm:inline">
              Simulated Data
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <span
              id="label-live-api-mode"
              className={`font-bold text-xs tracking-wider uppercase px-2 py-0.5 rounded border flex items-center gap-1.5 ${
                isApiConnected
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  : 'bg-rose-950 text-rose-300 border-rose-700'
              }`}
            >
              {isApiConnected ? (
                <Wifi className="w-3 h-3 text-emerald-400" />
              ) : (
                <WifiOff className="w-3 h-3 text-rose-400" />
              )}
              LIVE API MODE
            </span>

            <span className="text-[11px] font-mono flex items-center gap-1 hidden sm:inline">
              {isApiConnected ? (
                <span className="text-emerald-400 font-semibold">Real Sensor Data ({apiStatus?.latencyMs}ms)</span>
              ) : (
                <span className="text-rose-400 font-semibold">API Disconnected • Zero Fake Fallback</span>
              )}
            </span>
          </div>
        )}

        {/* Diagnostic / Endpoint Button */}
        {onOpenApiSettings && (
          <button
            id="btn-open-api-settings"
            onClick={onOpenApiSettings}
            className="p-1 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="Configure API Connection & Diagnostics"
          >
            <Settings2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
