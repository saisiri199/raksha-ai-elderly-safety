import React, { useState, useEffect, useRef } from 'react';
import { TopBar } from './TopBar';
import { EmergencyAlertArea } from './EmergencyAlertArea';
import { LivingRoomCard } from './LivingRoomCard';
import { BathroomCard } from './BathroomCard';
import { RecentEventsTimeline } from './RecentEventsTimeline';
import { SystemHealthSection } from './SystemHealthSection';
import { PrivacySection } from './PrivacySection';
import { DemoControlsBar } from './DemoControlsBar';
import { HelpActionSection } from './HelpActionSection';
import { AlertTriangle, ArrowLeft } from 'lucide-react';
import {
  LivingRoomStatus,
  PresenceStatus,
  MovementStatus,
  EmergencyAlert,
  TimelineEvent,
  FallState,
  ConnectionStatus,
  ReadyStatus,
  OnlineStatus,
  ApiConnectionState,
  RadarTargetState,
  RadarSample,
  RadarVerificationState,
} from '../types';
import {
  INITIAL_RADAR_STATE,
  evaluateRadarSamples,
} from '../utils/radarVerification';
import { sounds } from '../utils/sound';
import { ForcedLandmarkError } from './Skeleton3DViewer';
import { api } from '../services/api';
import { ApiConnectionModal } from './ApiConnectionModal';

export interface CaregiverDashboardProps {
  onBackToWelcome?: () => void;
}

export function CaregiverDashboard({ onBackToWelcome }: CaregiverDashboardProps) {
  // Demo Mode Switch (Demo Mode = local simulated data; Disabled = live API data)
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [apiStatus, setApiStatus] = useState<ApiConnectionState>(() => api.getConnectionState());
  const [isApiModalOpen, setIsApiModalOpen] = useState<boolean>(false);
  const [realApiEvents, setRealApiEvents] = useState<TimelineEvent[]>([]);

  // Explicit Fall Detection Workflow States:
  // NORMAL, POSSIBLE_FALL, CHECKING_RESPONSE, ALERT_SENT, RESOLVED, ESCALATED
  const [fallState, setFallState] = useState<FallState>('NORMAL');
  const [livingRoomStatus, setLivingRoomStatus] = useState<LivingRoomStatus>('NORMAL');
  const [cameraConnected, setCameraConnected] = useState<boolean>(true);

  // System Health Subsystems State
  const [cameraModule, setCameraModule] = useState<ConnectionStatus>('Connected');
  const [mediaPipe, setMediaPipe] = useState<ReadyStatus>('Ready');
  const [bathroomRadar, setBathroomRadar] = useState<ConnectionStatus>('Connected');
  const [backendStatus, setBackendStatus] = useState<OnlineStatus>('Online');

  // Landmark error injection state for testing "Pose data unavailable"
  const [forcedLandmarkError, setForcedLandmarkError] = useState<ForcedLandmarkError>(null);

  // Timestamps for System Health
  const [lastCameraEvent, setLastCameraEvent] = useState<string>(() => {
    const t = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    return `${t} • 33-point pose tracked (Normal posture)`;
  });
  const [lastRadarEvent, setLastRadarEvent] = useState<string>(() => {
    const t = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    return `${t} • HLK-LD2410C micro-motion scan active`;
  });
  const [lastDashboardUpdate, setLastDashboardUpdate] = useState<string>(() => {
    const t = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    return `${t} • Live (1s telemetry heartbeat)`;
  });

  // Bathroom State & Human-Presence Radar Verification State Machine
  // States: NO_TARGET -> TARGET_CHECKING -> HUMAN_LIKELY | NON_HUMAN_LIKELY -> POSSIBLE_FALL -> CHECKING_RESPONSE -> ALERT_SENT
  const [radarState, setRadarState] = useState<RadarVerificationState>(INITIAL_RADAR_STATE);
  const [radarSamples, setRadarSamples] = useState<RadarSample[]>([]);
  const radarTimeoutsRef = useRef<NodeJS.Timeout[]>([]);

  const [bathroomPresence, setBathroomPresence] = useState<PresenceStatus>('Not detected');
  const [bathroomMovement, setBathroomMovement] = useState<MovementStatus>('No movement');
  const [bathroomDwell, setBathroomDwell] = useState<number>(0);

  // Sound and simulation meta
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [activeScenario, setActiveScenario] = useState<string | null>(null);

  // Emergency Alert State (reflecting active FallState)
  const [emergencyAlert, setEmergencyAlert] = useState<EmergencyAlert>({
    isActive: false,
    type: null,
    state: 'NORMAL',
    room: 'Living Room',
    location: 'Living Room — Zone 01',
    timestamp: '',
    confidence: 0,
    countdownSeconds: 20,
    maxCountdown: 20,
    status: 'safe',
    acknowledged: false,
    residentResponded: false,
    details: '',
  });

  // Recent Events Timeline Initial Seed
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([
    {
      id: 'ev-init-1',
      timestamp: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
      timeString: '18 min ago',
      room: 'Living Room',
      type: 'presence',
      severity: 'info',
      title: 'State: NORMAL',
      description: 'System in NORMAL monitoring state. Upright 33-point skeleton tracked walking towards kitchen.',
      state: 'NORMAL',
    },
    {
      id: 'ev-init-2',
      timestamp: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
      timeString: '35 min ago',
      room: 'Bathroom',
      type: 'sensor',
      severity: 'info',
      title: 'HLK-LD2410C Heartbeat Nominal',
      description: '24GHz radar gate calibration verified. Zero optical cameras in hygiene space.',
    },
    {
      id: 'ev-init-3',
      timestamp: new Date(Date.now() - 1000 * 60 * 70).toISOString(),
      timeString: '1 hr ago',
      room: 'System',
      type: 'system',
      severity: 'success',
      title: 'Local Privacy Firewall Verified',
      description: 'Zero outbound video packets. On-device TPU inference nominal.',
    },
  ]);

  // Requirement 8: Add every state change to the event timeline
  const addEvent = (
    title: string,
    description: string,
    room: TimelineEvent['room'],
    type: TimelineEvent['type'],
    severity: TimelineEvent['severity'],
    state?: FallState
  ) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    const newEv: TimelineEvent = {
      id: `ev-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: now.toISOString(),
      timeString: timeStr,
      room,
      type,
      severity,
      title,
      description,
      state,
      dataSource: isDemoMode ? 'simulated' : 'real',
    };

    if (isDemoMode) {
      setTimelineEvents((prev) => [newEv, ...prev]);
    } else {
      // In Live API mode, dispatch to API
      api.postEvent(newEv).then((res) => {
        if (res.success && res.data) {
          setRealApiEvents((prev) => [res.data!, ...prev]);
        }
      }).catch(() => {
        // Safe catch: never crash on network failure
      });
    }
  };

  // API Connection Checker and Data Fetcher
  const checkApiConnection = async () => {
    try {
      const conn = await api.checkConnection();
      setApiStatus(conn);
      if (!isDemoMode && conn.status === 'connected') {
        const res = await api.getEvents();
        if (res.success && res.data) {
          setRealApiEvents(res.data);
        }
      }
    } catch {
      setApiStatus({
        status: 'disconnected',
        endpoint: api.getConnectionState().endpoint,
        latencyMs: 0,
        lastChecked: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        errorMessage: 'Backend unavailable (Network error)',
        isRealData: true,
        httpStatus: 0,
      });
    }

  };

  // Poll connection and real events
  useEffect(() => {
    checkApiConnection();
    const interval = setInterval(() => {
      checkApiConnection();
    }, 4000);
    return () => clearInterval(interval);
  }, [isDemoMode]);

  // Demo Mode Switch Handler
  const handleToggleDemoMode = (enabled: boolean) => {
    setIsDemoMode(enabled);
    if (!enabled) {
      // Switched to Live API: fetch real data immediately
      checkApiConnection();
    }
  };

  const stepTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Centralized State Transition Engine
  const transitionToState = (
    nextState: FallState,
    context?: {
      room?: string;
      timestamp?: string;
      details?: string;
    }
  ) => {
    if (stepTimerRef.current) {
      clearTimeout(stepTimerRef.current);
      stepTimerRef.current = null;
    }

    const room = context?.room || emergencyAlert.room || 'Living Room';
    const timestamp =
      context?.timestamp ||
      emergencyAlert.timestamp ||
      new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });

    setFallState(nextState);
    setLivingRoomStatus(nextState);

    // Update alert structure
    setEmergencyAlert((prev) => {
      switch (nextState) {
        case 'NORMAL':
          return {
            ...prev,
            isActive: false,
            state: 'NORMAL',
            room: 'Living Room',
            location: 'Living Room — Zone 01',
            timestamp: '',
            countdownSeconds: 20,
            maxCountdown: 20,
            status: 'safe',
            acknowledged: false,
            residentResponded: false,
            details: '',
          };
        case 'POSSIBLE_FALL':
          return {
            ...prev,
            isActive: true,
            type: 'living_room_fall',
            state: 'POSSIBLE_FALL',
            room,
            location: `${room} — Zone 01`,
            timestamp,
            confidence: 94,
            countdownSeconds: 20,
            maxCountdown: 20,
            status: 'pending',
            acknowledged: false,
            residentResponded: false,
            details:
              context?.details ||
              'Sudden vertical centroid drop detected by 33-point pose model. Possible fall.',
          };
        case 'CHECKING_RESPONSE':
          return {
            ...prev,
            isActive: true,
            type: 'living_room_fall',
            state: 'CHECKING_RESPONSE',
            room,
            location: `${room} — Zone 01`,
            timestamp,
            confidence: 94,
            countdownSeconds: 20,
            maxCountdown: 20,
            status: 'checking',
            acknowledged: false,
            residentResponded: false,
            details:
              context?.details ||
              'Checking response: Initiated 20-second resident check-in audio prompt and wearable check.',
          };
        case 'ALERT_SENT':
          return {
            ...prev,
            isActive: true,
            state: 'ALERT_SENT',
            room,
            location: `${room} — Zone 01`,
            timestamp,
            countdownSeconds: 0,
            maxCountdown: 20,
            status: 'pending',
            details:
              '20-second countdown finished without confirmation. Possible fall alert sent to designated contacts.',
          };
        case 'RESOLVED':
          return {
            ...prev,
            isActive: true,
            state: 'RESOLVED',
            room,
            location: `${room} — Zone 01`,
            timestamp,
            countdownSeconds: 0,
            maxCountdown: 20,
            status: 'resolved',
            residentResponded: true,
            details: 'Resident clicked "I’m Okay". Possible fall marked resolved.',
          };
        case 'ESCALATED':
          return {
            ...prev,
            isActive: true,
            state: 'ESCALATED',
            room,
            location: `${room} — Zone 01`,
            timestamp,
            countdownSeconds: 0,
            maxCountdown: 20,
            status: 'escalated',
            details: 'Caregiver clicked Escalate for possible fall. Priority escalation dispatched.',
          };
      }
    });

    // Requirement 8: Add every state change to the event timeline!
    switch (nextState) {
      case 'NORMAL':
        addEvent(
          'State: NORMAL',
          'System returned to NORMAL monitoring state. Ambient sensors scanning for possible falls.',
          'System',
          'system',
          'info',
          'NORMAL'
        );
        break;
      case 'POSSIBLE_FALL':
        addEvent(
          'State: POSSIBLE_FALL',
          `Possible fall detected in ${room} at ${timestamp}. Unconfirmed event. Initializing resident response check.`,
          room === 'Bathroom' ? 'Bathroom' : 'Living Room',
          'fall',
          'warning',
          'POSSIBLE_FALL'
        );
        break;
      case 'CHECKING_RESPONSE':
        addEvent(
          'State: CHECKING_RESPONSE',
          `Checking response for possible fall in ${room}. 20-second resident response countdown started.`,
          room === 'Bathroom' ? 'Bathroom' : 'Living Room',
          'alert',
          'warning',
          'CHECKING_RESPONSE'
        );
        break;
      case 'ALERT_SENT':
        addEvent(
          'State: ALERT_SENT',
          `20-second countdown finished without confirmation in ${room}. Possible fall alert sent to designated caregivers.`,
          room === 'Bathroom' ? 'Bathroom' : 'Living Room',
          'alert',
          'critical',
          'ALERT_SENT'
        );
        break;
      case 'RESOLVED':
        addEvent(
          'State: RESOLVED',
          `Resident clicked "I’m Okay" for ${room}. Possible fall event resolved without medical escalation.`,
          'Resident',
          'safe',
          'success',
          'RESOLVED'
        );
        break;
      case 'ESCALATED':
        addEvent(
          'State: ESCALATED',
          `Escalate clicked for possible fall in ${room}. Priority notification sent to designated contacts.`,
          room === 'Bathroom' ? 'Bathroom' : 'Living Room',
          'fall',
          'critical',
          'ESCALATED'
        );
        break;
    }
  };

  // Radar timeout cleanup on unmount
  useEffect(() => {
    return () => {
      radarTimeoutsRef.current.forEach(clearTimeout);
      radarTimeoutsRef.current = [];
    };
  }, []);

  // Ingest radar sample and evaluate through 7-state human-presence verification machine
  const ingestRadarSample = (sample: RadarSample) => {
    const now = sample.timestamp || Date.now();
    setRadarSamples((prev) => {
      const updatedSamples = [...prev, sample];
      const evaluated = evaluateRadarSamples(updatedSamples, radarState, now);
      setRadarState(evaluated);

      // Keep legacy presence and movement state synchronized for components relying on them
      if (evaluated.state === 'HUMAN_LIKELY') {
        setBathroomPresence('Presence detected');
        setBathroomMovement(sample.movement ? 'Movement detected' : 'Static breathing');
      } else if (evaluated.state === 'NO_TARGET') {
        setBathroomPresence('Not detected');
        setBathroomMovement('No movement');
        setBathroomDwell(0);
      } else if (evaluated.state === 'TARGET_CHECKING') {
        // Critical requirement: Never immediately display "Human detected"
        setBathroomPresence('Not detected');
        setBathroomMovement('Movement detected');
      } else if (evaluated.state === 'NON_HUMAN_LIKELY') {
        // Filtered out of emergency alerts
        setBathroomPresence('Not detected');
        setBathroomMovement('Low movement');
      }

      return evaluated.rawSamples;
    });
  };

  // Requirement 4 & 6: 20-Second Countdown Execution in CHECKING_RESPONSE
  useEffect(() => {
    if (fallState !== 'CHECKING_RESPONSE') return;

    const timer = setInterval(() => {
      setEmergencyAlert((prev) => {
        if (prev.countdownSeconds <= 1) {
          clearInterval(timer);
          // Step 6: If the countdown finishes without confirmation, change to Alert Sent.
          sounds.playAlert();
          setTimeout(() => {
            transitionToState('ALERT_SENT', {
              room: prev.room,
              timestamp: prev.timestamp,
            });
          }, 0);
          return {
            ...prev,
            countdownSeconds: 0,
          };
        }
        return {
          ...prev,
          countdownSeconds: prev.countdownSeconds - 1,
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [fallState]);

  // Bathroom dwell counter
  useEffect(() => {
    let dwellInterval: NodeJS.Timeout | null = null;
    if (bathroomPresence === 'Presence detected') {
      dwellInterval = setInterval(() => {
        setBathroomDwell((prev) => prev + 1);
      }, 1000);
    } else {
      setBathroomDwell(0);
    }
    return () => {
      if (dwellInterval) clearInterval(dwellInterval);
    };
  }, [bathroomPresence]);

  // Heartbeat interval for Last Dashboard Update
  useEffect(() => {
    const updateDashboardHeartbeat = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setLastDashboardUpdate(`${timeStr} • Live (1s telemetry heartbeat)`);
    };

    updateDashboardHeartbeat();
    const interval = setInterval(updateDashboardHeartbeat, 3000);
    return () => clearInterval(interval);
  }, []);

  // Check if any required module is disconnected
  const isAnyModuleDisconnected =
    cameraModule === 'Disconnected' ||
    mediaPipe === 'Unavailable' ||
    bathroomRadar === 'Disconnected' ||
    backendStatus === 'Offline';

  // Subsystem Toggles for Testing & Verification
  const handleToggleCamera = () => {
    const next: ConnectionStatus = cameraModule === 'Connected' ? 'Disconnected' : 'Connected';
    setCameraModule(next);
    setCameraConnected(next === 'Connected');
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (next === 'Disconnected') {
      sounds.playAlert();
      setLastCameraEvent(`${timeStr} • Camera module disconnected (Loss of signal)`);
      addEvent(
        'Camera Module Disconnected',
        'Optical video ingest halted. 33-point pose estimation disabled.',
        'System',
        'system',
        'critical'
      );
    } else {
      sounds.playSuccess();
      setLastCameraEvent(`${timeStr} • Camera reconnected (30 FPS pose stream active)`);
      addEvent(
        'Camera Module Reconnected',
        'Optical sensor re-synchronized with Edge TPU BlazePose pipeline.',
        'System',
        'system',
        'success'
      );
    }
  };

  const handleToggleMediaPipe = () => {
    const next: ReadyStatus = mediaPipe === 'Ready' ? 'Unavailable' : 'Ready';
    setMediaPipe(next);
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (next === 'Unavailable') {
      sounds.playAlert();
      setLastCameraEvent(`${timeStr} • MediaPipe runtime unavailable (Inference halted)`);
      addEvent(
        'MediaPipe Runtime Unavailable',
        '33-landmark pose estimation engine failed to initialize GPU/TPU context.',
        'System',
        'system',
        'warning'
      );
    } else {
      sounds.playSuccess();
      setLastCameraEvent(`${timeStr} • MediaPipe ready (33-landmark model initialized)`);
      addEvent(
        'MediaPipe Runtime Ready',
        'Wasm/GPU pose estimation context loaded and verified nominal.',
        'System',
        'system',
        'success'
      );
    }
  };

  const handleToggleRadar = () => {
    const next: ConnectionStatus = bathroomRadar === 'Connected' ? 'Disconnected' : 'Connected';
    setBathroomRadar(next);
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (next === 'Disconnected') {
      sounds.playAlert();
      setLastRadarEvent(`${timeStr} • HLK-LD2410C radar disconnected (UART baud drop)`);
      addEvent(
        'Bathroom Radar Disconnected',
        'UART communication with 24GHz FMCW sensor lost. Bathroom zone unmonitored.',
        'Bathroom',
        'sensor',
        'critical'
      );
    } else {
      sounds.playSuccess();
      setLastRadarEvent(`${timeStr} • HLK-LD2410C radar re-synced (Gates 0-8 active)`);
      addEvent(
        'Bathroom Radar Reconnected',
        'HLK-LD2410C UART 256kbps bus restored. Micro-motion detection active.',
        'Bathroom',
        'sensor',
        'success'
      );
    }
  };

  const handleToggleBackend = () => {
    const next: OnlineStatus = backendStatus === 'Online' ? 'Offline' : 'Online';
    setBackendStatus(next);
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    if (next === 'Offline') {
      sounds.playAlert();
      addEvent(
        'Backend Offline',
        'Edge orchestrator and caregiver notification relay unreachable. System in degraded fallback.',
        'System',
        'system',
        'critical'
      );
    } else {
      sounds.playSuccess();
      addEvent(
        'Backend Restored Online',
        'Edge orchestrator socket reconnected. Real-time alert dispatch re-enabled.',
        'System',
        'system',
        'success'
      );
    }
  };

  const handleRestoreAllHealth = () => {
    sounds.playSuccess();
    setCameraModule('Connected');
    setCameraConnected(true);
    setMediaPipe('Ready');
    setBathroomRadar('Connected');
    setBackendStatus('Online');
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setLastCameraEvent(`${timeStr} • All vision modules verified (30 FPS)`);
    setLastRadarEvent(`${timeStr} • Radar gates calibrated (Nominal)`);
    setLastDashboardUpdate(`${timeStr} • All subsystems synchronized`);
    addEvent(
      'All Subsystems Restored',
      'Camera, MediaPipe, Radar, and Backend verified and marked 100% operational.',
      'System',
      'system',
      'success'
    );
  };

  // -------------------------------------------------------------
  // Workflow Steps:
  // 1. Possible fall is detected.
  // 2. Show the room and timestamp.
  // 3. Change the state to Checking Response.
  // 4. Display a 20-second countdown.
  // -------------------------------------------------------------
  const handleSimulateLivingRoomFall = () => {
    sounds.playAlert();
    const room = 'Living Room';
    const timestamp = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    setLastCameraEvent(`${timestamp} • Sudden vertical centroid drop (94% conf)`);
    setActiveScenario('Possible Fall Workflow');

    // Step 1: Possible fall is detected.
    // Step 2: Show the room and timestamp.
    transitionToState('POSSIBLE_FALL', { room, timestamp });

    // Step 3: Change the state to Checking Response.
    // Step 4: Display a 20-second countdown.
    stepTimerRef.current = setTimeout(() => {
      transitionToState('CHECKING_RESPONSE', { room, timestamp });
    }, 1200);
  };

  // Step 5: If the user clicks I’m Okay, change to Resolved.
  const handleImOkay = () => {
    sounds.playSuccess();
    setActiveScenario(null);
    if (emergencyAlert.room === 'Bathroom') {
      setRadarState((prev) => ({
        ...prev,
        state: 'HUMAN_LIKELY',
        confidence: 'Human likely',
        lastEvaluationReason: 'Resident confirmed safe. Human presence monitoring active.',
      }));
    }
    transitionToState('RESOLVED');
  };

  // User clicks "I am checking": marks alert as Caregiver responding
  const handleAcknowledgeAlert = () => {
    sounds.playSuccess();
    setEmergencyAlert((prev) => ({
      ...prev,
      acknowledged: true,
      status: 'checking',
    }));
    const timeStr = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    setTimelineEvents((prev) => [
      {
        id: `ack-${Date.now()}`,
        timestamp: timeStr,
        timeString: timeStr,
        room: (emergencyAlert.room as any) || 'Living Room',
        type: 'alert',
        severity: 'info',
        title: 'Alert was acknowledged',
        description: 'Caregiver confirmed they are checking on the resident.',
        state: emergencyAlert.state,
        dataSource: isDemoMode ? 'simulated' : 'real',
      },
      ...prev,
    ]);
  };

  // Step 7: If Escalate is clicked, change to Escalated.
  const handleEscalate = () => {
    sounds.playEscalate();
    setActiveScenario('Escalated Alert');
    transitionToState('ESCALATED');
  };

  // Demo: Countdown finishes without response -> Alert Sent
  const handleSimulateNoResponse = () => {
    sounds.playAlert();
    setActiveScenario('Countdown Expired (0s)');
    transitionToState('ALERT_SENT');
  };

  // Direct State selection
  const handleSelectState = (st: FallState) => {
    if (st === 'POSSIBLE_FALL') {
      handleSimulateLivingRoomFall();
    } else {
      transitionToState(st);
    }
  };

  // Demo Button: Bathroom Radar Presence Simulation
  // Requirements:
  // - First show “Checking movement…”
  // - Do not immediately display “Human detected.”
  // - Evaluate using presence duration, movement duration, distance gate, signal stability, and repeated readings.
  // - Use a minimum of 3 consecutive radar readings before changing status.
  // - Use a short temporal window of 2–5 seconds.
  // - Mark Human likely only after stable readings across multiple samples.
  const handleSimulateBathroomPresence = () => {
    radarTimeoutsRef.current.forEach(clearTimeout);
    radarTimeoutsRef.current = [];

    if (radarState.state === 'HUMAN_LIKELY') {
      // Toggle off / Vacate
      sounds.playSuccess();
      setRadarSamples([]);
      setRadarState({
        ...INITIAL_RADAR_STATE,
        lastEvaluationReason: 'Target left zone. Radar echo returned to idle noise floor.',
      });
      setBathroomPresence('Not detected');
      setBathroomMovement('No movement');
      setBathroomDwell(0);
      setActiveScenario(null);
      const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastRadarEvent(`${time} • Echo faded to baseline noise floor (Vacated)`);
      addEvent(
        'Bathroom Vacated',
        'HLK-LD2410C radar target distance faded. Zone returned to baseline idle noise floor.',
        'Bathroom',
        'sensor',
        'info'
      );
      return;
    }

    // New radar trigger arrives:
    sounds.playAlert();
    setActiveScenario('Radar Multi-Sample Verification');
    const startTime = Date.now();
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Reading 1 of 3: First raw trigger arrives -> enters TARGET_CHECKING ("Checking movement…")
    const sample1: RadarSample = {
      timestamp: startTime,
      presence: true,
      movement: true,
      distanceGate: 2,
      distanceMeters: 1.35,
      signalEnergy: 84,
      stabilityScore: 88,
      targetProfile: 'human_candidate',
    };
    ingestRadarSample(sample1);
    setLastRadarEvent(`${timeStr} • Radar trigger at Gate 2 -> Checking movement…`);
    addEvent(
      'Checking movement… (Reading 1 of 3)',
      'Raw radar trigger detected at Gate 2. Verifying presence duration and stability over 2–5s before confirming.',
      'Bathroom',
      'sensor',
      'info'
    );

    // Reading 2 of 3: Still verifying in temporal window
    const t2 = setTimeout(() => {
      const sample2: RadarSample = {
        timestamp: Date.now(),
        presence: true,
        movement: true,
        distanceGate: 2,
        distanceMeters: 1.33,
        signalEnergy: 90,
        stabilityScore: 92,
        targetProfile: 'human_candidate',
      };
      ingestRadarSample(sample2);
    }, 900);
    radarTimeoutsRef.current.push(t2);

    // Reading 3 of 3 (t = 2100ms): At least 3 consecutive stable readings within 2-5s window -> Human likely!
    const t3 = setTimeout(() => {
      sounds.playSuccess();
      const sample3: RadarSample = {
        timestamp: Date.now(),
        presence: true,
        movement: false,
        distanceGate: 2,
        distanceMeters: 1.34,
        signalEnergy: 94,
        stabilityScore: 95,
        targetProfile: 'human_candidate',
      };
      ingestRadarSample(sample3);
      const nowTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastRadarEvent(`${nowTime} • Target confirmed: Human likely (3 samples verified, Gate 2)`);
      addEvent(
        'Human likely in bathroom',
        'Human-sized reflection verified over 3 consecutive radar samples across 2.1s (Gate 2, 95% stability).',
        'Bathroom',
        'presence',
        'info'
      );
    }, 2100);
    radarTimeoutsRef.current.push(t3);
  };

  // Demo: Non-Human Movement (curtain flutter, fan, pet)
  // Kept out of emergency alert workflow!
  const handleSimulateNonHumanMovement = () => {
    radarTimeoutsRef.current.forEach(clearTimeout);
    radarTimeoutsRef.current = [];
    sounds.playAlert();
    setActiveScenario('Non-Human Filter Simulation');

    const startTime = Date.now();
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Reading 1:
    const sample1: RadarSample = {
      timestamp: startTime,
      presence: true,
      movement: true,
      distanceGate: 4,
      distanceMeters: 3.2,
      signalEnergy: 35,
      stabilityScore: 32,
      targetProfile: 'micro_flutter',
    };
    ingestRadarSample(sample1);
    setLastRadarEvent(`${timeStr} • Movement detected -> Checking movement…`);
    addEvent(
      'Checking movement… (Radar trigger)',
      'Motion detected by radar. Evaluating signal consistency over 2–5s...',
      'Bathroom',
      'sensor',
      'info'
    );

    // Reading 2:
    const t2 = setTimeout(() => {
      const sample2: RadarSample = {
        timestamp: Date.now(),
        presence: true,
        movement: true,
        distanceGate: 2,
        distanceMeters: 1.4,
        signalEnergy: 28,
        stabilityScore: 25,
        targetProfile: 'micro_flutter',
      };
      ingestRadarSample(sample2);
    }, 800);
    radarTimeoutsRef.current.push(t2);

    // Reading 3 (t = 1800ms): Signal is brief, unstable, erratic micro-flutter
    const t3 = setTimeout(() => {
      const sample3: RadarSample = {
        timestamp: Date.now(),
        presence: false,
        movement: false,
        distanceGate: 5,
        distanceMeters: 4.1,
        signalEnergy: 20,
        stabilityScore: 22,
        targetProfile: 'micro_flutter',
      };
      ingestRadarSample(sample3);
      const nowTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastRadarEvent(`${nowTime} • Filtered: Non-human movement likely (Unstable echo)`);
      addEvent(
        'Non-human movement likely',
        'Brief, unstable signal detected (curtain flutter, fan, or pet). Safely excluded from caregiver alert pipeline.',
        'Bathroom',
        'sensor',
        'info'
      );
    }, 1800);
    radarTimeoutsRef.current.push(t3);
  };

  // Demo: Bathroom Fall (Requires possible impact, sudden transition, unusual low-position event across multiple readings)
  // "Never trigger a caregiver alert from one radar reading."
  const handleSimulateBathroomFall = () => {
    radarTimeoutsRef.current.forEach(clearTimeout);
    radarTimeoutsRef.current = [];
    sounds.playAlert();
    setActiveScenario('Bathroom Fall Simulation');

    const startTime = Date.now();
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Reading 1: Sudden downward transition
    const sample1: RadarSample = {
      timestamp: startTime,
      presence: true,
      movement: true,
      distanceGate: 1,
      distanceMeters: 0.85,
      signalEnergy: 92,
      stabilityScore: 85,
      isLowPositionImpact: true,
      targetProfile: 'low_position_impact',
    };
    ingestRadarSample(sample1);
    setLastRadarEvent(`${timeStr} • High-G downward transition detected at Gate 1 (Floor level)`);

    // Reading 2 (t = 700ms): Low-position corroboration
    const t2 = setTimeout(() => {
      const sample2: RadarSample = {
        timestamp: Date.now(),
        presence: true,
        movement: false,
        distanceGate: 1,
        distanceMeters: 0.8,
        signalEnergy: 94,
        stabilityScore: 88,
        isLowPositionImpact: true,
        targetProfile: 'low_position_impact',
      };
      ingestRadarSample(sample2);
    }, 700);
    radarTimeoutsRef.current.push(t2);

    // Reading 3 (t = 1600ms): Sustained low-position stillness confirmed across >= 3 readings
    const t3 = setTimeout(() => {
      sounds.playAlert();
      const sample3: RadarSample = {
        timestamp: Date.now(),
        presence: true,
        movement: false,
        distanceGate: 1,
        distanceMeters: 0.78,
        signalEnergy: 95,
        stabilityScore: 92,
        isLowPositionImpact: true,
        targetProfile: 'low_position_impact',
      };
      ingestRadarSample(sample3);

      const nowTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastRadarEvent(`${nowTime} • Sustained low-position target confirmed across 3 readings (Possible fall)`);

      // Initiate 20-second resident response countdown for Bathroom
      transitionToState('POSSIBLE_FALL', { room: 'Bathroom', timestamp: nowTime });

      stepTimerRef.current = setTimeout(() => {
        transitionToState('CHECKING_RESPONSE', { room: 'Bathroom', timestamp: nowTime });
      }, 1200);
    }, 1600);
    radarTimeoutsRef.current.push(t3);
  };

  // Direct 7-State machine selection
  const handleSelectRadarState = (st: RadarTargetState) => {
    radarTimeoutsRef.current.forEach(clearTimeout);
    radarTimeoutsRef.current = [];
    const now = Date.now();

    switch (st) {
      case 'NO_TARGET':
        setRadarSamples([]);
        setRadarState({
          ...INITIAL_RADAR_STATE,
          lastEvaluationReason: 'Manually reset to NO_TARGET. Area empty.',
        });
        setBathroomPresence('Not detected');
        setBathroomMovement('No movement');
        setBathroomDwell(0);
        if (fallState !== 'NORMAL' && emergencyAlert.room === 'Bathroom') {
          transitionToState('NORMAL');
        }
        break;

      case 'TARGET_CHECKING': {
        const s1: RadarSample = {
          timestamp: now,
          presence: true,
          movement: true,
          distanceGate: 2,
          distanceMeters: 1.35,
          signalEnergy: 80,
          stabilityScore: 85,
          targetProfile: 'human_candidate',
        };
        setRadarSamples([s1]);
        setRadarState(evaluateRadarSamples([s1], radarState, now));
        setBathroomPresence('Not detected');
        setBathroomMovement('Movement detected');
        break;
      }

      case 'HUMAN_LIKELY': {
        const sList: RadarSample[] = [
          { timestamp: now - 2000, presence: true, movement: true, distanceGate: 2, distanceMeters: 1.35, signalEnergy: 85, stabilityScore: 90, targetProfile: 'human_candidate' },
          { timestamp: now - 1000, presence: true, movement: true, distanceGate: 2, distanceMeters: 1.34, signalEnergy: 90, stabilityScore: 92, targetProfile: 'human_candidate' },
          { timestamp: now, presence: true, movement: false, distanceGate: 2, distanceMeters: 1.34, signalEnergy: 94, stabilityScore: 95, targetProfile: 'human_candidate' },
        ];
        setRadarSamples(sList);
        setRadarState(evaluateRadarSamples(sList, radarState, now));
        setBathroomPresence('Presence detected');
        setBathroomMovement('Static breathing');
        break;
      }

      case 'NON_HUMAN_LIKELY': {
        const sList: RadarSample[] = [
          { timestamp: now - 2000, presence: true, movement: true, distanceGate: 4, distanceMeters: 3.2, signalEnergy: 35, stabilityScore: 30, targetProfile: 'micro_flutter' },
          { timestamp: now - 1000, presence: true, movement: true, distanceGate: 2, distanceMeters: 1.4, signalEnergy: 30, stabilityScore: 28, targetProfile: 'micro_flutter' },
          { timestamp: now, presence: false, movement: false, distanceGate: 5, distanceMeters: 4.1, signalEnergy: 22, stabilityScore: 24, targetProfile: 'micro_flutter' },
        ];
        setRadarSamples(sList);
        setRadarState(evaluateRadarSamples(sList, radarState, now));
        setBathroomPresence('Not detected');
        setBathroomMovement('Low movement');
        break;
      }

      case 'POSSIBLE_FALL':
        handleSimulateBathroomFall();
        break;

      case 'CHECKING_RESPONSE': {
        const nowTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        transitionToState('CHECKING_RESPONSE', { room: 'Bathroom', timestamp: nowTime });
        break;
      }

      case 'ALERT_SENT': {
        const nowTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        transitionToState('ALERT_SENT', { room: 'Bathroom', timestamp: nowTime });
        break;
      }
    }
  };

  // Reset Demo -> NORMAL
  const handleResetDemo = () => {
    radarTimeoutsRef.current.forEach(clearTimeout);
    radarTimeoutsRef.current = [];
    sounds.playSuccess();
    handleRestoreAllHealth();
    setForcedLandmarkError(null);
    setRadarSamples([]);
    setRadarState(INITIAL_RADAR_STATE);
    setBathroomPresence('Not detected');
    setBathroomMovement('No movement');
    setBathroomDwell(0);
    setActiveScenario(null);
    transitionToState('NORMAL');
  };

  // Fault injection handlers to test robust error handling
  const handleInjectDuplicateEvents = () => {
    sounds.playAlert();
    const nowStr = new Date().toISOString();
    const timeDisplay = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const dupId = `dup-${Date.now()}`;
    const dupEvent: TimelineEvent = {
      id: dupId,
      timestamp: nowStr,
      timeString: timeDisplay,
      room: 'Living Room',
      type: 'sensor',
      severity: 'info',
      title: 'Pose Telemetry Stream Sync',
      description: 'Incoming sensor heartbeat. Testing timeline deduplication logic.',
    };
    // Inject identical events simultaneously
    setTimelineEvents((prev) => [dupEvent, { ...dupEvent }, ...prev]);
  };

  const handleInjectInvalidStatusEvent = () => {
    sounds.playAlert();
    const timeDisplay = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const invalidEvent = {
      id: `malformed-${Date.now()}`,
      timestamp: 'corrupted-timestamp',
      timeString: timeDisplay,
      room: 'Living Room' as TimelineEvent['room'],
      type: 'invalid_sensor_type' as unknown as TimelineEvent['type'],
      severity: 'non_standard_sev' as unknown as TimelineEvent['severity'],
      title: '',
      description: 'Simulated malformed packet with unparseable fields. Safe fallback active.',
      state: 'UNKNOWN_FALL_STATE' as unknown as FallState,
    };
    setTimelineEvents((prev) => [invalidEvent as unknown as TimelineEvent, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-['Plus_Jakarta_Sans']">
      {/* Top Bar */}
      <TopBar
        systemActive={fallState === 'NORMAL' && backendStatus === 'Online'}
        backendStatus={backendStatus}
        isAnyModuleDisconnected={isAnyModuleDisconnected}
        soundEnabled={soundEnabled}
        onToggleSound={setSoundEnabled}
        isDemoMode={isDemoMode}
        onToggleDemoMode={handleToggleDemoMode}
        apiStatus={apiStatus}
        onOpenApiSettings={() => setIsApiModalOpen(true)}
        onBackToWelcome={onBackToWelcome}
      />

      {/* Main Dashboard Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {onBackToWelcome && (
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <button
              id="back-to-welcome-btn"
              onClick={onBackToWelcome}
              className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-emerald-700 bg-white hover:bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-300 transition-all shadow-sm cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>← Back to Raksha Welcome Page</span>
            </button>
            <div className="text-xs text-slate-500 hidden sm:flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Live Sensor Feeds &amp; Safety Engine Active</span>
            </div>
          </div>
        )}

        {/* Warning banner if any required module is disconnected */}
        {isAnyModuleDisconnected && (
          <div
            id="app-level-warning-banner"
            role="alert"
            className="rounded-xl border border-amber-300 bg-amber-50 p-3.5 text-amber-900 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-100 text-amber-800 border border-amber-200 shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-700" />
              </div>
              <div>
                <p className="font-bold text-sm text-slate-900 flex items-center gap-2 flex-wrap">
                  <span>System Notice: Sensor Needs Attention</span>
                  {backendStatus === 'Offline' && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-200 text-amber-900 border border-amber-300">
                      Gateway Offline
                    </span>
                  )}
                </p>
                <p className="text-xs text-slate-600 mt-0.5">
                  {backendStatus === 'Offline'
                    ? 'The alert gateway is offline. Please check connection.'
                    : 'One or more sensors are currently disconnected. Check device status below.'}
                </p>
              </div>
            </div>
            <button
              id="btn-app-warning-restore"
              onClick={handleRestoreAllHealth}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs transition-colors shrink-0 self-start sm:self-auto shadow-sm"
            >
              Restore All Modules
            </button>
          </div>
        )}

        {/* 1. Emergency Alert Area (near top of screen on every device) */}
        <EmergencyAlertArea
          alert={emergencyAlert}
          onImOkay={handleImOkay}
          onAcknowledge={handleAcknowledgeAlert}
          onEscalate={handleEscalate}
          onReset={handleResetDemo}
        />

        {/* 2. Main Status Area: Two large room cards side by side on desktop & stacked on mobile */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Card 1: Living Room with 3D 33-body-points Skeleton */}
          <LivingRoomCard
            status={livingRoomStatus}
            cameraConnected={cameraModule === 'Connected' && mediaPipe === 'Ready'}
            room={emergencyAlert.room || 'Living Room'}
            incidentTimestamp={
              fallState !== 'NORMAL' ? emergencyAlert.timestamp : undefined
            }
            onStatusChange={setLivingRoomStatus}
            forcedLandmarkError={forcedLandmarkError}
            onClearForcedError={() => setForcedLandmarkError(null)}
            isDemoMode={isDemoMode}
          />

          {/* Card 2: Bathroom with Non-imaging radar & Human-Presence State Machine */}
          <BathroomCard
            radarState={radarState}
            presence={bathroomPresence}
            movement={bathroomMovement}
            sensorStatus={bathroomRadar === 'Connected' ? 'Online' : 'Offline'}
            radarConnected={bathroomRadar === 'Connected'}
            dwellSeconds={bathroomDwell}
            distanceMeters={radarState.distanceMeters || (bathroomPresence === 'Presence detected' ? 1.4 : 0)}
            isDemoMode={isDemoMode}
          />
        </div>

        {/* 3. Help Area: "What should I do?" */}
        <HelpActionSection fallState={fallState} />

        {/* 4. Recent Activity: "What happened recently" & Privacy Protection */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent-Events Timeline (Latest 5 events in plain language) */}
          <RecentEventsTimeline
            events={isDemoMode ? timelineEvents : realApiEvents}
            onClear={() => {
              if (isDemoMode) {
                setTimelineEvents([]);
              } else {
                setRealApiEvents([]);
              }
            }}
            backendStatus={backendStatus}
            isDemoMode={isDemoMode}
            apiStatus={apiStatus}
          />

          {/* Privacy Section (Collapsible guide) */}
          <div className="space-y-6">
            <PrivacySection />

            {/* System Health Subsystems Section */}
            <SystemHealthSection
              cameraModule={cameraModule}
              mediaPipe={mediaPipe}
              bathroomRadar={bathroomRadar}
              backend={backendStatus}
              lastCameraEvent={lastCameraEvent}
              lastRadarEvent={lastRadarEvent}
              lastDashboardUpdate={lastDashboardUpdate}
              onToggleCamera={handleToggleCamera}
              onToggleMediaPipe={handleToggleMediaPipe}
              onToggleRadar={handleToggleRadar}
              onToggleBackend={handleToggleBackend}
              onRestoreAll={handleRestoreAllHealth}
              onRefreshDashboard={() => {
                const timeStr = new Date().toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                });
                setLastDashboardUpdate(`${timeStr} • Manual telemetry poll`);
                checkApiConnection();
              }}
              isDemoMode={isDemoMode}
              apiStatus={apiStatus}
              onOpenApiSettings={() => setIsApiModalOpen(true)}
            />
          </div>
        </div>

        {/* 5. Testing & Demo Tools (Collapsible simulation bar) */}
        <DemoControlsBar
          onSimulateLivingRoomFall={handleSimulateLivingRoomFall}
          onSimulateBathroomPresence={handleSimulateBathroomPresence}
          onSimulateNonHumanMovement={handleSimulateNonHumanMovement}
          onSimulateBathroomFall={handleSimulateBathroomFall}
          onSimulateNoResponse={handleSimulateNoResponse}
          onMarkResidentSafe={handleImOkay}
          onResetDemo={handleResetDemo}
          activeScenario={activeScenario}
          activeState={fallState}
          activeRadarState={radarState.state}
          onSelectState={handleSelectState}
          onSelectRadarState={handleSelectRadarState}
          forcedLandmarkError={forcedLandmarkError}
          onSetForcedLandmarkError={setForcedLandmarkError}
          backendStatus={backendStatus}
          onToggleBackend={handleToggleBackend}
          cameraConnected={cameraModule === 'Connected' && mediaPipe === 'Ready'}
          onToggleCamera={handleToggleCamera}
          radarConnected={bathroomRadar === 'Connected'}
          onToggleRadar={handleToggleRadar}
          onInjectDuplicateEvents={handleInjectDuplicateEvents}
          onInjectInvalidStatusEvent={handleInjectInvalidStatusEvent}
          onClearEvents={() => {
            if (isDemoMode) {
              setTimelineEvents([]);
            } else {
              setRealApiEvents([]);
            }
          }}
          isDemoMode={isDemoMode}
          onToggleDemoMode={handleToggleDemoMode}
          apiStatus={apiStatus}
          onOpenApiSettings={() => setIsApiModalOpen(true)}
        />
      </main>

      {/* API Connection & Diagnostics Modal */}
      <ApiConnectionModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
        apiStatus={apiStatus}
        onRefresh={checkApiConnection}
        isDemoMode={isDemoMode}
        onToggleDemoMode={handleToggleDemoMode}
      />

      {/* Dashboard Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-500 font-sans">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Raksha Caregiver Portal • Local Edge Inference Only • No Facial Recognition</span>
          <span>Hardware ID: RAKSHA-EDGE-GW-401 • HIPAA Safeguard Compliant</span>
        </div>
      </footer>
    </div>
  );
}

export default CaregiverDashboard;

