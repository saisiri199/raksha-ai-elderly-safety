import React from 'react';
import { HelpCircle, CheckCircle2, AlertTriangle, PhoneCall } from 'lucide-react';
import { FallState } from '../types';

interface HelpActionSectionProps {
  fallState: FallState;
}

export const HelpActionSection: React.FC<HelpActionSectionProps> = ({ fallState }) => {
  const isRed = fallState === 'ALERT_SENT' || fallState === 'ESCALATED';
  const isYellow = fallState === 'POSSIBLE_FALL' || fallState === 'CHECKING_RESPONSE';
  const isGreen = !isRed && !isYellow;

  return (
    <section
      id="help-action-section"
      aria-label="What should I do?"
      className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm"
    >
      <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
        <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100">
          <HelpCircle className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-base font-bold text-slate-900 font-['Plus_Jakarta_Sans']">
            What should I do?
          </h3>
          <p className="text-xs text-slate-500">
            Quick reference guide for peace of mind
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-4">
        {/* Green condition */}
        <div
          className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
            isGreen
              ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-100'
              : 'bg-slate-50 border-slate-200 opacity-75'
          }`}
        >
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Green screen
              </span>
            </div>
            <p className="text-sm font-bold text-slate-900 mt-1">
              No action needed.
            </p>
            <p className="text-xs text-slate-600 mt-0.5">
              Everything is normal and monitored safely.
            </p>
          </div>
        </div>

        {/* Yellow condition */}
        <div
          className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
            isYellow
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-100'
              : 'bg-slate-50 border-slate-200 opacity-75'
          }`}
        >
          <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 mt-0.5">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Yellow screen
              </span>
            </div>
            <p className="text-sm font-bold text-slate-900 mt-1">
              Please check the person.
            </p>
            <p className="text-xs text-slate-600 mt-0.5">
              A potential event is undergoing 20s verification.
            </p>
          </div>
        </div>

        {/* Red condition */}
        <div
          className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
            isRed
              ? 'bg-red-50/80 border-red-300 ring-2 ring-red-100'
              : 'bg-slate-50 border-slate-200 opacity-75'
          }`}
        >
          <div className="w-7 h-7 rounded-lg bg-red-100 text-red-700 flex items-center justify-center shrink-0 mt-0.5">
            <PhoneCall className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Red screen
              </span>
            </div>
            <p className="text-sm font-bold text-slate-900 mt-1">
              Contact the resident or caregiver immediately.
            </p>
            <p className="text-xs text-slate-600 mt-0.5">
              Check in directly or use the Call for Help button.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
export default HelpActionSection;
